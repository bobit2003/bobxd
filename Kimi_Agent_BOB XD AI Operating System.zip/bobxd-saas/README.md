# BOB XD - AI Operating System for Agencies

<p align="center">
  <img src="https://img.shields.io/badge/BOB%20XD-AI%20Empire-7B3FE4?style=for-the-badge" alt="BOB XD">
</p>

<p align="center">
  <strong>Build Your AI Empire</strong>
</p>

<p align="center">
  <a href="#features">Features</a> •
  <a href="#tech-stack">Tech Stack</a> •
  <a href="#quick-start">Quick Start</a> •
  <a href="#deployment">Deployment</a> •
  <a href="#api-documentation">API</a>
</p>

---

## Overview

BOB XD is a production-ready, multi-tenant SaaS platform that serves as an **AI Operating System for Agencies**. It provides a complete solution for managing AI agents, tracking leads, running automations, executing campaigns, and monitoring AI activity.

### Key Features

- **AI Agent Management**: Create, configure, and deploy multiple AI agents
- **Lead Management**: Track and manage high-value leads with full CRM capabilities
- **Campaign Execution**: Run automated marketing campaigns
- **Real-time Monitoring**: WebSocket-powered live execution updates
- **Usage Tracking**: Comprehensive quota and subscription management
- **Multi-tenant Architecture**: Workspace-based isolation for agencies
- **Role-based Access Control**: Fine-grained permissions system

## Tech Stack

### Backend
- **Fastify** - High-performance Node.js framework
- **Prisma** - Next-generation ORM
- **PostgreSQL** - Primary database
- **Redis** - Caching and job queues
- **BullMQ** - Distributed job processing
- **JWT** - Authentication and authorization
- **WebSocket** - Real-time communication

### Frontend
- **React 18** - UI library
- **TypeScript** - Type safety
- **Vite** - Build tool
- **Tailwind CSS** - Styling
- **Zustand** - State management
- **shadcn/ui** - UI components

### Infrastructure
- **Docker** - Containerization
- **Docker Compose** - Local orchestration
- **Nginx** - Reverse proxy and static serving

## Quick Start

### Prerequisites

- Node.js 20+
- Docker and Docker Compose
- OpenClaw API key (get from [openclaw.ai](https://openclaw.ai))

### Installation

1. **Clone the repository**
   ```bash
   git clone https://github.com/your-org/bobxd-saas.git
   cd bobxd-saas
   ```

2. **Set up environment variables**
   ```bash
   cp .env.example .env
   # Edit .env with your configuration
   ```

3. **Start with Docker Compose**
   ```bash
   docker-compose up -d
   ```

4. **Run database migrations**
   ```bash
   docker-compose --profile migrations run --rm migrations
   ```

5. **Access the application**
   - Frontend: http://localhost:8080
   - Backend API: http://localhost:3001
   - API Documentation: http://localhost:3001/api/v1

### Development Setup

1. **Install backend dependencies**
   ```bash
   cd backend
   npm install
   cp .env.example .env
   # Edit .env with your configuration
   npx prisma generate
   npm run dev
   ```

2. **Install frontend dependencies**
   ```bash
   cd frontend
   npm install
   cp .env.example .env
   npm run dev
   ```

## Project Structure

```
bobxd-saas/
├── backend/                 # Fastify backend API
│   ├── src/
│   │   ├── config/         # Configuration files
│   │   ├── middleware/     # Express middleware
│   │   ├── prisma/         # Database schema
│   │   ├── routes/         # API routes
│   │   ├── services/       # Business logic
│   │   ├── types/          # TypeScript types
│   │   ├── utils/          # Utility functions
│   │   ├── jobs/           # BullMQ workers
│   │   └── websocket/      # WebSocket manager
│   ├── Dockerfile
│   └── package.json
├── frontend/               # React frontend
│   ├── src/
│   │   ├── components/     # React components
│   │   ├── pages/          # Page components
│   │   ├── stores/         # Zustand stores
│   │   ├── services/       # API services
│   │   └── types/          # TypeScript types
│   ├── Dockerfile
│   └── package.json
├── docker-compose.yml
└── README.md
```

## API Documentation

### Authentication

All API endpoints (except `/auth/login` and `/auth/register`) require authentication via Bearer token:

```
Authorization: Bearer <access_token>
```

### Endpoints

#### Auth
- `POST /api/v1/auth/register` - Register new user
- `POST /api/v1/auth/login` - Login user
- `POST /api/v1/auth/refresh` - Refresh access token
- `POST /api/v1/auth/logout` - Logout user
- `GET /api/v1/auth/me` - Get current user

#### Workspaces
- `GET /api/v1/workspaces` - List user workspaces
- `POST /api/v1/workspaces` - Create workspace
- `GET /api/v1/workspaces/:id` - Get workspace details
- `PATCH /api/v1/workspaces/:id` - Update workspace
- `DELETE /api/v1/workspaces/:id` - Delete workspace

#### Leads
- `GET /api/v1/leads/workspace/:workspaceId` - List workspace leads
- `POST /api/v1/leads/workspace/:workspaceId` - Create lead
- `GET /api/v1/leads/:id` - Get lead details
- `PATCH /api/v1/leads/:id` - Update lead
- `DELETE /api/v1/leads/:id` - Delete lead

#### Agents
- `GET /api/v1/agents/workspace/:workspaceId` - List agents
- `POST /api/v1/agents/workspace/:workspaceId` - Create agent
- `GET /api/v1/agents/:id` - Get agent details
- `PATCH /api/v1/agents/:id` - Update agent
- `DELETE /api/v1/agents/:id` - Delete agent
- `POST /api/v1/agents/:id/execute` - Execute agent task
- `POST /api/v1/agents/:id/toggle` - Toggle agent status

#### Subscriptions
- `GET /api/v1/subscriptions/workspace/:workspaceId` - Get subscription
- `GET /api/v1/subscriptions/workspace/:workspaceId/usage` - Get usage stats
- `POST /api/v1/subscriptions/workspace/:workspaceId/upgrade` - Upgrade plan

#### Admin (Super Admin only)
- `GET /api/v1/admin/stats` - Platform statistics
- `GET /api/v1/admin/users` - List all users
- `GET /api/v1/admin/workspaces` - List all workspaces
- `GET /api/v1/admin/audit-logs` - View audit logs

## Deployment

### Production Checklist

- [ ] Change all default secrets and passwords
- [ ] Set up SSL/TLS certificates
- [ ] Configure proper CORS origins
- [ ] Set up monitoring and logging
- [ ] Configure backup strategies
- [ ] Set up CI/CD pipeline

### Environment Variables

| Variable | Description | Required |
|----------|-------------|----------|
| `POSTGRES_PASSWORD` | Database password | Yes |
| `JWT_SECRET` | JWT signing secret | Yes |
| `JWT_REFRESH_SECRET` | JWT refresh secret | Yes |
| `OPENCLAW_API_KEY` | OpenClaw API key | Yes |
| `ENCRYPTION_KEY` | API key encryption | Yes |
| `FRONTEND_URL` | Frontend URL | Yes |

### Scaling

For high-traffic deployments:

1. **Horizontal Scaling**
   - Run multiple backend instances behind a load balancer
   - Use Redis Cluster for session storage
   - Implement database read replicas

2. **Background Jobs**
   - Scale BullMQ workers independently
   - Use separate queues for different job types

3. **Caching**
   - Implement Redis caching for frequently accessed data
   - Use CDN for static assets

## Agent Types

BOB XD supports six built-in agent types:

1. **Lead Hunter** - Automatically find and qualify leads
2. **LinkedIn Outreach** - Personalized connection requests
3. **SEO Audit** - Website analysis and recommendations
4. **Ads Strategy** - Campaign creation and optimization
5. **Content Generator** - Marketing content creation
6. **CRM Automation** - Workflow automation

## Subscription Plans

| Feature | Starter | Pro | Agency |
|---------|---------|-----|--------|
| Agents | 3 | 10 | 50 |
| Leads | 500 | 5,000 | 50,000 |
| Executions | 1,000 | 10,000 | 100,000 |
| Tokens | 100K | 1M | 10M |
| Price | $49/mo | $149/mo | $499/mo |

## Contributing

1. Fork the repository
2. Create your feature branch (`git checkout -b feature/amazing-feature`)
3. Commit your changes (`git commit -m 'Add amazing feature'`)
4. Push to the branch (`git push origin feature/amazing-feature`)
5. Open a Pull Request

## License

This project is licensed under the MIT License - see the LICENSE file for details.

## Support

For support, email support@bobxd.ai or join our Discord community.

---

<p align="center">
  Built with ❤️ by the BOB XD Team
</p>
