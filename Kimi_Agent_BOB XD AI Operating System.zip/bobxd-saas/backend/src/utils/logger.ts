/**
 * @fileoverview Logging Utility
 * Configured Pino logger for structured logging
 */

import pino from 'pino';
import { config } from '@config/index';

/**
 * Pino logger instance configured for environment
 */
export const logger = pino({
  level: config.server.isDevelopment ? 'debug' : 'info',
  transport: config.server.isDevelopment
    ? {
        target: 'pino-pretty',
        options: {
          colorize: true,
          translateTime: 'HH:MM:ss Z',
          ignore: 'pid,hostname',
        },
      }
    : undefined,
  base: {
    env: config.server.env,
    version: process.env.npm_package_version,
  },
});

/**
 * Creates a child logger with additional context
 * @param context - Context object to include in all logs
 * @returns Child logger instance
 */
export function createLogger(context: Record<string, unknown>) {
  return logger.child(context);
}

/**
 * Logs an audit event
 * @param action - Action being performed
 * @param entity - Entity being affected
 * @param userId - User performing the action
 * @param metadata - Additional metadata
 */
export function logAudit(
  action: string,
  entity: { type: string; id?: string },
  userId?: string,
  metadata?: Record<string, unknown>
): void {
  logger.info({
    type: 'audit',
    action,
    entity,
    userId,
    ...metadata,
  }, `Audit: ${action} on ${entity.type}`);
}
