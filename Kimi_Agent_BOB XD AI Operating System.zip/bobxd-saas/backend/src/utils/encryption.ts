/**
 * @fileoverview Encryption Utilities
 * Handles API key encryption/decryption and secure data handling
 */

import crypto from 'crypto';
import { config } from '@config/index';

const ALGORITHM = 'aes-256-gcm';
const IV_LENGTH = 16;
const AUTH_TAG_LENGTH = 16;

/**
 * Encrypts sensitive data using AES-256-GCM
 * @param text - Plain text to encrypt
 * @returns Encrypted string in format: iv:authTag:encryptedData
 */
export function encrypt(text: string): string {
  const iv = crypto.randomBytes(IV_LENGTH);
  const cipher = crypto.createCipheriv(ALGORITHM, Buffer.from(config.encryption.key.slice(0, 32)), iv);
  
  let encrypted = cipher.update(text, 'utf8', 'hex');
  encrypted += cipher.final('hex');
  
  const authTag = cipher.getAuthTag();
  
  return `${iv.toString('hex')}:${authTag.toString('hex')}:${encrypted}`;
}

/**
 * Decrypts data encrypted with encrypt()
 * @param encryptedData - Encrypted string in format: iv:authTag:encryptedData
 * @returns Decrypted plain text
 */
export function decrypt(encryptedData: string): string {
  const [ivHex, authTagHex, encrypted] = encryptedData.split(':');
  
  if (!ivHex || !authTagHex || !encrypted) {
    throw new Error('Invalid encrypted data format');
  }
  
  const iv = Buffer.from(ivHex, 'hex');
  const authTag = Buffer.from(authTagHex, 'hex');
  
  const decipher = crypto.createDecipheriv(ALGORITHM, Buffer.from(config.encryption.key.slice(0, 32)), iv);
  decipher.setAuthTag(authTag);
  
  let decrypted = decipher.update(encrypted, 'hex', 'utf8');
  decrypted += decipher.final('utf8');
  
  return decrypted;
}

/**
 * Generates a secure random API key
 * @returns Object containing the full key and prefix for storage
 */
export function generateApiKey(): { key: string; prefix: string; hash: string } {
  const key = `bxd_${crypto.randomBytes(32).toString('hex')}`;
  const prefix = key.slice(0, 12);
  const hash = crypto.createHash('sha256').update(key).digest('hex');
  
  return { key, prefix, hash };
}

/**
 * Hashes a string using SHA-256
 * @param data - String to hash
 * @returns SHA-256 hash
 */
export function hashString(data: string): string {
  return crypto.createHash('sha256').update(data).digest('hex');
}

/**
 * Compares a plain string with a hash
 * @param plain - Plain text to compare
 * @param hash - Hash to compare against
 * @returns Boolean indicating match
 */
export function compareHash(plain: string, hash: string): boolean {
  const plainHash = crypto.createHash('sha256').update(plain).digest('hex');
  return plainHash === hash;
}

/**
 * Generates a secure random token
 * @param length - Length of the token in bytes (default: 32)
 * @returns Random token string
 */
export function generateToken(length: number = 32): string {
  return crypto.randomBytes(length).toString('hex');
}
