/**
 * @fileoverview BOB XD Configuration Module
 * Centralized configuration management for all environment variables
 */

import dotenv from 'dotenv';
import { z } from 'zod';

dotenv.config();

/**
 * Configuration schema validation using Zod
 */
const configSchema = z.object({
  // Database
  DATABASE_URL: z.string().min(1),
  
  // Redis
  REDIS_URL: z.string().default('redis://localhost:6379'),
  
  // JWT
  JWT_SECRET: z.string().min(32),
  JWT_REFRESH_SECRET: z.string().min(32),
  JWT_ACCESS_EXPIRATION: z.string().default('15m'),
  JWT_REFRESH_EXPIRATION: z.string().default('7d'),
  
  // Server
  PORT: z.string().transform(Number).default('3001'),
  NODE_ENV: z.enum(['development', 'production', 'test']).default('development'),
  HOST: z.string().default('0.0.0.0'),
  
  // OpenClaw API
  OPENCLAW_API_URL: z.string().url(),
  OPENCLAW_API_KEY: z.string().min(1),
  
  // Frontend
  FRONTEND_URL: z.string().url().default('http://localhost:5173'),
  
  // Rate Limiting
  RATE_LIMIT_MAX: z.string().transform(Number).default('100'),
  RATE_LIMIT_WINDOW_MS: z.string().transform(Number).default('60000'),
  
  // Encryption
  ENCRYPTION_KEY: z.string().min(32),
  
  // WebSocket
  WS_PING_INTERVAL: z.string().transform(Number).default('30000'),
});

/**
 * Parsed and validated configuration
 */
const parsedConfig = configSchema.safeParse(process.env);

if (!parsedConfig.success) {
  console.error('Configuration validation failed:', parsedConfig.error.format());
  process.exit(1);
}

/**
 * Application configuration object
 */
export const config = {
  database: {
    url: parsedConfig.data.DATABASE_URL,
  },
  redis: {
    url: parsedConfig.data.REDIS_URL,
  },
  jwt: {
    secret: parsedConfig.data.JWT_SECRET,
    refreshSecret: parsedConfig.data.JWT_REFRESH_SECRET,
    accessExpiration: parsedConfig.data.JWT_ACCESS_EXPIRATION,
    refreshExpiration: parsedConfig.data.JWT_REFRESH_EXPIRATION,
  },
  server: {
    port: parsedConfig.data.PORT,
    env: parsedConfig.data.NODE_ENV,
    host: parsedConfig.data.HOST,
    isDevelopment: parsedConfig.data.NODE_ENV === 'development',
    isProduction: parsedConfig.data.NODE_ENV === 'production',
  },
  openclaw: {
    apiUrl: parsedConfig.data.OPENCLAW_API_URL,
    apiKey: parsedConfig.data.OPENCLAW_API_KEY,
  },
  frontend: {
    url: parsedConfig.data.FRONTEND_URL,
  },
  rateLimit: {
    max: parsedConfig.data.RATE_LIMIT_MAX,
    windowMs: parsedConfig.data.RATE_LIMIT_WINDOW_MS,
  },
  encryption: {
    key: parsedConfig.data.ENCRYPTION_KEY,
  },
  websocket: {
    pingInterval: parsedConfig.data.WS_PING_INTERVAL,
  },
} as const;

export type Config = typeof config;
