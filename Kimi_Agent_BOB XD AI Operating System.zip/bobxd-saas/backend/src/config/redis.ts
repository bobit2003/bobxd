/**
 * @fileoverview Redis Configuration
 * Manages Redis connections for caching and job queues
 */

import Redis from 'ioredis';
import { config } from '@config/index';
import { logger } from '@utils/logger';

/**
 * Redis client for general caching and sessions
 */
export const redis = new Redis(config.redis.url, {
  retryStrategy: (times) => {
    const delay = Math.min(times * 50, 2000);
    return delay;
  },
  maxRetriesPerRequest: 3,
  enableReadyCheck: true,
});

/**
 * Redis client for BullMQ (separate connection)
 */
export const redisBullMq = new Redis(config.redis.url, {
  retryStrategy: (times) => {
    const delay = Math.min(times * 50, 2000);
    return delay;
  },
  maxRetriesPerRequest: null,
  enableReadyCheck: false,
});

/**
 * Redis subscriber for pub/sub
 */
export const redisSubscriber = new Redis(config.redis.url, {
  retryStrategy: (times) => {
    const delay = Math.min(times * 50, 2000);
    return delay;
  },
  maxRetriesPerRequest: null,
  enableReadyCheck: false,
});

// Event handlers
redis.on('connect', () => {
  logger.info('Redis connected');
});

redis.on('error', (error) => {
  logger.error({ error }, 'Redis error');
});

redis.on('reconnecting', () => {
  logger.warn('Redis reconnecting...');
});

/**
 * Cache helper functions
 */
export const cache = {
  /**
   * Gets a value from cache
   */
  async get<T>(key: string): Promise<T | null> {
    const value = await redis.get(key);
    if (!value) return null;
    try {
      return JSON.parse(value) as T;
    } catch {
      return value as unknown as T;
    }
  },

  /**
   * Sets a value in cache with optional TTL
   */
  async set(key: string, value: unknown, ttlSeconds?: number): Promise<void> {
    const serialized = typeof value === 'string' ? value : JSON.stringify(value);
    if (ttlSeconds) {
      await redis.setex(key, ttlSeconds, serialized);
    } else {
      await redis.set(key, serialized);
    }
  },

  /**
   * Deletes a key from cache
   */
  async del(key: string): Promise<void> {
    await redis.del(key);
  },

  /**
   * Deletes keys matching a pattern
   */
  async delPattern(pattern: string): Promise<void> {
    const keys = await redis.keys(pattern);
    if (keys.length > 0) {
      await redis.del(...keys);
    }
  },

  /**
   * Checks if a key exists
   */
  async exists(key: string): Promise<boolean> {
    const result = await redis.exists(key);
    return result === 1;
  },

  /**
   * Gets workspace-specific cache key
   */
  workspaceKey(workspaceId: string, suffix: string): string {
    return `workspace:${workspaceId}:${suffix}`;
  },

  /**
   * Gets user-specific cache key
   */
  userKey(userId: string, suffix: string): string {
    return `user:${userId}:${suffix}`;
  },
};

/**
 * Gracefully closes all Redis connections
 */
export async function closeRedisConnections(): Promise<void> {
  await redis.quit();
  await redisBullMq.quit();
  await redisSubscriber.quit();
  logger.info('Redis connections closed');
}
