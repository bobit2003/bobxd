/**
 * @fileoverview Error Handler Middleware
 * Centralized error handling for the application
 */

import { FastifyError, FastifyRequest, FastifyReply } from 'fastify';
import { ZodError } from 'zod';
import { logger } from '@utils/logger';
import { config } from '@config/index';

/**
 * Custom application error
 */
export class AppError extends Error {
  constructor(
    public statusCode: number,
    public code: string,
    message: string,
    public details?: Record<string, unknown>
  ) {
    super(message);
    this.name = 'AppError';
    Error.captureStackTrace(this, this.constructor);
  }
}

/**
 * Error response interface
 */
interface ErrorResponse {
  success: false;
  error: string;
  code: string;
  details?: Record<string, unknown>;
  stack?: string;
}

/**
 * Global error handler
 */
export function errorHandler(
  error: FastifyError | AppError | ZodError | Error,
  request: FastifyRequest,
  reply: FastifyReply
): void {
  // Log error
  logger.error({
    error: error.message,
    stack: error.stack,
    url: request.url,
    method: request.method,
    userId: (request as any).user?.userId,
  }, 'Request error');

  // Handle Zod validation errors
  if (error instanceof ZodError) {
    const response: ErrorResponse = {
      success: false,
      error: 'Validation failed',
      code: 'VALIDATION_ERROR',
      details: {
        errors: error.errors.map((e) => ({
          path: e.path.join('.'),
          message: e.message,
        })),
      },
    };
    reply.status(400).send(response);
    return;
  }

  // Handle custom app errors
  if (error instanceof AppError) {
    const response: ErrorResponse = {
      success: false,
      error: error.message,
      code: error.code,
      details: error.details,
    };

    if (config.server.isDevelopment) {
      response.stack = error.stack;
    }

    reply.status(error.statusCode).send(response);
    return;
  }

  // Handle Prisma errors
  if (error.name?.includes('Prisma')) {
    let statusCode = 500;
    let message = 'Database error';
    let code = 'DATABASE_ERROR';

    if (error.message.includes('Unique constraint')) {
      statusCode = 409;
      message = 'Resource already exists';
      code = 'DUPLICATE_ERROR';
    } else if (error.message.includes('Foreign key constraint')) {
      statusCode = 400;
      message = 'Referenced resource not found';
      code = 'FOREIGN_KEY_ERROR';
    } else if (error.message.includes('Record not found')) {
      statusCode = 404;
      message = 'Resource not found';
      code = 'NOT_FOUND';
    }

    const response: ErrorResponse = {
      success: false,
      error: message,
      code,
    };

    if (config.server.isDevelopment) {
      response.details = { originalError: error.message };
      response.stack = error.stack;
    }

    reply.status(statusCode).send(response);
    return;
  }

  // Handle JWT errors
  if (error.name === 'JsonWebTokenError' || error.name === 'TokenExpiredError') {
    const response: ErrorResponse = {
      success: false,
      error: 'Invalid or expired token',
      code: 'TOKEN_ERROR',
    };
    reply.status(401).send(response);
    return;
  }

  // Handle rate limit errors
  if (error.statusCode === 429) {
    const response: ErrorResponse = {
      success: false,
      error: 'Rate limit exceeded. Please try again later.',
      code: 'RATE_LIMIT_ERROR',
    };
    reply.status(429).send(response);
    return;
  }

  // Default error response
  const response: ErrorResponse = {
    success: false,
    error: config.server.isProduction ? 'Internal server error' : error.message,
    code: 'INTERNAL_ERROR',
  };

  if (config.server.isDevelopment) {
    response.stack = error.stack;
  }

  reply.status(500).send(response);
}

/**
 * Not found handler
 */
export function notFoundHandler(
  request: FastifyRequest,
  reply: FastifyReply
): void {
  reply.status(404).send({
    success: false,
    error: `Route ${request.method} ${request.url} not found`,
    code: 'ROUTE_NOT_FOUND',
  });
}
