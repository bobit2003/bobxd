/**
 * @fileoverview Authentication Middleware
 * JWT validation and role-based access control
 */

import { FastifyRequest, FastifyReply, HookHandlerDoneFunction } from 'fastify';
import { prisma } from '@prisma/client';
import { cache } from '@config/redis';
import { logger } from '@utils/logger';
import { UserRoleType, TokenPayload } from '@types/index';

/**
 * Extended request interface with user data
 */
export interface AuthenticatedRequest extends FastifyRequest {
  user: TokenPayload;
}

/**
 * JWT authentication middleware
 */
export async function authenticateToken(
  request: FastifyRequest,
  reply: FastifyReply
): Promise<void> {
  try {
    const authHeader = request.headers.authorization;

    if (!authHeader?.startsWith('Bearer ')) {
      reply.status(401).send({
        success: false,
        error: 'Access token required',
      });
      return;
    }

    const token = authHeader.substring(7);

    // Verify token
    const decoded = await request.server.jwt.verify<TokenPayload>(token);

    // Check if token is blacklisted
    const isBlacklisted = await cache.get(`blacklist:token:${token}`);
    if (isBlacklisted) {
      reply.status(401).send({
        success: false,
        error: 'Token has been revoked',
      });
      return;
    }

    // Verify user still exists and is active
    const user = await prisma.user.findUnique({
      where: { id: decoded.userId },
      select: { isActive: true },
    });

    if (!user || !user.isActive) {
      reply.status(401).send({
        success: false,
        error: 'User not found or inactive',
      });
      return;
    }

    // Attach user to request
    (request as AuthenticatedRequest).user = decoded;
  } catch (error) {
    logger.error({ error }, 'Token authentication failed');
    reply.status(401).send({
      success: false,
      error: 'Invalid or expired token',
    });
  }
}

/**
 * Creates role-based authorization middleware
 * @param allowedRoles - Roles that can access the route
 */
export function requireRoles(...allowedRoles: UserRoleType[]) {
  return async (
    request: FastifyRequest,
    reply: FastifyReply
  ): Promise<void> => {
    const user = (request as AuthenticatedRequest).user;

    if (!user) {
      reply.status(401).send({
        success: false,
        error: 'Authentication required',
      });
      return;
    }

    // Super admin can access everything
    if (user.role === 'SUPER_ADMIN') {
      return;
    }

    if (!allowedRoles.includes(user.role)) {
      reply.status(403).send({
        success: false,
        error: 'Insufficient permissions',
      });
      return;
    }
  };
}

/**
 * Middleware to check workspace membership
 */
export function requireWorkspaceMember() {
  return async (
    request: FastifyRequest,
    reply: FastifyReply
  ): Promise<void> => {
    const user = (request as AuthenticatedRequest).user;
    const workspaceId = request.params?.workspaceId || request.body?.workspaceId;

    if (!workspaceId) {
      reply.status(400).send({
        success: false,
        error: 'Workspace ID required',
      });
      return;
    }

    // Super admin can access any workspace
    if (user.role === 'SUPER_ADMIN') {
      return;
    }

    // Check if user is member of workspace
    const membership = await prisma.workspaceMember.findUnique({
      where: {
        userId_workspaceId: {
          userId: user.userId,
          workspaceId,
        },
      },
    });

    if (!membership) {
      reply.status(403).send({
        success: false,
        error: 'Not a member of this workspace',
      });
      return;
    }

    // Attach workspace role to user
    (request as AuthenticatedRequest & { workspaceRole: UserRoleType }).workspaceRole = membership.role;
  };
}

/**
 * API key authentication middleware
 */
export async function authenticateApiKey(
  request: FastifyRequest,
  reply: FastifyReply
): Promise<void> {
  try {
    const apiKey = request.headers['x-api-key'] as string;

    if (!apiKey) {
      reply.status(401).send({
        success: false,
        error: 'API key required',
      });
      return;
    }

    // Hash the provided key
    const crypto = await import('crypto');
    const keyHash = crypto.createHash('sha256').update(apiKey).digest('hex');

    // Find API key in database
    const keyRecord = await prisma.apiKey.findUnique({
      where: { keyHash },
      include: {
        user: {
          select: {
            id: true,
            email: true,
            isActive: true,
          },
        },
        workspace: true,
      },
    });

    if (!keyRecord) {
      reply.status(401).send({
        success: false,
        error: 'Invalid API key',
      });
      return;
    }

    // Check if key is active
    if (!keyRecord.isActive) {
      reply.status(401).send({
        success: false,
        error: 'API key is disabled',
      });
      return;
    }

    // Check if key has expired
    if (keyRecord.expiresAt && new Date() > keyRecord.expiresAt) {
      reply.status(401).send({
        success: false,
        error: 'API key has expired',
      });
      return;
    }

    // Check if user is active
    if (!keyRecord.user.isActive) {
      reply.status(401).send({
        success: false,
        error: 'User account is inactive',
      });
      return;
    }

    // Update last used timestamp
    await prisma.apiKey.update({
      where: { id: keyRecord.id },
      data: { lastUsedAt: new Date() },
    });

    // Attach user to request
    (request as AuthenticatedRequest).user = {
      userId: keyRecord.user.id,
      email: keyRecord.user.email,
      role: 'MEMBER',
      workspaceId: keyRecord.workspaceId,
    };
  } catch (error) {
    logger.error({ error }, 'API key authentication failed');
    reply.status(401).send({
      success: false,
      error: 'Authentication failed',
    });
  }
}

/**
 * Optional authentication - doesn't fail if no token provided
 */
export async function optionalAuth(
  request: FastifyRequest,
  reply: FastifyReply
): Promise<void> {
  try {
    const authHeader = request.headers.authorization;

    if (!authHeader?.startsWith('Bearer ')) {
      return;
    }

    const token = authHeader.substring(7);
    const decoded = await request.server.jwt.verify<TokenPayload>(token);

    const isBlacklisted = await cache.get(`blacklist:token:${token}`);
    if (isBlacklisted) {
      return;
    }

    (request as AuthenticatedRequest).user = decoded;
  } catch {
    // Silently ignore authentication errors for optional auth
  }
}
