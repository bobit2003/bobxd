/**
 * @fileoverview Workspace Routes
 * Workspace management and member operations
 */

import { FastifyInstance, FastifyRequest, FastifyReply } from 'fastify';
import { z } from 'zod';
import { prisma } from '@prisma/client';
import { logger } from '@utils/logger';
import { authenticateToken, AuthenticatedRequest, requireRoles } from '@middleware/auth';
import { createWorkspaceSchema, UserRole } from '@types/index';

/**
 * Workspace routes plugin
 */
export async function workspaceRoutes(fastify: FastifyInstance): Promise<void> {
  // Apply authentication to all routes
  fastify.addHook('preHandler', authenticateToken);

  // ==================== LIST WORKSPACES ====================

  fastify.get(
    '/',
    {
      schema: {
        description: 'List user workspaces',
        tags: ['Workspaces'],
      },
    },
    async (request: FastifyRequest, reply: FastifyReply) => {
      const user = (request as AuthenticatedRequest).user;

      const workspaces = await prisma.workspace.findMany({
        where: {
          members: {
            some: {
              userId: user.userId,
            },
          },
        },
        include: {
          members: {
            include: {
              user: {
                select: {
                  id: true,
                  email: true,
                  firstName: true,
                  lastName: true,
                  avatar: true,
                },
              },
            },
          },
          subscription: true,
          _count: {
            select: {
              leads: true,
              agents: true,
            },
          },
        },
      });

      return reply.send({
        success: true,
        data: workspaces.map((w) => ({
          id: w.id,
          name: w.name,
          slug: w.slug,
          description: w.description,
          logo: w.logo,
          isActive: w.isActive,
          ownerId: w.ownerId,
          memberCount: w.members.length,
          leadCount: w._count.leads,
          agentCount: w._count.agents,
          subscription: w.subscription,
          createdAt: w.createdAt,
          updatedAt: w.updatedAt,
        })),
      });
    }
  );

  // ==================== GET WORKSPACE ====================

  fastify.get(
    '/:workspaceId',
    {
      schema: {
        description: 'Get workspace details',
        tags: ['Workspaces'],
        params: {
          type: 'object',
          required: ['workspaceId'],
          properties: {
            workspaceId: { type: 'string' },
          },
        },
      },
    },
    async (request: FastifyRequest<{ Params: { workspaceId: string } }>, reply: FastifyReply) => {
      const { workspaceId } = request.params;
      const user = (request as AuthenticatedRequest).user;

      // Check membership
      const membership = await prisma.workspaceMember.findUnique({
        where: {
          userId_workspaceId: {
            userId: user.userId,
            workspaceId,
          },
        },
      });

      if (!membership && user.role !== 'SUPER_ADMIN') {
        return reply.status(403).send({
          success: false,
          error: 'Not a member of this workspace',
        });
      }

      const workspace = await prisma.workspace.findUnique({
        where: { id: workspaceId },
        include: {
          members: {
            include: {
              user: {
                select: {
                  id: true,
                  email: true,
                  firstName: true,
                  lastName: true,
                  avatar: true,
                },
              },
            },
          },
          subscription: true,
          _count: {
            select: {
              leads: true,
              agents: true,
            },
          },
        },
      });

      if (!workspace) {
        return reply.status(404).send({
          success: false,
          error: 'Workspace not found',
        });
      }

      return reply.send({
        success: true,
        data: {
          ...workspace,
          leadCount: workspace._count.leads,
          agentCount: workspace._count.agents,
        },
      });
    }
  );

  // ==================== CREATE WORKSPACE ====================

  fastify.post(
    '/',
    {
      schema: {
        description: 'Create new workspace',
        tags: ['Workspaces'],
        body: {
          type: 'object',
          required: ['name', 'slug'],
          properties: {
            name: { type: 'string', minLength: 1, maxLength: 100 },
            slug: { type: 'string', minLength: 3, maxLength: 50 },
            description: { type: 'string' },
          },
        },
      },
    },
    async (request: FastifyRequest<{ Body: { name: string; slug: string; description?: string } }>, reply: FastifyReply) => {
      const user = (request as AuthenticatedRequest).user;
      const { name, slug, description } = request.body;

      // Validate slug format
      if (!/^[a-z0-9-]+$/.test(slug)) {
        return reply.status(400).send({
          success: false,
          error: 'Slug must contain only lowercase letters, numbers, and hyphens',
        });
      }

      // Check if slug is taken
      const existing = await prisma.workspace.findUnique({
        where: { slug },
      });

      if (existing) {
        return reply.status(409).send({
          success: false,
          error: 'Workspace slug already taken',
        });
      }

      const workspace = await prisma.workspace.create({
        data: {
          name,
          slug,
          description,
          ownerId: user.userId,
          members: {
            create: {
              userId: user.userId,
              role: 'ADMIN',
            },
          },
        },
        include: {
          members: {
            include: {
              user: {
                select: {
                  id: true,
                  email: true,
                  firstName: true,
                  lastName: true,
                },
              },
            },
          },
        },
      });

      // Create trial subscription
      await prisma.subscription.create({
        data: {
          workspaceId: workspace.id,
          plan: 'STARTER',
          status: 'TRIAL',
          currentPeriodStart: new Date(),
          currentPeriodEnd: new Date(Date.now() + 14 * 24 * 60 * 60 * 1000),
          trialEndsAt: new Date(Date.now() + 14 * 24 * 60 * 60 * 1000),
          features: ['basic_agents', 'lead_management', 'email_support'],
        },
      });

      logger.info({ workspaceId: workspace.id, userId: user.userId }, 'Workspace created');

      return reply.status(201).send({
        success: true,
        data: workspace,
      });
    }
  );

  // ==================== UPDATE WORKSPACE ====================

  fastify.patch(
    '/:workspaceId',
    {
      schema: {
        description: 'Update workspace',
        tags: ['Workspaces'],
        params: {
          type: 'object',
          required: ['workspaceId'],
          properties: {
            workspaceId: { type: 'string' },
          },
        },
        body: {
          type: 'object',
          properties: {
            name: { type: 'string', minLength: 1 },
            description: { type: 'string' },
            logo: { type: 'string' },
            settings: { type: 'object' },
          },
        },
      },
    },
    async (request: FastifyRequest<{ Params: { workspaceId: string }; Body: { name?: string; description?: string; logo?: string; settings?: Record<string, unknown> } }>, reply: FastifyReply) => {
      const { workspaceId } = request.params;
      const user = (request as AuthenticatedRequest).user;

      // Check permissions
      const membership = await prisma.workspaceMember.findUnique({
        where: {
          userId_workspaceId: {
            userId: user.userId,
            workspaceId,
          },
        },
      });

      if (!membership || (membership.role !== 'ADMIN' && user.role !== 'SUPER_ADMIN')) {
        return reply.status(403).send({
          success: false,
          error: 'Insufficient permissions',
        });
      }

      const workspace = await prisma.workspace.update({
        where: { id: workspaceId },
        data: request.body,
      });

      logger.info({ workspaceId }, 'Workspace updated');

      return reply.send({
        success: true,
        data: workspace,
      });
    }
  );

  // ==================== ADD MEMBER ====================

  fastify.post(
    '/:workspaceId/members',
    {
      schema: {
        description: 'Add member to workspace',
        tags: ['Workspaces'],
        params: {
          type: 'object',
          required: ['workspaceId'],
          properties: {
            workspaceId: { type: 'string' },
          },
        },
        body: {
          type: 'object',
          required: ['email', 'role'],
          properties: {
            email: { type: 'string', format: 'email' },
            role: { type: 'string', enum: ['ADMIN', 'MANAGER', 'MEMBER', 'VIEWER'] },
          },
        },
      },
    },
    async (request: FastifyRequest<{ Params: { workspaceId: string }; Body: { email: string; role: string } }>, reply: FastifyReply) => {
      const { workspaceId } = request.params;
      const { email, role } = request.body;
      const user = (request as AuthenticatedRequest).user;

      // Check permissions
      const membership = await prisma.workspaceMember.findUnique({
        where: {
          userId_workspaceId: {
            userId: user.userId,
            workspaceId,
          },
        },
      });

      if (!membership || (membership.role !== 'ADMIN' && user.role !== 'SUPER_ADMIN')) {
        return reply.status(403).send({
          success: false,
          error: 'Insufficient permissions',
        });
      }

      // Find user by email
      const targetUser = await prisma.user.findUnique({
        where: { email },
      });

      if (!targetUser) {
        return reply.status(404).send({
          success: false,
          error: 'User not found',
        });
      }

      // Check if already a member
      const existingMember = await prisma.workspaceMember.findUnique({
        where: {
          userId_workspaceId: {
            userId: targetUser.id,
            workspaceId,
          },
        },
      });

      if (existingMember) {
        return reply.status(409).send({
          success: false,
          error: 'User is already a member of this workspace',
        });
      }

      const newMember = await prisma.workspaceMember.create({
        data: {
          userId: targetUser.id,
          workspaceId,
          role: role as any,
        },
        include: {
          user: {
            select: {
              id: true,
              email: true,
              firstName: true,
              lastName: true,
              avatar: true,
            },
          },
        },
      });

      logger.info({ workspaceId, userId: targetUser.id }, 'Member added to workspace');

      return reply.status(201).send({
        success: true,
        data: newMember,
      });
    }
  );

  // ==================== REMOVE MEMBER ====================

  fastify.delete(
    '/:workspaceId/members/:userId',
    {
      schema: {
        description: 'Remove member from workspace',
        tags: ['Workspaces'],
        params: {
          type: 'object',
          required: ['workspaceId', 'userId'],
          properties: {
            workspaceId: { type: 'string' },
            userId: { type: 'string' },
          },
        },
      },
    },
    async (request: FastifyRequest<{ Params: { workspaceId: string; userId: string } }>, reply: FastifyReply) => {
      const { workspaceId, userId: targetUserId } = request.params;
      const user = (request as AuthenticatedRequest).user;

      // Check permissions
      const membership = await prisma.workspaceMember.findUnique({
        where: {
          userId_workspaceId: {
            userId: user.userId,
            workspaceId,
          },
        },
      });

      if (!membership || (membership.role !== 'ADMIN' && user.role !== 'SUPER_ADMIN')) {
        return reply.status(403).send({
          success: false,
          error: 'Insufficient permissions',
        });
      }

      // Cannot remove owner
      const workspace = await prisma.workspace.findUnique({
        where: { id: workspaceId },
      });

      if (workspace?.ownerId === targetUserId) {
        return reply.status(400).send({
          success: false,
          error: 'Cannot remove workspace owner',
        });
      }

      await prisma.workspaceMember.delete({
        where: {
          userId_workspaceId: {
            userId: targetUserId,
            workspaceId,
          },
        },
      });

      logger.info({ workspaceId, userId: targetUserId }, 'Member removed from workspace');

      return reply.send({
        success: true,
        message: 'Member removed successfully',
      });
    }
  );

  // ==================== DELETE WORKSPACE ====================

  fastify.delete(
    '/:workspaceId',
    {
      schema: {
        description: 'Delete workspace',
        tags: ['Workspaces'],
        params: {
          type: 'object',
          required: ['workspaceId'],
          properties: {
            workspaceId: { type: 'string' },
          },
        },
      },
    },
    async (request: FastifyRequest<{ Params: { workspaceId: string } }>, reply: FastifyReply) => {
      const { workspaceId } = request.params;
      const user = (request as AuthenticatedRequest).user;

      // Check permissions (only owner or super admin)
      const workspace = await prisma.workspace.findUnique({
        where: { id: workspaceId },
      });

      if (!workspace) {
        return reply.status(404).send({
          success: false,
          error: 'Workspace not found',
        });
      }

      if (workspace.ownerId !== user.userId && user.role !== 'SUPER_ADMIN') {
        return reply.status(403).send({
          success: false,
          error: 'Only workspace owner can delete',
        });
      }

      await prisma.workspace.delete({
        where: { id: workspaceId },
      });

      logger.info({ workspaceId }, 'Workspace deleted');

      return reply.send({
        success: true,
        message: 'Workspace deleted successfully',
      });
    }
  );
}

export default workspaceRoutes;
