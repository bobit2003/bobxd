/**
 * @fileoverview Leads Routes
 * Lead management and tracking
 */

import { FastifyInstance, FastifyRequest, FastifyReply } from 'fastify';
import { z } from 'zod';
import { prisma } from '@prisma/client';
import { logger } from '@utils/logger';
import { authenticateToken, AuthenticatedRequest } from '@middleware/auth';
import { createLeadSchema, LeadStatus } from '@types/index';

/**
 * Lead routes plugin
 */
export async function leadRoutes(fastify: FastifyInstance): Promise<void> {
  // Apply authentication to all routes
  fastify.addHook('preHandler', authenticateToken);

  // ==================== LIST LEADS ====================

  fastify.get(
    '/workspace/:workspaceId',
    {
      schema: {
        description: 'List workspace leads',
        tags: ['Leads'],
        params: {
          type: 'object',
          required: ['workspaceId'],
          properties: {
            workspaceId: { type: 'string' },
          },
        },
        querystring: {
          type: 'object',
          properties: {
            status: { type: 'string' },
            source: { type: 'string' },
            search: { type: 'string' },
            page: { type: 'string', default: '1' },
            limit: { type: 'string', default: '20' },
            sortBy: { type: 'string', default: 'createdAt' },
            sortOrder: { type: 'string', default: 'desc' },
          },
        },
      },
    },
    async (request: FastifyRequest<{
      Params: { workspaceId: string };
      Querystring: {
        status?: string;
        source?: string;
        search?: string;
        page?: string;
        limit?: string;
        sortBy?: string;
        sortOrder?: string;
      };
    }>, reply: FastifyReply) => {
      const { workspaceId } = request.params;
      const user = (request as AuthenticatedRequest).user;
      const { status, source, search, page = '1', limit = '20', sortBy = 'createdAt', sortOrder = 'desc' } = request.query;

      // Check membership
      const membership = await prisma.workspaceMember.findUnique({
        where: {
          userId_workspaceId: {
            userId: user.userId,
            workspaceId,
          },
        },
      });

      if (!membership && user.role !== 'SUPER_ADMIN') {
        return reply.status(403).send({
          success: false,
          error: 'Not a member of this workspace',
        });
      }

      const pageNum = parseInt(page, 10);
      const limitNum = parseInt(limit, 10);
      const skip = (pageNum - 1) * limitNum;

      // Build where clause
      const where: any = { workspaceId };

      if (status) {
        where.status = status;
      }

      if (source) {
        where.source = source;
      }

      if (search) {
        where.OR = [
          { firstName: { contains: search, mode: 'insensitive' } },
          { lastName: { contains: search, mode: 'insensitive' } },
          { email: { contains: search, mode: 'insensitive' } },
          { company: { contains: search, mode: 'insensitive' } },
        ];
      }

      const [leads, total] = await Promise.all([
        prisma.lead.findMany({
          where,
          skip,
          take: limitNum,
          orderBy: { [sortBy]: sortOrder },
          include: {
            activities: {
              orderBy: { createdAt: 'desc' },
              take: 3,
            },
            _count: {
              select: {
                activities: true,
              },
            },
          },
        }),
        prisma.lead.count({ where }),
      ]);

      return reply.send({
        success: true,
        data: {
          leads,
          pagination: {
            page: pageNum,
            limit: limitNum,
            total,
            totalPages: Math.ceil(total / limitNum),
          },
        },
      });
    }
  );

  // ==================== GET LEAD ====================

  fastify.get(
    '/:leadId',
    {
      schema: {
        description: 'Get lead details',
        tags: ['Leads'],
        params: {
          type: 'object',
          required: ['leadId'],
          properties: {
            leadId: { type: 'string' },
          },
        },
      },
    },
    async (request: FastifyRequest<{ Params: { leadId: string } }>, reply: FastifyReply) => {
      const { leadId } = request.params;
      const user = (request as AuthenticatedRequest).user;

      const lead = await prisma.lead.findUnique({
        where: { id: leadId },
        include: {
          activities: {
            orderBy: { createdAt: 'desc' },
            include: {
              agent: {
                select: {
                  id: true,
                  name: true,
                  type: true,
                },
              },
            },
          },
          workspace: {
            select: {
              id: true,
              name: true,
            },
          },
        },
      });

      if (!lead) {
        return reply.status(404).send({
          success: false,
          error: 'Lead not found',
        });
      }

      // Check membership
      const membership = await prisma.workspaceMember.findUnique({
        where: {
          userId_workspaceId: {
            userId: user.userId,
            workspaceId: lead.workspaceId,
          },
        },
      });

      if (!membership && user.role !== 'SUPER_ADMIN') {
        return reply.status(403).send({
          success: false,
          error: 'Not authorized to view this lead',
        });
      }

      return reply.send({
        success: true,
        data: lead,
      });
    }
  );

  // ==================== CREATE LEAD ====================

  fastify.post(
    '/workspace/:workspaceId',
    {
      schema: {
        description: 'Create new lead',
        tags: ['Leads'],
        params: {
          type: 'object',
          required: ['workspaceId'],
          properties: {
            workspaceId: { type: 'string' },
          },
        },
        body: {
          type: 'object',
          required: ['firstName', 'lastName', 'email', 'source'],
          properties: {
            firstName: { type: 'string', minLength: 1 },
            lastName: { type: 'string', minLength: 1 },
            email: { type: 'string', format: 'email' },
            phone: { type: 'string' },
            company: { type: 'string' },
            title: { type: 'string' },
            source: { type: 'string' },
            tags: { type: 'array', items: { type: 'string' } },
            notes: { type: 'string' },
            customFields: { type: 'object' },
          },
        },
      },
    },
    async (request: FastifyRequest<{
      Params: { workspaceId: string };
      Body: {
        firstName: string;
        lastName: string;
        email: string;
        phone?: string;
        company?: string;
        title?: string;
        source: string;
        tags?: string[];
        notes?: string;
        customFields?: Record<string, unknown>;
      };
    }>, reply: FastifyReply) => {
      const { workspaceId } = request.params;
      const user = (request as AuthenticatedRequest).user;

      // Check membership and permissions
      const membership = await prisma.workspaceMember.findUnique({
        where: {
          userId_workspaceId: {
            userId: user.userId,
            workspaceId,
          },
        },
      });

      if (!membership && user.role !== 'SUPER_ADMIN') {
        return reply.status(403).send({
          success: false,
          error: 'Not a member of this workspace',
        });
      }

      // Validate input
      const validated = createLeadSchema.parse(request.body);

      // Check for duplicate email in workspace
      const existingLead = await prisma.lead.findFirst({
        where: {
          workspaceId,
          email: validated.email,
        },
      });

      if (existingLead) {
        return reply.status(409).send({
          success: false,
          error: 'Lead with this email already exists in workspace',
        });
      }

      const lead = await prisma.lead.create({
        data: {
          ...validated,
          workspaceId,
        },
        include: {
          activities: true,
        },
      });

      // Create activity log
      await prisma.leadActivity.create({
        data: {
          leadId: lead.id,
          type: 'LEAD_CREATED',
          description: 'Lead created manually',
          metadata: { createdBy: user.userId },
        },
      });

      logger.info({ leadId: lead.id, workspaceId }, 'Lead created');

      return reply.status(201).send({
        success: true,
        data: lead,
      });
    }
  );

  // ==================== UPDATE LEAD ====================

  fastify.patch(
    '/:leadId',
    {
      schema: {
        description: 'Update lead',
        tags: ['Leads'],
        params: {
          type: 'object',
          required: ['leadId'],
          properties: {
            leadId: { type: 'string' },
          },
        },
        body: {
          type: 'object',
          properties: {
            firstName: { type: 'string', minLength: 1 },
            lastName: { type: 'string', minLength: 1 },
            email: { type: 'string', format: 'email' },
            phone: { type: 'string' },
            company: { type: 'string' },
            title: { type: 'string' },
            status: { type: 'string' },
            score: { type: 'number' },
            tags: { type: 'array', items: { type: 'string' } },
            notes: { type: 'string' },
            customFields: { type: 'object' },
          },
        },
      },
    },
    async (request: FastifyRequest<{
      Params: { leadId: string };
      Body: Partial<{
        firstName: string;
        lastName: string;
        email: string;
        phone: string;
        company: string;
        title: string;
        status: string;
        score: number;
        tags: string[];
        notes: string;
        customFields: Record<string, unknown>;
      }>;
    }>, reply: FastifyReply) => {
      const { leadId } = request.params;
      const user = (request as AuthenticatedRequest).user;

      const lead = await prisma.lead.findUnique({
        where: { id: leadId },
      });

      if (!lead) {
        return reply.status(404).send({
          success: false,
          error: 'Lead not found',
        });
      }

      // Check membership
      const membership = await prisma.workspaceMember.findUnique({
        where: {
          userId_workspaceId: {
            userId: user.userId,
            workspaceId: lead.workspaceId,
          },
        },
      });

      if (!membership && user.role !== 'SUPER_ADMIN') {
        return reply.status(403).send({
          success: false,
          error: 'Not authorized to update this lead',
        });
      }

      const oldStatus = lead.status;
      const updatedLead = await prisma.lead.update({
        where: { id: leadId },
        data: {
          ...request.body,
          updatedAt: new Date(),
        },
      });

      // Create activity log if status changed
      if (request.body.status && request.body.status !== oldStatus) {
        await prisma.leadActivity.create({
          data: {
            leadId,
            type: 'STATUS_CHANGED',
            description: `Status changed from ${oldStatus} to ${request.body.status}`,
            metadata: {
              oldStatus,
              newStatus: request.body.status,
              updatedBy: user.userId,
            },
          },
        });
      }

      logger.info({ leadId }, 'Lead updated');

      return reply.send({
        success: true,
        data: updatedLead,
      });
    }
  );

  // ==================== DELETE LEAD ====================

  fastify.delete(
    '/:leadId',
    {
      schema: {
        description: 'Delete lead',
        tags: ['Leads'],
        params: {
          type: 'object',
          required: ['leadId'],
          properties: {
            leadId: { type: 'string' },
          },
        },
      },
    },
    async (request: FastifyRequest<{ Params: { leadId: string } }>, reply: FastifyReply) => {
      const { leadId } = request.params;
      const user = (request as AuthenticatedRequest).user;

      const lead = await prisma.lead.findUnique({
        where: { id: leadId },
      });

      if (!lead) {
        return reply.status(404).send({
          success: false,
          error: 'Lead not found',
        });
      }

      // Check permissions (admin or manager only)
      const membership = await prisma.workspaceMember.findUnique({
        where: {
          userId_workspaceId: {
            userId: user.userId,
            workspaceId: lead.workspaceId,
          },
        },
      });

      if (
        !membership ||
        (membership.role !== 'ADMIN' && membership.role !== 'MANAGER' && user.role !== 'SUPER_ADMIN')
      ) {
        return reply.status(403).send({
          success: false,
          error: 'Insufficient permissions',
        });
      }

      await prisma.lead.delete({
        where: { id: leadId },
      });

      logger.info({ leadId }, 'Lead deleted');

      return reply.send({
        success: true,
        message: 'Lead deleted successfully',
      });
    }
  );

  // ==================== BULK IMPORT ====================

  fastify.post(
    '/workspace/:workspaceId/import',
    {
      schema: {
        description: 'Bulk import leads',
        tags: ['Leads'],
        params: {
          type: 'object',
          required: ['workspaceId'],
          properties: {
            workspaceId: { type: 'string' },
          },
        },
        body: {
          type: 'object',
          required: ['leads'],
          properties: {
            leads: {
              type: 'array',
              items: {
                type: 'object',
                required: ['firstName', 'lastName', 'email', 'source'],
                properties: {
                  firstName: { type: 'string' },
                  lastName: { type: 'string' },
                  email: { type: 'string' },
                  phone: { type: 'string' },
                  company: { type: 'string' },
                  title: { type: 'string' },
                  source: { type: 'string' },
                },
              },
            },
          },
        },
      },
    },
    async (request: FastifyRequest<{
      Params: { workspaceId: string };
      Body: { leads: Array<{
        firstName: string;
        lastName: string;
        email: string;
        phone?: string;
        company?: string;
        title?: string;
        source: string;
      }> };
    }>, reply: FastifyReply) => {
      const { workspaceId } = request.params;
      const { leads } = request.body;
      const user = (request as AuthenticatedRequest).user;

      // Check membership and permissions
      const membership = await prisma.workspaceMember.findUnique({
        where: {
          userId_workspaceId: {
            userId: user.userId,
            workspaceId,
          },
        },
      });

      if (
        !membership ||
        (membership.role !== 'ADMIN' && membership.role !== 'MANAGER' && user.role !== 'SUPER_ADMIN')
      ) {
        return reply.status(403).send({
          success: false,
          error: 'Insufficient permissions',
        });
      }

      const results = {
        created: 0,
        skipped: 0,
        errors: [] as string[],
      };

      for (const leadData of leads) {
        try {
          // Check for duplicate
          const existing = await prisma.lead.findFirst({
            where: {
              workspaceId,
              email: leadData.email,
            },
          });

          if (existing) {
            results.skipped++;
            continue;
          }

          await prisma.lead.create({
            data: {
              ...leadData,
              workspaceId,
            },
          });

          results.created++;
        } catch (error) {
          results.errors.push(`Failed to import ${leadData.email}: ${(error as Error).message}`);
        }
      }

      logger.info({ workspaceId, results }, 'Bulk import completed');

      return reply.send({
        success: true,
        data: results,
      });
    }
  );
}

export default leadRoutes;
