/**
 * @fileoverview Agent Routes
 * AI agent management and execution
 */

import { FastifyInstance, FastifyRequest, FastifyReply } from 'fastify';
import { z } from 'zod';
import { prisma } from '@prisma/client';
import { logger } from '@utils/logger';
import { authenticateToken, AuthenticatedRequest } from '@middleware/auth';
import { openclawService } from '@services/openclaw.service';
import { createAgentSchema, executeAgentSchema, PLAN_LIMITS } from '@types/index';

/**
 * Agent routes plugin
 */
export async function agentRoutes(fastify: FastifyInstance): Promise<void> {
  // Apply authentication to all routes
  fastify.addHook('preHandler', authenticateToken);

  // ==================== LIST AGENTS ====================

  fastify.get(
    '/workspace/:workspaceId',
    {
      schema: {
        description: 'List workspace agents',
        tags: ['Agents'],
        params: {
          type: 'object',
          required: ['workspaceId'],
          properties: {
            workspaceId: { type: 'string' },
          },
        },
        querystring: {
          type: 'object',
          properties: {
            status: { type: 'string' },
            type: { type: 'string' },
          },
        },
      },
    },
    async (request: FastifyRequest<{
      Params: { workspaceId: string };
      Querystring: { status?: string; type?: string };
    }>, reply: FastifyReply) => {
      const { workspaceId } = request.params;
      const { status, type } = request.query;
      const user = (request as AuthenticatedRequest).user;

      // Check membership
      const membership = await prisma.workspaceMember.findUnique({
        where: {
          userId_workspaceId: {
            userId: user.userId,
            workspaceId,
          },
        },
      });

      if (!membership && user.role !== 'SUPER_ADMIN') {
        return reply.status(403).send({
          success: false,
          error: 'Not a member of this workspace',
        });
      }

      const where: any = { workspaceId };
      if (status) where.status = status;
      if (type) where.type = type;

      const agents = await prisma.agent.findMany({
        where,
        include: {
          _count: {
            select: {
              executions: true,
            },
          },
        },
        orderBy: { createdAt: 'desc' },
      });

      // Get recent executions for each agent
      const agentsWithExecutions = await Promise.all(
        agents.map(async (agent) => {
          const recentExecutions = await prisma.agentExecution.findMany({
            where: { agentId: agent.id },
            orderBy: { createdAt: 'desc' },
            take: 5,
          });

          return {
            ...agent,
            recentExecutions,
          };
        })
      );

      return reply.send({
        success: true,
        data: agentsWithExecutions,
      });
    }
  );

  // ==================== GET AGENT ====================

  fastify.get(
    '/:agentId',
    {
      schema: {
        description: 'Get agent details',
        tags: ['Agents'],
        params: {
          type: 'object',
          required: ['agentId'],
          properties: {
            agentId: { type: 'string' },
          },
        },
      },
    },
    async (request: FastifyRequest<{ Params: { agentId: string } }>, reply: FastifyReply) => {
      const { agentId } = request.params;
      const user = (request as AuthenticatedRequest).user;

      const agent = await prisma.agent.findUnique({
        where: { id: agentId },
        include: {
          workspace: {
            select: {
              id: true,
              name: true,
            },
          },
        },
      });

      if (!agent) {
        return reply.status(404).send({
          success: false,
          error: 'Agent not found',
        });
      }

      // Check membership
      const membership = await prisma.workspaceMember.findUnique({
        where: {
          userId_workspaceId: {
            userId: user.userId,
            workspaceId: agent.workspaceId,
          },
        },
      });

      if (!membership && user.role !== 'SUPER_ADMIN') {
        return reply.status(403).send({
          success: false,
          error: 'Not authorized to view this agent',
        });
      }

      // Get execution stats
      const executionStats = await prisma.agentExecution.groupBy({
        by: ['status'],
        where: { agentId },
        _count: {
          status: true,
        },
      });

      return reply.send({
        success: true,
        data: {
          ...agent,
          executionStats,
        },
      });
    }
  );

  // ==================== CREATE AGENT ====================

  fastify.post(
    '/workspace/:workspaceId',
    {
      schema: {
        description: 'Create new agent',
        tags: ['Agents'],
        params: {
          type: 'object',
          required: ['workspaceId'],
          properties: {
            workspaceId: { type: 'string' },
          },
        },
        body: {
          type: 'object',
          required: ['name', 'type', 'systemPrompt'],
          properties: {
            name: { type: 'string', minLength: 1, maxLength: 100 },
            description: { type: 'string' },
            type: { type: 'string' },
            systemPrompt: { type: 'string', minLength: 1 },
            configuration: { type: 'object' },
            tokenLimit: { type: 'number' },
            executionLimit: { type: 'number' },
            memoryEnabled: { type: 'boolean' },
          },
        },
      },
    },
    async (request: FastifyRequest<{
      Params: { workspaceId: string };
      Body: {
        name: string;
        description?: string;
        type: string;
        systemPrompt: string;
        configuration?: Record<string, unknown>;
        tokenLimit?: number;
        executionLimit?: number;
        memoryEnabled?: boolean;
      };
    }>, reply: FastifyReply) => {
      const { workspaceId } = request.params;
      const user = (request as AuthenticatedRequest).user;

      // Check membership and permissions
      const membership = await prisma.workspaceMember.findUnique({
        where: {
          userId_workspaceId: {
            userId: user.userId,
            workspaceId,
          },
        },
      });

      if (
        !membership ||
        (membership.role !== 'ADMIN' && membership.role !== 'MANAGER' && user.role !== 'SUPER_ADMIN')
      ) {
        return reply.status(403).send({
          success: false,
          error: 'Insufficient permissions',
        });
      }

      // Validate input
      const validated = createAgentSchema.parse(request.body);

      // Check agent limit based on subscription
      const subscription = await prisma.subscription.findUnique({
        where: { workspaceId },
      });

      const plan = subscription?.plan || 'STARTER';
      const maxAgents = PLAN_LIMITS[plan].maxAgents;

      const currentAgentCount = await prisma.agent.count({
        where: { workspaceId },
      });

      if (currentAgentCount >= maxAgents) {
        return reply.status(403).send({
          success: false,
          error: `Agent limit reached for ${plan} plan. Upgrade to add more agents.`,
        });
      }

      // Create agent in database
      const agent = await prisma.agent.create({
        data: {
          ...validated,
          workspaceId,
        },
      });

      // Create agent in OpenClaw
      const openclawResult = await openclawService.createAgent(agent);

      if (!openclawResult.success) {
        // Rollback if OpenClaw creation failed
        await prisma.agent.delete({
          where: { id: agent.id },
        });

        return reply.status(500).send({
          success: false,
          error: `Failed to create agent in OpenClaw: ${openclawResult.error}`,
        });
      }

      logger.info({ agentId: agent.id, workspaceId }, 'Agent created');

      return reply.status(201).send({
        success: true,
        data: agent,
      });
    }
  );

  // ==================== UPDATE AGENT ====================

  fastify.patch(
    '/:agentId',
    {
      schema: {
        description: 'Update agent',
        tags: ['Agents'],
        params: {
          type: 'object',
          required: ['agentId'],
          properties: {
            agentId: { type: 'string' },
          },
        },
        body: {
          type: 'object',
          properties: {
            name: { type: 'string' },
            description: { type: 'string' },
            systemPrompt: { type: 'string' },
            configuration: { type: 'object' },
            status: { type: 'string' },
            tokenLimit: { type: 'number' },
            executionLimit: { type: 'number' },
            isEnabled: { type: 'boolean' },
            memoryEnabled: { type: 'boolean' },
          },
        },
      },
    },
    async (request: FastifyRequest<{
      Params: { agentId: string };
      Body: Partial<{
        name: string;
        description: string;
        systemPrompt: string;
        configuration: Record<string, unknown>;
        status: string;
        tokenLimit: number;
        executionLimit: number;
        isEnabled: boolean;
        memoryEnabled: boolean;
      }>;
    }>, reply: FastifyReply) => {
      const { agentId } = request.params;
      const user = (request as AuthenticatedRequest).user;

      const agent = await prisma.agent.findUnique({
        where: { id: agentId },
      });

      if (!agent) {
        return reply.status(404).send({
          success: false,
          error: 'Agent not found',
        });
      }

      // Check membership and permissions
      const membership = await prisma.workspaceMember.findUnique({
        where: {
          userId_workspaceId: {
            userId: user.userId,
            workspaceId: agent.workspaceId,
          },
        },
      });

      if (
        !membership ||
        (membership.role !== 'ADMIN' && membership.role !== 'MANAGER' && user.role !== 'SUPER_ADMIN')
      ) {
        return reply.status(403).send({
          success: false,
          error: 'Insufficient permissions',
        });
      }

      // Update in database
      const updatedAgent = await prisma.agent.update({
        where: { id: agentId },
        data: request.body,
      });

      // Update in OpenClaw
      await openclawService.updateAgent(updatedAgent);

      logger.info({ agentId }, 'Agent updated');

      return reply.send({
        success: true,
        data: updatedAgent,
      });
    }
  );

  // ==================== DELETE AGENT ====================

  fastify.delete(
    '/:agentId',
    {
      schema: {
        description: 'Delete agent',
        tags: ['Agents'],
        params: {
          type: 'object',
          required: ['agentId'],
          properties: {
            agentId: { type: 'string' },
          },
        },
      },
    },
    async (request: FastifyRequest<{ Params: { agentId: string } }>, reply: FastifyReply) => {
      const { agentId } = request.params;
      const user = (request as AuthenticatedRequest).user;

      const agent = await prisma.agent.findUnique({
        where: { id: agentId },
      });

      if (!agent) {
        return reply.status(404).send({
          success: false,
          error: 'Agent not found',
        });
      }

      // Check permissions (admin only)
      const membership = await prisma.workspaceMember.findUnique({
        where: {
          userId_workspaceId: {
            userId: user.userId,
            workspaceId: agent.workspaceId,
          },
        },
      });

      if (!membership || (membership.role !== 'ADMIN' && user.role !== 'SUPER_ADMIN')) {
        return reply.status(403).send({
          success: false,
          error: 'Insufficient permissions',
        });
      }

      // Delete from OpenClaw
      await openclawService.deleteAgent(agentId);

      // Delete from database
      await prisma.agent.delete({
        where: { id: agentId },
      });

      logger.info({ agentId }, 'Agent deleted');

      return reply.send({
        success: true,
        message: 'Agent deleted successfully',
      });
    }
  );

  // ==================== EXECUTE AGENT ====================

  fastify.post(
    '/:agentId/execute',
    {
      schema: {
        description: 'Execute agent task',
        tags: ['Agents'],
        params: {
          type: 'object',
          required: ['agentId'],
          properties: {
            agentId: { type: 'string' },
          },
        },
        body: {
          type: 'object',
          required: ['taskType', 'input'],
          properties: {
            taskType: { type: 'string' },
            input: { type: 'object' },
            scheduledAt: { type: 'string' },
          },
        },
      },
    },
    async (request: FastifyRequest<{
      Params: { agentId: string };
      Body: {
        taskType: string;
        input: Record<string, unknown>;
        scheduledAt?: string;
      };
    }>, reply: FastifyReply) => {
      const { agentId } = request.params;
      const { taskType, input, scheduledAt } = request.body;
      const user = (request as AuthenticatedRequest).user;

      const agent = await prisma.agent.findUnique({
        where: { id: agentId },
        include: {
          workspace: {
            include: {
              subscription: true,
            },
          },
        },
      });

      if (!agent) {
        return reply.status(404).send({
          success: false,
          error: 'Agent not found',
        });
      }

      // Check membership
      const membership = await prisma.workspaceMember.findUnique({
        where: {
          userId_workspaceId: {
            userId: user.userId,
            workspaceId: agent.workspaceId,
          },
        },
      });

      if (!membership && user.role !== 'SUPER_ADMIN') {
        return reply.status(403).send({
          success: false,
          error: 'Not authorized to execute this agent',
        });
      }

      // Check quota
      const quotaCheck = await openclawService.checkAgentQuota(agentId);
      if (!quotaCheck.canExecute) {
        return reply.status(403).send({
          success: false,
          error: quotaCheck.reason,
        });
      }

      // Queue the task
      const task = await openclawService.queueTask({
        id: `task_${Date.now()}`,
        agentId,
        type: taskType,
        input,
        priority: 5,
        scheduledAt: scheduledAt ? new Date(scheduledAt) : undefined,
      });

      logger.info({ taskId: task.id, agentId, taskType }, 'Agent task queued');

      return reply.send({
        success: true,
        data: {
          taskId: task.id,
          status: 'queued',
          message: scheduledAt ? 'Task scheduled' : 'Task queued for execution',
        },
      });
    }
  );

  // ==================== GET EXECUTION LOGS ====================

  fastify.get(
    '/:agentId/executions',
    {
      schema: {
        description: 'Get agent execution logs',
        tags: ['Agents'],
        params: {
          type: 'object',
          required: ['agentId'],
          properties: {
            agentId: { type: 'string' },
          },
        },
        querystring: {
          type: 'object',
          properties: {
            page: { type: 'string', default: '1' },
            limit: { type: 'string', default: '20' },
            status: { type: 'string' },
          },
        },
      },
    },
    async (request: FastifyRequest<{
      Params: { agentId: string };
      Querystring: { page?: string; limit?: string; status?: string };
    }>, reply: FastifyReply) => {
      const { agentId } = request.params;
      const { page = '1', limit = '20', status } = request.query;
      const user = (request as AuthenticatedRequest).user;

      const agent = await prisma.agent.findUnique({
        where: { id: agentId },
      });

      if (!agent) {
        return reply.status(404).send({
          success: false,
          error: 'Agent not found',
        });
      }

      // Check membership
      const membership = await prisma.workspaceMember.findUnique({
        where: {
          userId_workspaceId: {
            userId: user.userId,
            workspaceId: agent.workspaceId,
          },
        },
      });

      if (!membership && user.role !== 'SUPER_ADMIN') {
        return reply.status(403).send({
          success: false,
          error: 'Not authorized to view this agent',
        });
      }

      const pageNum = parseInt(page, 10);
      const limitNum = parseInt(limit, 10);
      const skip = (pageNum - 1) * limitNum;

      const where: any = { agentId };
      if (status) where.status = status;

      const [executions, total] = await Promise.all([
        prisma.agentExecution.findMany({
          where,
          skip,
          take: limitNum,
          orderBy: { createdAt: 'desc' },
        }),
        prisma.agentExecution.count({ where }),
      ]);

      return reply.send({
        success: true,
        data: {
          executions,
          pagination: {
            page: pageNum,
            limit: limitNum,
            total,
            totalPages: Math.ceil(total / limitNum),
          },
        },
      });
    }
  );

  // ==================== TOGGLE AGENT STATUS ====================

  fastify.post(
    '/:agentId/toggle',
    {
      schema: {
        description: 'Toggle agent enabled status',
        tags: ['Agents'],
        params: {
          type: 'object',
          required: ['agentId'],
          properties: {
            agentId: { type: 'string' },
          },
        },
      },
    },
    async (request: FastifyRequest<{ Params: { agentId: string } }>, reply: FastifyReply) => {
      const { agentId } = request.params;
      const user = (request as AuthenticatedRequest).user;

      const agent = await prisma.agent.findUnique({
        where: { id: agentId },
      });

      if (!agent) {
        return reply.status(404).send({
          success: false,
          error: 'Agent not found',
        });
      }

      // Check permissions
      const membership = await prisma.workspaceMember.findUnique({
        where: {
          userId_workspaceId: {
            userId: user.userId,
            workspaceId: agent.workspaceId,
          },
        },
      });

      if (
        !membership ||
        (membership.role !== 'ADMIN' && membership.role !== 'MANAGER' && user.role !== 'SUPER_ADMIN')
      ) {
        return reply.status(403).send({
          success: false,
          error: 'Insufficient permissions',
        });
      }

      const updatedAgent = await prisma.agent.update({
        where: { id: agentId },
        data: {
          isEnabled: !agent.isEnabled,
          status: agent.isEnabled ? 'PAUSED' : 'ACTIVE',
        },
      });

      // Update in OpenClaw
      await openclawService.updateAgent(updatedAgent);

      logger.info({ agentId, isEnabled: updatedAgent.isEnabled }, 'Agent toggled');

      return reply.send({
        success: true,
        data: updatedAgent,
      });
    }
  );
}

export default agentRoutes;
