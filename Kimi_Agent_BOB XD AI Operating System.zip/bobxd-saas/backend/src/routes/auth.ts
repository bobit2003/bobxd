/**
 * @fileoverview Authentication Routes
 * User registration, login, token refresh, and logout
 */

import { FastifyInstance, FastifyRequest, FastifyReply } from 'fastify';
import bcrypt from 'bcryptjs';
import { prisma } from '@prisma/client';
import { cache } from '@config/redis';
import { config } from '@config/index';
import { logger } from '@utils/logger';
import { generateToken, hashString } from '@utils/encryption';
import {
  createUserSchema,
  loginSchema,
  CreateUserInput,
  LoginInput,
  AuthTokens,
  TokenPayload,
} from '@types/index';

/**
 * Authentication routes plugin
 */
export async function authRoutes(fastify: FastifyInstance): Promise<void> {
  // Register JWT plugin
  await fastify.register(require('@fastify/jwt'), {
    secret: config.jwt.secret,
    sign: {
      expiresIn: config.jwt.accessExpiration,
    },
  });

  // ==================== REGISTRATION ====================

  fastify.post(
    '/register',
    {
      schema: {
        description: 'Register a new user',
        tags: ['Auth'],
        body: {
          type: 'object',
          required: ['email', 'password', 'firstName', 'lastName'],
          properties: {
            email: { type: 'string', format: 'email' },
            password: { type: 'string', minLength: 8 },
            firstName: { type: 'string', minLength: 1 },
            lastName: { type: 'string', minLength: 1 },
          },
        },
      },
    },
    async (request: FastifyRequest<{ Body: CreateUserInput }>, reply: FastifyReply) => {
      try {
        // Validate input
        const validated = createUserSchema.parse(request.body);

        // Check if user exists
        const existingUser = await prisma.user.findUnique({
          where: { email: validated.email },
        });

        if (existingUser) {
          return reply.status(409).send({
            success: false,
            error: 'User with this email already exists',
          });
        }

        // Hash password
        const hashedPassword = await bcrypt.hash(validated.password, 12);

        // Create user
        const user = await prisma.user.create({
          data: {
            email: validated.email,
            password: hashedPassword,
            firstName: validated.firstName,
            lastName: validated.lastName,
          },
          select: {
            id: true,
            email: true,
            firstName: true,
            lastName: true,
            createdAt: true,
          },
        });

        // Create default workspace
        const workspace = await prisma.workspace.create({
          data: {
            name: `${validated.firstName}'s Workspace`,
            slug: `workspace-${user.id.slice(0, 8)}`,
            ownerId: user.id,
            members: {
              create: {
                userId: user.id,
                role: 'ADMIN',
              },
            },
          },
        });

        // Create trial subscription
        await prisma.subscription.create({
          data: {
            workspaceId: workspace.id,
            plan: 'STARTER',
            status: 'TRIAL',
            currentPeriodStart: new Date(),
            currentPeriodEnd: new Date(Date.now() + 14 * 24 * 60 * 60 * 1000), // 14 days trial
            trialEndsAt: new Date(Date.now() + 14 * 24 * 60 * 60 * 1000),
            features: ['basic_agents', 'lead_management', 'email_support'],
          },
        });

        logger.info({ userId: user.id }, 'User registered successfully');

        return reply.status(201).send({
          success: true,
          data: {
            user,
            workspace: {
              id: workspace.id,
              name: workspace.name,
              slug: workspace.slug,
            },
          },
          message: 'Registration successful. Please log in.',
        });
      } catch (error) {
        logger.error({ error }, 'Registration failed');
        throw error;
      }
    }
  );

  // ==================== LOGIN ====================

  fastify.post(
    '/login',
    {
      schema: {
        description: 'Login user',
        tags: ['Auth'],
        body: {
          type: 'object',
          required: ['email', 'password'],
          properties: {
            email: { type: 'string', format: 'email' },
            password: { type: 'string' },
          },
        },
      },
    },
    async (request: FastifyRequest<{ Body: LoginInput }>, reply: FastifyReply) => {
      try {
        // Validate input
        const validated = loginSchema.parse(request.body);

        // Find user
        const user = await prisma.user.findUnique({
          where: { email: validated.email },
          include: {
            workspaces: {
              include: {
                workspace: {
                  include: {
                    subscription: true,
                  },
                },
              },
            },
          },
        });

        if (!user) {
          return reply.status(401).send({
            success: false,
            error: 'Invalid credentials',
          });
        }

        // Check if user is active
        if (!user.isActive) {
          return reply.status(401).send({
            success: false,
            error: 'Account is deactivated',
          });
        }

        // Verify password
        const isValidPassword = await bcrypt.compare(validated.password, user.password);

        if (!isValidPassword) {
          return reply.status(401).send({
            success: false,
            error: 'Invalid credentials',
          });
        }

        // Update last login
        await prisma.user.update({
          where: { id: user.id },
          data: { lastLoginAt: new Date() },
        });

        // Generate tokens
        const tokens = await generateAuthTokens(fastify, {
          userId: user.id,
          email: user.email,
          role: user.workspaces[0]?.role || 'MEMBER',
        });

        // Create refresh token record
        const refreshTokenRecord = await prisma.refreshToken.create({
          data: {
            userId: user.id,
            token: tokens.refreshToken,
            expiresAt: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000), // 7 days
          },
        });

        logger.info({ userId: user.id }, 'User logged in successfully');

        return reply.send({
          success: true,
          data: {
            user: {
              id: user.id,
              email: user.email,
              firstName: user.firstName,
              lastName: user.lastName,
              avatar: user.avatar,
            },
            workspaces: user.workspaces.map((w) => ({
              id: w.workspace.id,
              name: w.workspace.name,
              slug: w.workspace.slug,
              role: w.role,
              subscription: w.workspace.subscription,
            })),
            tokens,
          },
        });
      } catch (error) {
        logger.error({ error }, 'Login failed');
        throw error;
      }
    }
  );

  // ==================== TOKEN REFRESH ====================

  fastify.post(
    '/refresh',
    {
      schema: {
        description: 'Refresh access token',
        tags: ['Auth'],
        body: {
          type: 'object',
          required: ['refreshToken'],
          properties: {
            refreshToken: { type: 'string' },
          },
        },
      },
    },
    async (request: FastifyRequest<{ Body: { refreshToken: string } }>, reply: FastifyReply) => {
      try {
        const { refreshToken } = request.body;

        // Find refresh token
        const tokenRecord = await prisma.refreshToken.findUnique({
          where: { token: refreshToken },
          include: { user: true },
        });

        if (!tokenRecord || tokenRecord.revokedAt) {
          return reply.status(401).send({
            success: false,
            error: 'Invalid refresh token',
          });
        }

        // Check if expired
        if (new Date() > tokenRecord.expiresAt) {
          return reply.status(401).send({
            success: false,
            error: 'Refresh token expired',
          });
        }

        // Get user's workspace role
        const workspaceMember = await prisma.workspaceMember.findFirst({
          where: { userId: tokenRecord.userId },
        });

        // Generate new tokens
        const tokens = await generateAuthTokens(fastify, {
          userId: tokenRecord.user.id,
          email: tokenRecord.user.email,
          role: workspaceMember?.role || 'MEMBER',
        });

        // Revoke old refresh token
        await prisma.refreshToken.update({
          where: { id: tokenRecord.id },
          data: { revokedAt: new Date() },
        });

        // Create new refresh token
        await prisma.refreshToken.create({
          data: {
            userId: tokenRecord.userId,
            token: tokens.refreshToken,
            expiresAt: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000),
          },
        });

        logger.info({ userId: tokenRecord.userId }, 'Token refreshed successfully');

        return reply.send({
          success: true,
          data: { tokens },
        });
      } catch (error) {
        logger.error({ error }, 'Token refresh failed');
        throw error;
      }
    }
  );

  // ==================== LOGOUT ====================

  fastify.post(
    '/logout',
    {
      schema: {
        description: 'Logout user',
        tags: ['Auth'],
        body: {
          type: 'object',
          required: ['refreshToken'],
          properties: {
            refreshToken: { type: 'string' },
          },
        },
      },
    },
    async (request: FastifyRequest<{ Body: { refreshToken: string } }>, reply: FastifyReply) => {
      try {
        const { refreshToken } = request.body;

        // Revoke refresh token
        await prisma.refreshToken.updateMany({
          where: { token: refreshToken },
          data: { revokedAt: new Date() },
        });

        // Blacklist access token if provided
        const authHeader = request.headers.authorization;
        if (authHeader?.startsWith('Bearer ')) {
          const accessToken = authHeader.substring(7);
          await cache.set(`blacklist:token:${accessToken}`, true, 900); // 15 minutes
        }

        logger.info('User logged out successfully');

        return reply.send({
          success: true,
          message: 'Logged out successfully',
        });
      } catch (error) {
        logger.error({ error }, 'Logout failed');
        throw error;
      }
    }
  );

  // ==================== ME ====================

  fastify.get(
    '/me',
    {
      schema: {
        description: 'Get current user',
        tags: ['Auth'],
      },
    },
    async (request: FastifyRequest, reply: FastifyReply) => {
      try {
        const user = (request as any).user as TokenPayload;

        if (!user) {
          return reply.status(401).send({
            success: false,
            error: 'Not authenticated',
          });
        }

        const userData = await prisma.user.findUnique({
          where: { id: user.userId },
          select: {
            id: true,
            email: true,
            firstName: true,
            lastName: true,
            avatar: true,
            isActive: true,
            emailVerified: true,
            lastLoginAt: true,
            createdAt: true,
            workspaces: {
              include: {
                workspace: {
                  include: {
                    subscription: true,
                  },
                },
              },
            },
          },
        });

        if (!userData) {
          return reply.status(404).send({
            success: false,
            error: 'User not found',
          });
        }

        return reply.send({
          success: true,
          data: {
            user: {
              id: userData.id,
              email: userData.email,
              firstName: userData.firstName,
              lastName: userData.lastName,
              avatar: userData.avatar,
              isActive: userData.isActive,
              emailVerified: userData.emailVerified,
              lastLoginAt: userData.lastLoginAt,
              createdAt: userData.createdAt,
            },
            workspaces: userData.workspaces.map((w) => ({
              id: w.workspace.id,
              name: w.workspace.name,
              slug: w.workspace.slug,
              role: w.role,
              subscription: w.workspace.subscription,
            })),
          },
        });
      } catch (error) {
        logger.error({ error }, 'Failed to get current user');
        throw error;
      }
    }
  );
}

/**
 * Generates authentication tokens
 */
async function generateAuthTokens(
  fastify: FastifyInstance,
  payload: TokenPayload
): Promise<AuthTokens> {
  const accessToken = await fastify.jwt.sign(payload);
  const refreshToken = generateToken(64);

  return {
    accessToken,
    refreshToken,
    expiresIn: 900, // 15 minutes
  };
}

export default authRoutes;
