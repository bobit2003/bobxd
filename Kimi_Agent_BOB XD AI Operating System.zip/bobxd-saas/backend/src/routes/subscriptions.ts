/**
 * @fileoverview Subscription Routes
 * Subscription management and billing
 */

import { FastifyInstance, FastifyRequest, FastifyReply } from 'fastify';
import { z } from 'zod';
import { prisma } from '@prisma/client';
import { logger } from '@utils/logger';
import { authenticateToken, AuthenticatedRequest, requireRoles } from '@middleware/auth';
import { PLAN_LIMITS, PlanType } from '@types/index';

/**
 * Subscription routes plugin
 */
export async function subscriptionRoutes(fastify: FastifyInstance): Promise<void> {
  // Apply authentication to all routes
  fastify.addHook('preHandler', authenticateToken);

  // ==================== GET SUBSCRIPTION ====================

  fastify.get(
    '/workspace/:workspaceId',
    {
      schema: {
        description: 'Get workspace subscription',
        tags: ['Subscriptions'],
        params: {
          type: 'object',
          required: ['workspaceId'],
          properties: {
            workspaceId: { type: 'string' },
          },
        },
      },
    },
    async (request: FastifyRequest<{ Params: { workspaceId: string } }>, reply: FastifyReply) => {
      const { workspaceId } = request.params;
      const user = (request as AuthenticatedRequest).user;

      // Check membership
      const membership = await prisma.workspaceMember.findUnique({
        where: {
          userId_workspaceId: {
            userId: user.userId,
            workspaceId,
          },
        },
      });

      if (!membership && user.role !== 'SUPER_ADMIN') {
        return reply.status(403).send({
          success: false,
          error: 'Not a member of this workspace',
        });
      }

      const subscription = await prisma.subscription.findUnique({
        where: { workspaceId },
        include: {
          invoices: {
            orderBy: { createdAt: 'desc' },
            take: 10,
          },
        },
      });

      if (!subscription) {
        return reply.status(404).send({
          success: false,
          error: 'Subscription not found',
        });
      }

      // Get current usage
      const [agentCount, leadCount, executionCount] = await Promise.all([
        prisma.agent.count({ where: { workspaceId } }),
        prisma.lead.count({ where: { workspaceId } }),
        prisma.agentExecution.count({
          where: {
            workspaceId,
            createdAt: {
              gte: subscription.currentPeriodStart,
              lte: subscription.currentPeriodEnd,
            },
          },
        }),
      ]);

      const limits = PLAN_LIMITS[subscription.plan];

      return reply.send({
        success: true,
        data: {
          subscription,
          usage: {
            agents: { used: agentCount, limit: limits.maxAgents },
            leads: { used: leadCount, limit: limits.maxLeads },
            executions: { used: executionCount, limit: limits.maxExecutions },
          },
          limits,
        },
      });
    }
  );

  // ==================== GET USAGE ====================

  fastify.get(
    '/workspace/:workspaceId/usage',
    {
      schema: {
        description: 'Get workspace usage statistics',
        tags: ['Subscriptions'],
        params: {
          type: 'object',
          required: ['workspaceId'],
          properties: {
            workspaceId: { type: 'string' },
          },
        },
        querystring: {
          type: 'object',
          properties: {
            period: { type: 'string', default: 'current' },
          },
        },
      },
    },
    async (request: FastifyRequest<{
      Params: { workspaceId: string };
      Querystring: { period?: string };
    }>, reply: FastifyReply) => {
      const { workspaceId } = request.params;
      const { period = 'current' } = request.query;
      const user = (request as AuthenticatedRequest).user;

      // Check membership
      const membership = await prisma.workspaceMember.findUnique({
        where: {
          userId_workspaceId: {
            userId: user.userId,
            workspaceId,
          },
        },
      });

      if (!membership && user.role !== 'SUPER_ADMIN') {
        return reply.status(403).send({
          success: false,
          error: 'Not a member of this workspace',
        });
      }

      const subscription = await prisma.subscription.findUnique({
        where: { workspaceId },
      });

      if (!subscription) {
        return reply.status(404).send({
          success: false,
          error: 'Subscription not found',
        });
      }

      // Calculate date range
      let startDate: Date;
      let endDate: Date;

      if (period === 'current') {
        startDate = subscription.currentPeriodStart;
        endDate = subscription.currentPeriodEnd;
      } else if (period === 'last') {
        const duration = subscription.currentPeriodEnd.getTime() - subscription.currentPeriodStart.getTime();
        endDate = subscription.currentPeriodStart;
        startDate = new Date(endDate.getTime() - duration);
      } else {
        startDate = new Date(Date.now() - 30 * 24 * 60 * 60 * 1000);
        endDate = new Date();
      }

      // Get usage stats
      const [
        agentCount,
        leadCount,
        executionCount,
        tokenUsage,
        dailyExecutions,
      ] = await Promise.all([
        prisma.agent.count({ where: { workspaceId } }),
        prisma.lead.count({ where: { workspaceId } }),
        prisma.agentExecution.count({
          where: {
            workspaceId,
            createdAt: {
              gte: startDate,
              lte: endDate,
            },
          },
        }),
        prisma.agent.aggregate({
          where: { workspaceId },
          _sum: { tokensUsed: true },
        }),
        prisma.agentExecution.groupBy({
          by: ['status'],
          where: {
            workspaceId,
            createdAt: {
              gte: startDate,
              lte: endDate,
            },
          },
          _count: {
            status: true,
          },
        }),
      ]);

      const limits = PLAN_LIMITS[subscription.plan];

      return reply.send({
        success: true,
        data: {
          period: { start: startDate, end: endDate },
          usage: {
            agents: { used: agentCount, limit: limits.maxAgents, percentage: (agentCount / limits.maxAgents) * 100 },
            leads: { used: leadCount, limit: limits.maxLeads, percentage: (leadCount / limits.maxLeads) * 100 },
            executions: { used: executionCount, limit: limits.maxExecutions, percentage: (executionCount / limits.maxExecutions) * 100 },
            tokens: { used: tokenUsage._sum.tokensUsed || 0, limit: limits.maxTokens, percentage: ((tokenUsage._sum.tokensUsed || 0) / limits.maxTokens) * 100 },
          },
          executionBreakdown: dailyExecutions,
        },
      });
    }
  );

  // ==================== UPGRADE SUBSCRIPTION ====================

  fastify.post(
    '/workspace/:workspaceId/upgrade',
    {
      schema: {
        description: 'Upgrade workspace subscription',
        tags: ['Subscriptions'],
        params: {
          type: 'object',
          required: ['workspaceId'],
          properties: {
            workspaceId: { type: 'string' },
          },
        },
        body: {
          type: 'object',
          required: ['plan'],
          properties: {
            plan: { type: 'string', enum: ['STARTER', 'PRO', 'AGENCY'] },
            paymentMethodId: { type: 'string' },
          },
        },
      },
    },
    async (request: FastifyRequest<{
      Params: { workspaceId: string };
      Body: { plan: PlanType; paymentMethodId?: string };
    }>, reply: FastifyReply) => {
      const { workspaceId } = request.params;
      const { plan, paymentMethodId } = request.body;
      const user = (request as AuthenticatedRequest).user;

      // Check permissions (admin only)
      const membership = await prisma.workspaceMember.findUnique({
        where: {
          userId_workspaceId: {
            userId: user.userId,
            workspaceId,
          },
        },
      });

      if (!membership || (membership.role !== 'ADMIN' && user.role !== 'SUPER_ADMIN')) {
        return reply.status(403).send({
          success: false,
          error: 'Insufficient permissions',
        });
      }

      const subscription = await prisma.subscription.findUnique({
        where: { workspaceId },
      });

      if (!subscription) {
        return reply.status(404).send({
          success: false,
          error: 'Subscription not found',
        });
      }

      // Validate plan upgrade
      const planHierarchy = ['STARTER', 'PRO', 'AGENCY'];
      const currentIndex = planHierarchy.indexOf(subscription.plan);
      const newIndex = planHierarchy.indexOf(plan);

      if (newIndex <= currentIndex) {
        return reply.status(400).send({
          success: false,
          error: 'Can only upgrade to a higher plan',
        });
      }

      // Update subscription
      const updatedSubscription = await prisma.subscription.update({
        where: { workspaceId },
        data: {
          plan,
          status: 'ACTIVE',
          features: PLAN_LIMITS[plan].features,
          usageLimits: {
            maxAgents: PLAN_LIMITS[plan].maxAgents,
            maxLeads: PLAN_LIMITS[plan].maxLeads,
            maxExecutions: PLAN_LIMITS[plan].maxExecutions,
            maxTokens: PLAN_LIMITS[plan].maxTokens,
          },
          ...(paymentMethodId && { paymentMethodId }),
        },
      });

      logger.info({ workspaceId, oldPlan: subscription.plan, newPlan: plan }, 'Subscription upgraded');

      return reply.send({
        success: true,
        data: updatedSubscription,
        message: `Successfully upgraded to ${plan} plan`,
      });
    }
  );

  // ==================== CANCEL SUBSCRIPTION ====================

  fastify.post(
    '/workspace/:workspaceId/cancel',
    {
      schema: {
        description: 'Cancel workspace subscription',
        tags: ['Subscriptions'],
        params: {
          type: 'object',
          required: ['workspaceId'],
          properties: {
            workspaceId: { type: 'string' },
          },
        },
        body: {
          type: 'object',
          properties: {
            immediate: { type: 'boolean', default: false },
          },
        },
      },
    },
    async (request: FastifyRequest<{
      Params: { workspaceId: string };
      Body: { immediate?: boolean };
    }>, reply: FastifyReply) => {
      const { workspaceId } = request.params;
      const { immediate = false } = request.body;
      const user = (request as AuthenticatedRequest).user;

      // Check permissions (admin only)
      const membership = await prisma.workspaceMember.findUnique({
        where: {
          userId_workspaceId: {
            userId: user.userId,
            workspaceId,
          },
        },
      });

      if (!membership || (membership.role !== 'ADMIN' && user.role !== 'SUPER_ADMIN')) {
        return reply.status(403).send({
          success: false,
          error: 'Insufficient permissions',
        });
      }

      const subscription = await prisma.subscription.findUnique({
        where: { workspaceId },
      });

      if (!subscription) {
        return reply.status(404).send({
          success: false,
          error: 'Subscription not found',
        });
      }

      if (immediate) {
        // Immediate cancellation
        await prisma.subscription.update({
          where: { workspaceId },
          data: {
            status: 'CANCELLED',
            cancelAtPeriodEnd: false,
          },
        });
      } else {
        // Cancel at period end
        await prisma.subscription.update({
          where: { workspaceId },
          data: {
            cancelAtPeriodEnd: true,
          },
        });
      }

      logger.info({ workspaceId, immediate }, 'Subscription cancelled');

      return reply.send({
        success: true,
        message: immediate
          ? 'Subscription cancelled immediately'
          : 'Subscription will be cancelled at the end of the billing period',
      });
    }
  );

  // ==================== GET PLAN DETAILS ====================

  fastify.get(
    '/plans',
    {
      schema: {
        description: 'Get available subscription plans',
        tags: ['Subscriptions'],
      },
    },
    async (request: FastifyRequest, reply: FastifyReply) => {
      const plans = Object.entries(PLAN_LIMITS).map(([name, limits]) => ({
        name,
        ...limits,
        pricing: {
          STARTER: { monthly: 49, yearly: 490 },
          PRO: { monthly: 149, yearly: 1490 },
          AGENCY: { monthly: 499, yearly: 4990 },
        }[name],
      }));

      return reply.send({
        success: true,
        data: plans,
      });
    }
  );

  // ==================== ADMIN: OVERRIDE USAGE ====================

  fastify.post(
    '/workspace/:workspaceId/override',
    {
      schema: {
        description: 'Override usage limits (Admin only)',
        tags: ['Subscriptions'],
        params: {
          type: 'object',
          required: ['workspaceId'],
          properties: {
            workspaceId: { type: 'string' },
          },
        },
        body: {
          type: 'object',
          required: ['resource', 'newLimit'],
          properties: {
            resource: { type: 'string', enum: ['agents', 'leads', 'executions', 'tokens'] },
            newLimit: { type: 'number', minimum: 1 },
            reason: { type: 'string' },
          },
        },
      },
    },
    async (request: FastifyRequest<{
      Params: { workspaceId: string };
      Body: { resource: string; newLimit: number; reason?: string };
    }>, reply: FastifyReply) => {
      const { workspaceId } = request.params;
      const { resource, newLimit, reason } = request.body;
      const user = (request as AuthenticatedRequest).user;

      // Super admin only
      if (user.role !== 'SUPER_ADMIN') {
        return reply.status(403).send({
          success: false,
          error: 'Super admin access required',
        });
      }

      const subscription = await prisma.subscription.findUnique({
        where: { workspaceId },
      });

      if (!subscription) {
        return reply.status(404).send({
          success: false,
          error: 'Subscription not found',
        });
      }

      const usageLimits = subscription.usageLimits as Record<string, number>;
      usageLimits[resource] = newLimit;

      const updatedSubscription = await prisma.subscription.update({
        where: { workspaceId },
        data: {
          usageLimits,
        },
      });

      // Log the override
      await prisma.auditLog.create({
        data: {
          action: 'SETTINGS_CHANGE',
          entityType: 'SUBSCRIPTION',
          entityId: subscription.id,
          description: `Usage limit override: ${resource} = ${newLimit}`,
          userId: user.userId,
          workspaceId,
          newValues: { resource, newLimit, reason },
        },
      });

      logger.info({ workspaceId, resource, newLimit, adminId: user.userId }, 'Usage limit overridden');

      return reply.send({
        success: true,
        data: updatedSubscription,
      });
    }
  );
}

export default subscriptionRoutes;
