/**
 * @fileoverview Admin Routes
 * Super admin operations for platform management
 */

import { FastifyInstance, FastifyRequest, FastifyReply } from 'fastify';
import { z } from 'zod';
import { prisma } from '@prisma/client';
import { logger } from '@utils/logger';
import { authenticateToken, AuthenticatedRequest, requireRoles } from '@middleware/auth';
import { openclawService } from '@services/openclaw.service';

/**
 * Admin routes plugin - Super Admin only
 */
export async function adminRoutes(fastify: FastifyInstance): Promise<void> {
  // Apply authentication and super admin check to all routes
  fastify.addHook('preHandler', authenticateToken);
  fastify.addHook('preHandler', requireRoles('SUPER_ADMIN'));

  // ==================== DASHBOARD STATS ====================

  fastify.get(
    '/stats',
    {
      schema: {
        description: 'Get platform statistics',
        tags: ['Admin'],
      },
    },
    async (request: FastifyRequest, reply: FastifyReply) => {
      const [
        totalUsers,
        totalWorkspaces,
        totalLeads,
        totalAgents,
        totalExecutions,
        recentUsers,
        recentWorkspaces,
        subscriptionsByPlan,
        queueStats,
      ] = await Promise.all([
        prisma.user.count(),
        prisma.workspace.count(),
        prisma.lead.count(),
        prisma.agent.count(),
        prisma.agentExecution.count(),
        prisma.user.findMany({
          orderBy: { createdAt: 'desc' },
          take: 5,
          select: {
            id: true,
            email: true,
            firstName: true,
            lastName: true,
            createdAt: true,
          },
        }),
        prisma.workspace.findMany({
          orderBy: { createdAt: 'desc' },
          take: 5,
          include: {
            owner: {
              select: {
                id: true,
                email: true,
                firstName: true,
                lastName: true,
              },
            },
            subscription: true,
          },
        }),
        prisma.subscription.groupBy({
          by: ['plan'],
          _count: {
            plan: true,
          },
        }),
        openclawService.getQueueStats(),
      ]);

      // Calculate revenue (mock calculation)
      const planPrices = { STARTER: 49, PRO: 149, AGENCY: 499 };
      const estimatedMRR = subscriptionsByPlan.reduce((total, sub) => {
        const price = planPrices[sub.plan as keyof typeof planPrices] || 0;
        return total + price * sub._count.plan;
      }, 0);

      return reply.send({
        success: true,
        data: {
          totals: {
            users: totalUsers,
            workspaces: totalWorkspaces,
            leads: totalLeads,
            agents: totalAgents,
            executions: totalExecutions,
          },
          recentUsers,
          recentWorkspaces,
          subscriptionsByPlan,
          estimatedMRR,
          queueStats,
        },
      });
    }
  );

  // ==================== USER MANAGEMENT ====================

  fastify.get(
    '/users',
    {
      schema: {
        description: 'List all users',
        tags: ['Admin'],
        querystring: {
          type: 'object',
          properties: {
            page: { type: 'string', default: '1' },
            limit: { type: 'string', default: '20' },
            search: { type: 'string' },
            isActive: { type: 'string' },
          },
        },
      },
    },
    async (request: FastifyRequest<{
      Querystring: { page?: string; limit?: string; search?: string; isActive?: string };
    }>, reply: FastifyReply) => {
      const { page = '1', limit = '20', search, isActive } = request.query;
      const pageNum = parseInt(page, 10);
      const limitNum = parseInt(limit, 10);
      const skip = (pageNum - 1) * limitNum;

      const where: any = {};
      if (search) {
        where.OR = [
          { email: { contains: search, mode: 'insensitive' } },
          { firstName: { contains: search, mode: 'insensitive' } },
          { lastName: { contains: search, mode: 'insensitive' } },
        ];
      }
      if (isActive !== undefined) {
        where.isActive = isActive === 'true';
      }

      const [users, total] = await Promise.all([
        prisma.user.findMany({
          where,
          skip,
          take: limitNum,
          orderBy: { createdAt: 'desc' },
          include: {
            workspaces: {
              include: {
                workspace: {
                  select: {
                    id: true,
                    name: true,
                  },
                },
              },
            },
            _count: {
              select: {
                workspaces: true,
              },
            },
          },
        }),
        prisma.user.count({ where }),
      ]);

      return reply.send({
        success: true,
        data: {
          users,
          pagination: {
            page: pageNum,
            limit: limitNum,
            total,
            totalPages: Math.ceil(total / limitNum),
          },
        },
      });
    }
  );

  fastify.patch(
    '/users/:userId',
    {
      schema: {
        description: 'Update user',
        tags: ['Admin'],
        params: {
          type: 'object',
          required: ['userId'],
          properties: {
            userId: { type: 'string' },
          },
        },
        body: {
          type: 'object',
          properties: {
            firstName: { type: 'string' },
            lastName: { type: 'string' },
            isActive: { type: 'boolean' },
            emailVerified: { type: 'boolean' },
          },
        },
      },
    },
    async (request: FastifyRequest<{
      Params: { userId: string };
      Body: { firstName?: string; lastName?: string; isActive?: boolean; emailVerified?: boolean };
    }>, reply: FastifyReply) => {
      const { userId } = request.params;

      const user = await prisma.user.update({
        where: { id: userId },
        data: request.body,
      });

      logger.info({ userId, updates: request.body }, 'User updated by admin');

      return reply.send({
        success: true,
        data: user,
      });
    }
  );

  // ==================== WORKSPACE MANAGEMENT ====================

  fastify.get(
    '/workspaces',
    {
      schema: {
        description: 'List all workspaces',
        tags: ['Admin'],
        querystring: {
          type: 'object',
          properties: {
            page: { type: 'string', default: '1' },
            limit: { type: 'string', default: '20' },
            search: { type: 'string' },
          },
        },
      },
    },
    async (request: FastifyRequest<{
      Querystring: { page?: string; limit?: string; search?: string };
    }>, reply: FastifyReply) => {
      const { page = '1', limit = '20', search } = request.query;
      const pageNum = parseInt(page, 10);
      const limitNum = parseInt(limit, 10);
      const skip = (pageNum - 1) * limitNum;

      const where: any = {};
      if (search) {
        where.OR = [
          { name: { contains: search, mode: 'insensitive' } },
          { slug: { contains: search, mode: 'insensitive' } },
        ];
      }

      const [workspaces, total] = await Promise.all([
        prisma.workspace.findMany({
          where,
          skip,
          take: limitNum,
          orderBy: { createdAt: 'desc' },
          include: {
            owner: {
              select: {
                id: true,
                email: true,
                firstName: true,
                lastName: true,
              },
            },
            subscription: true,
            _count: {
              select: {
                members: true,
                leads: true,
                agents: true,
              },
            },
          },
        }),
        prisma.workspace.count({ where }),
      ]);

      return reply.send({
        success: true,
        data: {
          workspaces,
          pagination: {
            page: pageNum,
            limit: limitNum,
            total,
            totalPages: Math.ceil(total / limitNum),
          },
        },
      });
    }
  );

  // ==================== AGENT SYSTEM PROMPTS ====================

  fastify.get(
    '/agents/system-prompts',
    {
      schema: {
        description: 'Get default system prompts for agent types',
        tags: ['Admin'],
      },
    },
    async (request: FastifyRequest, reply: FastifyReply) => {
      const systemPrompts = {
        LEAD_HUNTER: `You are a Lead Hunter AI agent for BOB XD. Your mission is to identify and qualify high-value leads across multiple channels.

Capabilities:
- Research companies and decision-makers
- Analyze LinkedIn profiles for prospecting
- Score leads based on fit and intent
- Enrich lead data with additional information

When executing tasks:
1. Use available data sources effectively
2. Provide detailed lead information
3. Assign appropriate lead scores (0-100)
4. Tag leads with relevant categories
5. Suggest next best actions

Always maintain professionalism and accuracy in your research.`,

        LINKEDIN_OUTREACH: `You are a LinkedIn Outreach AI agent for BOB XD. You craft personalized connection requests and follow-up messages.

Capabilities:
- Analyze LinkedIn profiles for personalization
- Write compelling connection requests
- Create multi-touch outreach sequences
- Track engagement and responses

Guidelines:
- Keep messages concise and professional
- Reference specific profile details
- Avoid spammy language
- Follow LinkedIn's best practices
- Respect daily connection limits

Always prioritize quality over quantity in outreach.`,

        SEO_AUDIT: `You are an SEO Audit AI agent for BOB XD. You analyze websites and provide actionable SEO recommendations.

Capabilities:
- Technical SEO analysis
- Content optimization suggestions
- Keyword research and analysis
- Competitor analysis
- Backlink profile review

Audit Checklist:
1. Site structure and crawlability
2. Page speed and Core Web Vitals
3. Mobile-friendliness
4. Content quality and relevance
5. Meta tags and headers
6. Internal linking structure
7. Schema markup presence

Provide clear, prioritized recommendations with implementation guidance.`,

        ADS_STRATEGY: `You are an Ads Strategy AI agent for BOB XD. You create and optimize paid advertising campaigns.

Capabilities:
- Campaign structure recommendations
- Audience targeting suggestions
- Ad copy creation and optimization
- Budget allocation strategies
- A/B test recommendations

Focus Areas:
- Google Ads (Search, Display, YouTube)
- Meta Ads (Facebook, Instagram)
- LinkedIn Ads
- Retargeting strategies

Always align strategies with business goals and target ROAS/CPA.`,

        CONTENT_GENERATOR: `You are a Content Generator AI agent for BOB XD. You create high-quality marketing content.

Content Types:
- Blog posts and articles
- Social media posts
- Email newsletters
- Landing page copy
- Ad copy variations
- Video scripts

Guidelines:
- Match brand voice and tone
- Optimize for target keywords
- Include clear CTAs
- Follow platform best practices
- Ensure factual accuracy

Create content that engages, educates, and converts.`,

        CRM_AUTOMATION: `You are a CRM Automation AI agent for BOB XD. You automate CRM workflows and data management.

Capabilities:
- Lead scoring and routing
- Data enrichment and cleansing
- Workflow automation
- Report generation
- Follow-up scheduling

Automation Rules:
- Trigger actions based on lead behavior
- Maintain data quality standards
- Ensure timely follow-ups
- Create meaningful segments
- Generate actionable insights

Streamline CRM operations while maintaining data integrity.`,
      };

      return reply.send({
        success: true,
        data: systemPrompts,
      });
    }
  );

  // ==================== CMS MANAGEMENT ====================

  fastify.get(
    '/cms',
    {
      schema: {
        description: 'Get CMS content',
        tags: ['Admin'],
        querystring: {
          type: 'object',
          properties: {
            contentType: { type: 'string' },
            key: { type: 'string' },
          },
        },
      },
    },
    async (request: FastifyRequest<{
      Querystring: { contentType?: string; key?: string };
    }>, reply: FastifyReply) => {
      const { contentType, key } = request.query;

      const where: any = {};
      if (contentType) where.contentType = contentType;
      if (key) where.key = key;

      const contents = await prisma.cmsContent.findMany({
        where,
        orderBy: { updatedAt: 'desc' },
      });

      return reply.send({
        success: true,
        data: contents,
      });
    }
  );

  fastify.post(
    '/cms',
    {
      schema: {
        description: 'Create or update CMS content',
        tags: ['Admin'],
        body: {
          type: 'object',
          required: ['key', 'contentType', 'title', 'content'],
          properties: {
            key: { type: 'string' },
            contentType: { type: 'string' },
            title: { type: 'string' },
            content: { type: 'string' },
            metadata: { type: 'object' },
            isPublished: { type: 'boolean' },
          },
        },
      },
    },
    async (request: FastifyRequest<{
      Body: {
        key: string;
        contentType: string;
        title: string;
        content: string;
        metadata?: Record<string, unknown>;
        isPublished?: boolean;
      };
    }>, reply: FastifyReply) => {
      const { key, contentType, title, content, metadata, isPublished } = request.body;

      const cmsContent = await prisma.cmsContent.upsert({
        where: {
          workspaceId_key: {
            workspaceId: 'system',
            key,
          },
        },
        update: {
          title,
          content,
          metadata: metadata as any,
          isPublished,
          ...(isPublished && { publishedAt: new Date() }),
        },
        create: {
          workspaceId: 'system',
          key,
          contentType,
          title,
          content,
          metadata: metadata as any,
          isPublished: isPublished || false,
          ...(isPublished && { publishedAt: new Date() }),
        },
      });

      return reply.send({
        success: true,
        data: cmsContent,
      });
    }
  );

  // ==================== AUDIT LOGS ====================

  fastify.get(
    '/audit-logs',
    {
      schema: {
        description: 'Get audit logs',
        tags: ['Admin'],
        querystring: {
          type: 'object',
          properties: {
            page: { type: 'string', default: '1' },
            limit: { type: 'string', default: '50' },
            action: { type: 'string' },
            userId: { type: 'string' },
            workspaceId: { type: 'string' },
          },
        },
      },
    },
    async (request: FastifyRequest<{
      Querystring: { page?: string; limit?: string; action?: string; userId?: string; workspaceId?: string };
    }>, reply: FastifyReply) => {
      const { page = '1', limit = '50', action, userId, workspaceId } = request.query;
      const pageNum = parseInt(page, 10);
      const limitNum = parseInt(limit, 10);
      const skip = (pageNum - 1) * limitNum;

      const where: any = {};
      if (action) where.action = action;
      if (userId) where.userId = userId;
      if (workspaceId) where.workspaceId = workspaceId;

      const [logs, total] = await Promise.all([
        prisma.auditLog.findMany({
          where,
          skip,
          take: limitNum,
          orderBy: { createdAt: 'desc' },
          include: {
            user: {
              select: {
                id: true,
                email: true,
                firstName: true,
                lastName: true,
              },
            },
          },
        }),
        prisma.auditLog.count({ where }),
      ]);

      return reply.send({
        success: true,
        data: {
          logs,
          pagination: {
            page: pageNum,
            limit: limitNum,
            total,
            totalPages: Math.ceil(total / limitNum),
          },
        },
      });
    }
  );

  // ==================== SYSTEM SETTINGS ====================

  fastify.get(
    '/settings',
    {
      schema: {
        description: 'Get system settings',
        tags: ['Admin'],
      },
    },
    async (request: FastifyRequest, reply: FastifyReply) => {
      const settings = await prisma.systemSetting.findMany({
        orderBy: { category: 'asc' },
      });

      return reply.send({
        success: true,
        data: settings,
      });
    }
  );

  fastify.post(
    '/settings',
    {
      schema: {
        description: 'Update system setting',
        tags: ['Admin'],
        body: {
          type: 'object',
          required: ['key', 'value', 'category'],
          properties: {
            key: { type: 'string' },
            value: {},
            category: { type: 'string' },
          },
        },
      },
    },
    async (request: FastifyRequest<{
      Body: { key: string; value: unknown; category: string };
    }>, reply: FastifyReply) => {
      const { key, value, category } = request.body;

      const setting = await prisma.systemSetting.upsert({
        where: { key },
        update: { value: value as any },
        create: { key, value: value as any, category },
      });

      logger.info({ key, category }, 'System setting updated');

      return reply.send({
        success: true,
        data: setting,
      });
    }
  );
}

export default adminRoutes;
