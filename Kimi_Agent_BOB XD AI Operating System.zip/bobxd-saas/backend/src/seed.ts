/**
 * @fileoverview Database Seed Script
 * Seeds the database with initial data for development
 */

import { PrismaClient, PlanType, UserRole, AgentStatus } from '@prisma/client';
import bcrypt from 'bcryptjs';

const prisma = new PrismaClient();

async function main() {
  console.log('Starting database seed...');

  // Create super admin user
  const superAdminPassword = await bcrypt.hash('admin123', 12);
  const superAdmin = await prisma.user.upsert({
    where: { email: 'admin@bobxd.ai' },
    update: {},
    create: {
      email: 'admin@bobxd.ai',
      password: superAdminPassword,
      firstName: 'Super',
      lastName: 'Admin',
      isActive: true,
      emailVerified: true,
    },
  });
  console.log('Created super admin:', superAdmin.email);

  // Create demo user
  const demoPassword = await bcrypt.hash('demo123', 12);
  const demoUser = await prisma.user.upsert({
    where: { email: 'demo@example.com' },
    update: {},
    create: {
      email: 'demo@example.com',
      password: demoPassword,
      firstName: 'Demo',
      lastName: 'User',
      isActive: true,
      emailVerified: true,
    },
  });
  console.log('Created demo user:', demoUser.email);

  // Create demo workspace
  const demoWorkspace = await prisma.workspace.upsert({
    where: { slug: 'demo-workspace' },
    update: {},
    create: {
      name: 'Demo Workspace',
      slug: 'demo-workspace',
      description: 'A demo workspace for testing BOB XD',
      ownerId: demoUser.id,
      members: {
        create: {
          userId: demoUser.id,
          role: 'ADMIN',
        },
      },
    },
  });
  console.log('Created demo workspace:', demoWorkspace.name);

  // Create subscription for demo workspace
  const subscription = await prisma.subscription.upsert({
    where: { workspaceId: demoWorkspace.id },
    update: {},
    create: {
      workspaceId: demoWorkspace.id,
      plan: 'PRO',
      status: 'ACTIVE',
      currentPeriodStart: new Date(),
      currentPeriodEnd: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000),
      features: [
        'advanced_agents',
        'lead_management',
        'campaigns',
        'analytics',
        'priority_support',
        'api_access',
      ],
      usageLimits: {
        maxAgents: 10,
        maxLeads: 5000,
        maxExecutions: 10000,
        maxTokens: 1000000,
      },
    },
  });
  console.log('Created subscription:', subscription.plan);

  // Create sample leads
  const sampleLeads = [
    {
      firstName: 'John',
      lastName: 'Smith',
      email: 'john.smith@techcorp.com',
      phone: '+1-555-0123',
      company: 'TechCorp Inc.',
      title: 'CTO',
      source: 'LinkedIn',
      status: 'QUALIFIED',
      score: 85,
      tags: ['enterprise', 'tech'],
      notes: 'Interested in AI automation solutions',
    },
    {
      firstName: 'Sarah',
      lastName: 'Johnson',
      email: 'sarah.j@marketingpro.com',
      phone: '+1-555-0456',
      company: 'Marketing Pro',
      title: 'Marketing Director',
      source: 'Website',
      status: 'CONTACTED',
      score: 72,
      tags: ['marketing', 'mid-market'],
      notes: 'Looking for content generation tools',
    },
    {
      firstName: 'Michael',
      lastName: 'Chen',
      email: 'mchen@startup.io',
      phone: '+1-555-0789',
      company: 'StartupIO',
      title: 'Founder',
      source: 'Referral',
      status: 'NEW',
      score: 65,
      tags: ['startup', 'tech'],
      notes: 'Early stage startup exploring AI solutions',
    },
    {
      firstName: 'Emily',
      lastName: 'Davis',
      email: 'emily.davis@agency.co',
      phone: '+1-555-0321',
      company: 'Creative Agency Co',
      title: 'Account Director',
      source: 'Conference',
      status: 'PROPOSAL',
      score: 90,
      tags: ['agency', 'enterprise'],
      notes: 'Ready to sign, negotiating terms',
    },
    {
      firstName: 'David',
      lastName: 'Wilson',
      email: 'd.wilson@retail giant.com',
      phone: '+1-555-0654',
      company: 'Retail Giant',
      title: 'VP of Sales',
      source: 'Cold Outreach',
      status: 'NEGOTIATION',
      score: 78,
      tags: ['retail', 'enterprise'],
      notes: 'Large deal potential, multiple stakeholders',
    },
  ];

  for (const leadData of sampleLeads) {
    await prisma.lead.upsert({
      where: { email: leadData.email },
      update: {},
      create: {
        ...leadData,
        workspaceId: demoWorkspace.id,
      },
    });
  }
  console.log('Created sample leads:', sampleLeads.length);

  // Create sample agents
  const sampleAgents = [
    {
      name: 'Lead Hunter Pro',
      description: 'Automatically finds and qualifies leads from multiple sources',
      type: 'LEAD_HUNTER',
      systemPrompt: `You are a Lead Hunter AI agent. Your mission is to identify and qualify high-value leads across multiple channels.

When executing tasks:
1. Research companies and decision-makers
2. Analyze profiles for prospecting
3. Score leads based on fit and intent (0-100)
4. Enrich lead data with additional information
5. Suggest next best actions

Always maintain professionalism and accuracy in your research.`,
      status: 'ACTIVE',
      tokenLimit: 100000,
      tokensUsed: 24500,
      executionLimit: 1000,
      executionsUsed: 156,
      isEnabled: true,
      memoryEnabled: true,
    },
    {
      name: 'LinkedIn Connector',
      description: 'Sends personalized LinkedIn connection requests',
      type: 'LINKEDIN_OUTREACH',
      systemPrompt: `You are a LinkedIn Outreach AI agent. You craft personalized connection requests and follow-up messages.

Guidelines:
- Keep messages concise and professional
- Reference specific profile details
- Avoid spammy language
- Follow LinkedIn's best practices
- Respect daily connection limits

Always prioritize quality over quantity in outreach.`,
      status: 'ACTIVE',
      tokenLimit: 50000,
      tokensUsed: 12300,
      executionLimit: 500,
      executionsUsed: 89,
      isEnabled: true,
      memoryEnabled: true,
    },
    {
      name: 'SEO Auditor',
      description: 'Analyzes websites and provides SEO recommendations',
      type: 'SEO_AUDIT',
      systemPrompt: `You are an SEO Audit AI agent. You analyze websites and provide actionable SEO recommendations.

Audit Checklist:
1. Site structure and crawlability
2. Page speed and Core Web Vitals
3. Mobile-friendliness
4. Content quality and relevance
5. Meta tags and headers
6. Internal linking structure
7. Schema markup presence

Provide clear, prioritized recommendations with implementation guidance.`,
      status: 'PAUSED',
      tokenLimit: 200000,
      tokensUsed: 45000,
      executionLimit: 200,
      executionsUsed: 34,
      isEnabled: false,
      memoryEnabled: true,
    },
  ];

  for (const agentData of sampleAgents) {
    await prisma.agent.upsert({
      where: {
        id: `agent-${agentData.name.toLowerCase().replace(/\s+/g, '-')}`,
      },
      update: {},
      create: {
        ...agentData,
        id: `agent-${agentData.name.toLowerCase().replace(/\s+/g, '-')}`,
        workspaceId: demoWorkspace.id,
        configuration: {},
        memoryContext: {},
      },
    });
  }
  console.log('Created sample agents:', sampleAgents.length);

  // Create system settings
  const systemSettings = [
    {
      key: 'platform_name',
      value: 'BOB XD',
      category: 'branding',
    },
    {
      key: 'platform_tagline',
      value: 'Build Your AI Empire',
      category: 'branding',
    },
    {
      key: 'maintenance_mode',
      value: false,
      category: 'system',
    },
    {
      key: 'registration_enabled',
      value: true,
      category: 'system',
    },
  ];

  for (const setting of systemSettings) {
    await prisma.systemSetting.upsert({
      where: { key: setting.key },
      update: {},
      create: setting,
    });
  }
  console.log('Created system settings:', systemSettings.length);

  console.log('\n✅ Database seed completed successfully!');
  console.log('\nDemo credentials:');
  console.log('  Email: demo@example.com');
  console.log('  Password: demo123');
  console.log('\nAdmin credentials:');
  console.log('  Email: admin@bobxd.ai');
  console.log('  Password: admin123');
}

main()
  .catch((e) => {
    console.error('Seed failed:', e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
