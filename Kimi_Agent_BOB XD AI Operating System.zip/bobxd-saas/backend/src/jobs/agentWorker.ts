/**
 * @fileoverview Agent Job Worker
 * Processes agent execution jobs from BullMQ queue
 */

import { Worker, Job } from 'bullmq';
import { redisBullMq } from '@config/redis';
import { prisma } from '@prisma/client';
import { openclawService } from '@services/openclaw.service';
import { logger } from '@utils/logger';
import { websocketManager } from '@websocket/manager';
import { ExecutionStatusType } from '@types/index';

/**
 * Job data interface
 */
interface AgentJobData {
  agentId: string;
  taskType: string;
  input: Record<string, unknown>;
}

/**
 * Creates and configures the agent job worker
 */
export function createAgentWorker(): Worker {
  const worker = new Worker<AgentJobData>(
    'agent-execution',
    async (job: Job<AgentJobData>) => {
      const { agentId, taskType, input } = job.data;
      const startTime = Date.now();

      logger.info({ jobId: job.id, agentId, taskType }, 'Processing agent job');

      try {
        // Check quota before execution
        const quotaCheck = await openclawService.checkAgentQuota(agentId);
        if (!quotaCheck.canExecute) {
          throw new Error(`Quota check failed: ${quotaCheck.reason}`);
        }

        // Get agent details
        const agent = await prisma.agent.findUnique({
          where: { id: agentId },
          select: { workspaceId: true, name: true },
        });

        if (!agent) {
          throw new Error('Agent not found');
        }

        // Create execution record
        const execution = await prisma.agentExecution.create({
          data: {
            agentId,
            workspaceId: agent.workspaceId,
            taskType,
            input,
            status: 'RUNNING',
            startedAt: new Date(),
          },
        });

        // Broadcast execution started
        websocketManager.broadcastToWorkspace(agent.workspaceId, {
          type: 'execution:started',
          payload: {
            executionId: execution.id,
            agentId,
            taskType,
            startedAt: execution.startedAt,
          },
          timestamp: Date.now(),
        });

        // Execute task
        const result = await openclawService.executeTask(agentId, taskType, input);

        const executionTime = Date.now() - startTime;

        // Update execution record
        await prisma.agentExecution.update({
          where: { id: execution.id },
          data: {
            status: result.success ? 'COMPLETED' : 'FAILED',
            output: result.data as any,
            tokensUsed: result.tokensUsed,
            executionTime,
            error: result.error,
            completedAt: new Date(),
          },
        });

        // Track token usage
        if (result.tokensUsed > 0) {
          await openclawService.trackTokenUsage(agentId, result.tokensUsed);
        }

        // Broadcast execution completed
        websocketManager.broadcastToWorkspace(agent.workspaceId, {
          type: 'execution:completed',
          payload: {
            executionId: execution.id,
            agentId,
            taskType,
            status: result.success ? 'COMPLETED' : 'FAILED',
            executionTime,
            tokensUsed: result.tokensUsed,
            result: result.data,
            error: result.error,
          },
          timestamp: Date.now(),
        });

        logger.info(
          { jobId: job.id, agentId, executionId: execution.id, success: result.success, executionTime },
          'Agent job completed'
        );

        return {
          success: result.success,
          executionId: execution.id,
          executionTime,
          tokensUsed: result.tokensUsed,
        };
      } catch (error) {
        const executionTime = Date.now() - startTime;
        const errorMessage = error instanceof Error ? error.message : 'Unknown error';

        logger.error(
          { jobId: job.id, agentId, error: errorMessage, executionTime },
          'Agent job failed'
        );

        // Get agent workspace for error broadcast
        const agent = await prisma.agent.findUnique({
          where: { id: agentId },
          select: { workspaceId: true },
        });

        if (agent) {
          websocketManager.broadcastToWorkspace(agent.workspaceId, {
            type: 'execution:failed',
            payload: {
              jobId: job.id,
              agentId,
              taskType,
              error: errorMessage,
            },
            timestamp: Date.now(),
          });
        }

        throw error;
      }
    },
    {
      connection: redisBullMq,
      concurrency: 5,
      limiter: {
        max: 10,
        duration: 1000,
      },
    }
  );

  // Event handlers
  worker.on('completed', (job) => {
    logger.debug({ jobId: job.id }, 'Job completed successfully');
  });

  worker.on('failed', (job, error) => {
    logger.error({ jobId: job?.id, error: error.message }, 'Job failed');
  });

  worker.on('error', (error) => {
    logger.error({ error }, 'Worker error');
  });

  return worker;
}

/**
 * Gracefully shuts down the worker
 */
export async function shutdownWorker(worker: Worker): Promise<void> {
  await worker.close();
  logger.info('Agent worker shut down');
}
