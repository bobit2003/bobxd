/**
 * @fileoverview Prisma Client Singleton
 * Manages database connection with proper lifecycle handling
 */

import { PrismaClient } from '@prisma/client';
import { config } from '@config/index';
import { logger } from '@utils/logger';

/**
 * Prisma client configuration based on environment
 */
const prismaClientSingleton = () => {
  return new PrismaClient({
    log: config.server.isDevelopment
      ? ['query', 'info', 'warn', 'error']
      : ['error', 'warn'],
  });
};

type PrismaClientSingleton = ReturnType<typeof prismaClientSingleton>;

const globalForPrisma = globalThis as unknown as {
  prisma: PrismaClientSingleton | undefined;
};

/**
 * Singleton Prisma client instance
 */
export const prisma = globalForPrisma.prisma ?? prismaClientSingleton();

if (config.server.isDevelopment) {
  globalForPrisma.prisma = prisma;
}

/**
 * Connects to the database
 */
export async function connectDatabase(): Promise<void> {
  try {
    await prisma.$connect();
    logger.info('Database connected successfully');
  } catch (error) {
    logger.error({ error }, 'Failed to connect to database');
    throw error;
  }
}

/**
 * Disconnects from the database
 */
export async function disconnectDatabase(): Promise<void> {
  try {
    await prisma.$disconnect();
    logger.info('Database disconnected successfully');
  } catch (error) {
    logger.error({ error }, 'Error disconnecting from database');
    throw error;
  }
}

/**
 * Executes a transaction with proper error handling
 * @param fn - Transaction function
 * @returns Transaction result
 */
export async function executeTransaction<T>(
  fn: (tx: Omit<PrismaClient, '$connect' | '$disconnect' | '$on' | '$transaction' | '$use' | '$extends'>) => Promise<T>
): Promise<T> {
  return prisma.$transaction(async (tx) => {
    return fn(tx);
  }, {
    maxWait: 5000,
    timeout: 10000,
  });
}

export default prisma;
