/**
 * @fileoverview BOB XD Type Definitions
 * Centralized type definitions for the entire application
 */

import { z } from 'zod';

// ==================== USER TYPES ====================

export const UserRole = {
  SUPER_ADMIN: 'SUPER_ADMIN',
  ADMIN: 'ADMIN',
  MANAGER: 'MANAGER',
  MEMBER: 'MEMBER',
  VIEWER: 'VIEWER',
} as const;

export type UserRoleType = typeof UserRole[keyof typeof UserRole];

export interface User {
  id: string;
  email: string;
  firstName: string;
  lastName: string;
  avatar?: string;
  isActive: boolean;
  emailVerified: boolean;
  lastLoginAt?: Date;
  createdAt: Date;
  updatedAt: Date;
}

export interface UserWithWorkspaces extends User {
  workspaces: WorkspaceMember[];
}

// ==================== WORKSPACE TYPES ====================

export interface Workspace {
  id: string;
  name: string;
  slug: string;
  description?: string;
  logo?: string;
  isActive: boolean;
  settings: Record<string, unknown>;
  ownerId: string;
  createdAt: Date;
  updatedAt: Date;
}

export interface WorkspaceMember {
  id: string;
  userId: string;
  workspaceId: string;
  role: UserRoleType;
  joinedAt: Date;
  updatedAt: Date;
  user?: User;
}

export interface WorkspaceWithMembers extends Workspace {
  members: (WorkspaceMember & { user: User })[];
  subscription?: Subscription;
}

// ==================== LEAD TYPES ====================

export const LeadStatus = {
  NEW: 'NEW',
  CONTACTED: 'CONTACTED',
  QUALIFIED: 'QUALIFIED',
  PROPOSAL: 'PROPOSAL',
  NEGOTIATION: 'NEGOTIATION',
  CLOSED_WON: 'CLOSED_WON',
  CLOSED_LOST: 'CLOSED_LOST',
  ARCHIVED: 'ARCHIVED',
} as const;

export type LeadStatusType = typeof LeadStatus[keyof typeof LeadStatus];

export interface Lead {
  id: string;
  firstName: string;
  lastName: string;
  email: string;
  phone?: string;
  company?: string;
  title?: string;
  source: string;
  status: LeadStatusType;
  score: number;
  tags: string[];
  notes?: string;
  customFields: Record<string, unknown>;
  lastContactAt?: Date;
  workspaceId: string;
  createdAt: Date;
  updatedAt: Date;
}

export interface LeadActivity {
  id: string;
  leadId: string;
  type: string;
  description: string;
  metadata: Record<string, unknown>;
  agentId?: string;
  createdAt: Date;
}

// ==================== AGENT TYPES ====================

export const AgentStatus = {
  ACTIVE: 'ACTIVE',
  PAUSED: 'PAUSED',
  ERROR: 'ERROR',
  MAINTENANCE: 'MAINTENANCE',
} as const;

export type AgentStatusType = typeof AgentStatus[keyof typeof AgentStatus];

export const AgentType = {
  LEAD_HUNTER: 'LEAD_HUNTER',
  LINKEDIN_OUTREACH: 'LINKEDIN_OUTREACH',
  SEO_AUDIT: 'SEO_AUDIT',
  ADS_STRATEGY: 'ADS_STRATEGY',
  CONTENT_GENERATOR: 'CONTENT_GENERATOR',
  CRM_AUTOMATION: 'CRM_AUTOMATION',
} as const;

export type AgentTypeType = typeof AgentType[keyof typeof AgentType];

export interface Agent {
  id: string;
  name: string;
  description?: string;
  type: string;
  systemPrompt: string;
  configuration: Record<string, unknown>;
  status: AgentStatusType;
  tokenLimit: number;
  tokensUsed: number;
  executionLimit: number;
  executionsUsed: number;
  isEnabled: boolean;
  memoryEnabled: boolean;
  memoryContext: Record<string, unknown>;
  workspaceId: string;
  createdAt: Date;
  updatedAt: Date;
}

export const ExecutionStatus = {
  PENDING: 'PENDING',
  RUNNING: 'RUNNING',
  COMPLETED: 'COMPLETED',
  FAILED: 'FAILED',
  RETRYING: 'RETRYING',
  CANCELLED: 'CANCELLED',
} as const;

export type ExecutionStatusType = typeof ExecutionStatus[keyof typeof ExecutionStatus];

export interface AgentExecution {
  id: string;
  agentId: string;
  workspaceId: string;
  taskType: string;
  input: Record<string, unknown>;
  output?: Record<string, unknown>;
  status: ExecutionStatusType;
  tokensUsed: number;
  executionTime?: number;
  error?: string;
  retryCount: number;
  scheduledAt?: Date;
  startedAt?: Date;
  completedAt?: Date;
  createdAt: Date;
  updatedAt: Date;
}

// ==================== SUBSCRIPTION TYPES ====================

export const PlanType = {
  STARTER: 'STARTER',
  PRO: 'PRO',
  AGENCY: 'AGENCY',
} as const;

export type PlanTypeType = typeof PlanType[keyof typeof PlanType];

export const SubscriptionStatus = {
  ACTIVE: 'ACTIVE',
  PAST_DUE: 'PAST_DUE',
  CANCELLED: 'CANCELLED',
  EXPIRED: 'EXPIRED',
  TRIAL: 'TRIAL',
} as const;

export type SubscriptionStatusType = typeof SubscriptionStatus[keyof typeof SubscriptionStatus];

export interface PlanLimits {
  maxAgents: number;
  maxLeads: number;
  maxExecutions: number;
  maxTokens: number;
  features: string[];
}

export const PLAN_LIMITS: Record<PlanTypeType, PlanLimits> = {
  STARTER: {
    maxAgents: 3,
    maxLeads: 500,
    maxExecutions: 1000,
    maxTokens: 100000,
    features: ['basic_agents', 'lead_management', 'email_support'],
  },
  PRO: {
    maxAgents: 10,
    maxLeads: 5000,
    maxExecutions: 10000,
    maxTokens: 1000000,
    features: ['advanced_agents', 'lead_management', 'campaigns', 'analytics', 'priority_support', 'api_access'],
  },
  AGENCY: {
    maxAgents: 50,
    maxLeads: 50000,
    maxExecutions: 100000,
    maxTokens: 10000000,
    features: ['all_agents', 'lead_management', 'campaigns', 'analytics', 'white_label', 'dedicated_support', 'api_access', 'custom_integrations'],
  },
};

export interface Subscription {
  id: string;
  workspaceId: string;
  plan: PlanTypeType;
  status: SubscriptionStatusType;
  currentPeriodStart: Date;
  currentPeriodEnd: Date;
  trialEndsAt?: Date;
  cancelAtPeriodEnd: boolean;
  stripeCustomerId?: string;
  stripeSubscriptionId?: string;
  paymentMethodId?: string;
  billingEmail?: string;
  usageLimits: Record<string, unknown>;
  features: string[];
  gracePeriodEndsAt?: Date;
  createdAt: Date;
  updatedAt: Date;
}

// ==================== API KEY TYPES ====================

export interface ApiKey {
  id: string;
  name: string;
  keyHash: string;
  keyPrefix: string;
  permissions: string[];
  isActive: boolean;
  lastUsedAt?: Date;
  expiresAt?: Date;
  workspaceId: string;
  userId: string;
  createdAt: Date;
  updatedAt: Date;
}

// ==================== AUDIT LOG TYPES ====================

export const AuditAction = {
  CREATE: 'CREATE',
  UPDATE: 'UPDATE',
  DELETE: 'DELETE',
  LOGIN: 'LOGIN',
  LOGOUT: 'LOGOUT',
  EXECUTE: 'EXECUTE',
  EXPORT: 'EXPORT',
  IMPORT: 'IMPORT',
  SETTINGS_CHANGE: 'SETTINGS_CHANGE',
} as const;

export type AuditActionType = typeof AuditAction[keyof typeof AuditAction];

export interface AuditLog {
  id: string;
  action: AuditActionType;
  entityType: string;
  entityId?: string;
  description: string;
  oldValues?: Record<string, unknown>;
  newValues?: Record<string, unknown>;
  userId?: string;
  workspaceId?: string;
  ipAddress?: string;
  userAgent?: string;
  createdAt: Date;
}

// ==================== AUTH TYPES ====================

export interface TokenPayload {
  userId: string;
  email: string;
  role: UserRoleType;
  workspaceId?: string;
}

export interface AuthTokens {
  accessToken: string;
  refreshToken: string;
  expiresIn: number;
}

// ==================== OPENCLAW TYPES ====================

export interface OpenClawTask {
  id: string;
  agentId: string;
  type: string;
  input: Record<string, unknown>;
  priority?: number;
  scheduledAt?: Date;
}

export interface OpenClawResponse {
  success: boolean;
  data?: Record<string, unknown>;
  error?: string;
  tokensUsed: number;
  executionTime: number;
}

// ==================== WEBSOCKET TYPES ====================

export interface WebSocketMessage {
  type: string;
  payload: unknown;
  timestamp: number;
}

export interface ExecutionUpdateMessage extends WebSocketMessage {
  type: 'execution:update';
  payload: {
    executionId: string;
    agentId: string;
    status: ExecutionStatusType;
    progress?: number;
    result?: Record<string, unknown>;
    error?: string;
  };
}

// ==================== VALIDATION SCHEMAS ====================

export const createUserSchema = z.object({
  email: z.string().email(),
  password: z.string().min(8),
  firstName: z.string().min(1),
  lastName: z.string().min(1),
});

export const loginSchema = z.object({
  email: z.string().email(),
  password: z.string(),
});

export const createWorkspaceSchema = z.object({
  name: z.string().min(1).max(100),
  slug: z.string().min(3).max(50).regex(/^[a-z0-9-]+$/),
  description: z.string().optional(),
});

export const createLeadSchema = z.object({
  firstName: z.string().min(1),
  lastName: z.string().min(1),
  email: z.string().email(),
  phone: z.string().optional(),
  company: z.string().optional(),
  title: z.string().optional(),
  source: z.string().min(1),
  tags: z.array(z.string()).default([]),
  notes: z.string().optional(),
  customFields: z.record(z.unknown()).default({}),
});

export const createAgentSchema = z.object({
  name: z.string().min(1).max(100),
  description: z.string().optional(),
  type: z.enum(['LEAD_HUNTER', 'LINKEDIN_OUTREACH', 'SEO_AUDIT', 'ADS_STRATEGY', 'CONTENT_GENERATOR', 'CRM_AUTOMATION']),
  systemPrompt: z.string().min(1),
  configuration: z.record(z.unknown()).default({}),
  tokenLimit: z.number().int().positive().default(100000),
  executionLimit: z.number().int().positive().default(1000),
  memoryEnabled: z.boolean().default(true),
});

export const executeAgentSchema = z.object({
  agentId: z.string().uuid(),
  taskType: z.string().min(1),
  input: z.record(z.unknown()),
  scheduledAt: z.string().datetime().optional(),
});

export type CreateUserInput = z.infer<typeof createUserSchema>;
export type LoginInput = z.infer<typeof loginSchema>;
export type CreateWorkspaceInput = z.infer<typeof createWorkspaceSchema>;
export type CreateLeadInput = z.infer<typeof createLeadSchema>;
export type CreateAgentInput = z.infer<typeof createAgentSchema>;
export type ExecuteAgentInput = z.infer<typeof executeAgentSchema>;
