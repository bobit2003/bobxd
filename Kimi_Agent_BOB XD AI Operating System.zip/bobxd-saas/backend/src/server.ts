/**
 * @fileoverview BOB XD Backend Server
 * Main entry point for the AI Operating System API
 */

import Fastify from 'fastify';
import cors from '@fastify/cors';
import helmet from '@fastify/helmet';
import rateLimit from '@fastify/rate-limit';
import jwt from '@fastify/jwt';
import { config } from '@config/index';
import { connectDatabase, disconnectDatabase } from '@prisma/client';
import { redis, closeRedisConnections } from '@config/redis';
import { logger } from '@utils/logger';
import { errorHandler, notFoundHandler } from '@middleware/errorHandler';
import { createAgentWorker, shutdownWorker } from '@jobs/agentWorker';
import { websocketManager } from '@websocket/manager';

// Import routes
import { authRoutes } from '@routes/auth';
import { workspaceRoutes } from '@routes/workspaces';
import { leadRoutes } from '@routes/leads';
import { agentRoutes } from '@routes/agents';
import { subscriptionRoutes } from '@routes/subscriptions';
import { adminRoutes } from '@routes/admin';

/**
 * Creates and configures the Fastify server
 */
async function createServer() {
  // Initialize Fastify
  const fastify = Fastify({
    logger: config.server.isDevelopment,
    trustProxy: true,
  });

  // ==================== SECURITY MIDDLEWARE ====================

  // CORS configuration
  await fastify.register(cors, {
    origin: config.frontend.url,
    credentials: true,
    methods: ['GET', 'POST', 'PUT', 'PATCH', 'DELETE', 'OPTIONS'],
    allowedHeaders: ['Content-Type', 'Authorization', 'X-API-Key'],
  });

  // Helmet for security headers
  await fastify.register(helmet, {
    contentSecurityPolicy: {
      directives: {
        defaultSrc: ["'self'"],
        styleSrc: ["'self'", "'unsafe-inline'"],
        scriptSrc: ["'self'"],
        imgSrc: ["'self'", 'data:', 'https:'],
      },
    },
  });

  // Rate limiting
  await fastify.register(rateLimit, {
    max: config.rateLimit.max,
    timeWindow: config.rateLimit.windowMs,
    redis: redis,
    keyGenerator: (req) => {
      return req.user?.userId || req.ip;
    },
    errorResponseBuilder: (req, context) => ({
      success: false,
      error: 'Rate limit exceeded',
      code: 'RATE_LIMIT_ERROR',
      retryAfter: context.after,
    }),
  });

  // JWT configuration
  await fastify.register(jwt, {
    secret: config.jwt.secret,
    sign: {
      expiresIn: config.jwt.accessExpiration,
    },
  });

  // ==================== ERROR HANDLING ====================

  fastify.setErrorHandler(errorHandler);
  fastify.setNotFoundHandler(notFoundHandler);

  // ==================== HEALTH CHECK ====================

  fastify.get('/health', async (request, reply) => {
    const healthcheck = {
      uptime: process.uptime(),
      message: 'OK',
      timestamp: Date.now(),
      version: process.env.npm_package_version || '1.0.0',
      environment: config.server.env,
      services: {
        database: 'unknown',
        redis: 'unknown',
      },
    };

    try {
      // Check database
      await connectDatabase();
      healthcheck.services.database = 'connected';
    } catch (error) {
      healthcheck.services.database = 'disconnected';
      healthcheck.message = 'Service degraded';
    }

    try {
      // Check Redis
      await redis.ping();
      healthcheck.services.redis = 'connected';
    } catch (error) {
      healthcheck.services.redis = 'disconnected';
      healthcheck.message = 'Service degraded';
    }

    const statusCode = healthcheck.message === 'OK' ? 200 : 503;
    return reply.status(statusCode).send(healthcheck);
  });

  // ==================== API ROUTES ====================

  // API version prefix
  const API_PREFIX = '/api/v1';

  // Register routes
  await fastify.register(authRoutes, { prefix: `${API_PREFIX}/auth` });
  await fastify.register(workspaceRoutes, { prefix: `${API_PREFIX}/workspaces` });
  await fastify.register(leadRoutes, { prefix: `${API_PREFIX}/leads` });
  await fastify.register(agentRoutes, { prefix: `${API_PREFIX}/agents` });
  await fastify.register(subscriptionRoutes, { prefix: `${API_PREFIX}/subscriptions` });
  await fastify.register(adminRoutes, { prefix: `${API_PREFIX}/admin` });

  // ==================== WEBSOCKET ====================

  websocketManager.initialize(fastify);

  // ==================== ROOT ENDPOINT ====================

  fastify.get('/', async (request, reply) => {
    return reply.send({
      name: 'BOB XD API',
      version: '1.0.0',
      description: 'AI Operating System for Agencies',
      documentation: '/documentation',
      health: '/health',
    });
  });

  return fastify;
}

/**
 * Starts the server
 */
async function startServer() {
  try {
    // Connect to database
    await connectDatabase();
    logger.info('Database connected');

    // Create server
    const fastify = await createServer();

    // Start agent worker
    const agentWorker = createAgentWorker();
    logger.info('Agent worker started');

    // Start server
    const address = await fastify.listen({
      port: config.server.port,
      host: config.server.host,
    });

    logger.info(`BOB XD Server running at ${address}`);
    logger.info(`Environment: ${config.server.env}`);
    logger.info(`API Documentation: ${address}/api/v1`);

    // Graceful shutdown handlers
    const shutdown = async (signal: string) => {
      logger.info(`${signal} received. Starting graceful shutdown...`);

      // Close server (stop accepting new connections)
      await fastify.close();
      logger.info('HTTP server closed');

      // Shutdown worker
      await shutdownWorker(agentWorker);

      // Close database connection
      await disconnectDatabase();
      logger.info('Database connection closed');

      // Close Redis connections
      await closeRedisConnections();

      logger.info('Graceful shutdown completed');
      process.exit(0);
    };

    process.on('SIGTERM', () => shutdown('SIGTERM'));
    process.on('SIGINT', () => shutdown('SIGINT'));

    // Handle uncaught errors
    process.on('uncaughtException', (error) => {
      logger.fatal({ error }, 'Uncaught exception');
      shutdown('UNCAUGHT_EXCEPTION');
    });

    process.on('unhandledRejection', (reason) => {
      logger.fatal({ reason }, 'Unhandled rejection');
      shutdown('UNHANDLED_REJECTION');
    });

  } catch (error) {
    logger.fatal({ error }, 'Failed to start server');
    process.exit(1);
  }
}

// Start the server
startServer();
