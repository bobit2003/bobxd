/**
 * @fileoverview WebSocket Manager
 * Manages real-time communication for execution updates
 */

import { FastifyInstance } from 'fastify';
import { WebSocket } from 'ws';
import { logger } from '@utils/logger';
import { cache } from '@config/redis';
import { WebSocketMessage } from '@types/index';

/**
 * Extended WebSocket interface with metadata
 */
interface ExtendedWebSocket extends WebSocket {
  isAlive: boolean;
  workspaceId?: string;
  userId?: string;
}

/**
 * WebSocket connection manager
 */
class WebSocketManager {
  private connections: Map<string, ExtendedWebSocket> = new Map();
  private workspaceConnections: Map<string, Set<string>> = new Map();

  /**
   * Initializes WebSocket server
   * @param fastify - Fastify instance
   */
  initialize(fastify: FastifyInstance): void {
    fastify.register(require('@fastify/websocket'), {
      options: {
        maxPayload: 1048576, // 1MB
        clientTracking: true,
      },
    });

    fastify.register(async (fastify) => {
      fastify.get('/ws', { websocket: true }, (connection, req) => {
        const ws = connection.socket as ExtendedWebSocket;
        const connectionId = this.generateConnectionId();

        ws.isAlive = true;
        this.connections.set(connectionId, ws);

        logger.info({ connectionId, ip: req.ip }, 'WebSocket connection established');

        // Handle ping/pong for connection health
        ws.on('pong', () => {
          ws.isAlive = true;
        });

        // Handle messages
        ws.on('message', async (message: Buffer) => {
          try {
            const data = JSON.parse(message.toString());
            await this.handleMessage(connectionId, ws, data);
          } catch (error) {
            logger.error({ connectionId, error }, 'Failed to parse WebSocket message');
            this.sendToConnection(connectionId, {
              type: 'error',
              payload: { message: 'Invalid message format' },
              timestamp: Date.now(),
            });
          }
        });

        // Handle close
        ws.on('close', () => {
          this.removeConnection(connectionId);
          logger.info({ connectionId }, 'WebSocket connection closed');
        });

        // Handle errors
        ws.on('error', (error) => {
          logger.error({ connectionId, error }, 'WebSocket error');
        });

        // Send welcome message
        this.sendToConnection(connectionId, {
          type: 'connected',
          payload: { connectionId },
          timestamp: Date.now(),
        });
      });
    });

    // Start heartbeat interval
    this.startHeartbeat();
  }

  /**
   * Handles incoming WebSocket messages
   */
  private async handleMessage(
    connectionId: string,
    ws: ExtendedWebSocket,
    data: { type: string; payload?: Record<string, unknown> }
  ): Promise<void> {
    switch (data.type) {
      case 'auth':
        await this.handleAuth(connectionId, ws, data.payload);
        break;

      case 'subscribe':
        await this.handleSubscribe(connectionId, ws, data.payload);
        break;

      case 'unsubscribe':
        this.handleUnsubscribe(connectionId, ws);
        break;

      case 'ping':
        this.sendToConnection(connectionId, {
          type: 'pong',
          payload: {},
          timestamp: Date.now(),
        });
        break;

      default:
        this.sendToConnection(connectionId, {
          type: 'error',
          payload: { message: `Unknown message type: ${data.type}` },
          timestamp: Date.now(),
        });
    }
  }

  /**
   * Handles authentication
   */
  private async handleAuth(
    connectionId: string,
    ws: ExtendedWebSocket,
    payload?: Record<string, unknown>
  ): Promise<void> {
    try {
      const token = payload?.token as string;

      if (!token) {
        this.sendToConnection(connectionId, {
          type: 'auth:error',
          payload: { message: 'Token required' },
          timestamp: Date.now(),
        });
        return;
      }

      // Verify token from cache or JWT
      const cached = await cache.get<{ userId: string; workspaceId?: string }>(`ws:token:${token}`);

      if (cached) {
        ws.userId = cached.userId;
        ws.workspaceId = cached.workspaceId;
      }

      this.sendToConnection(connectionId, {
        type: 'auth:success',
        payload: { userId: ws.userId },
        timestamp: Date.now(),
      });
    } catch (error) {
      logger.error({ connectionId, error }, 'WebSocket auth failed');
      this.sendToConnection(connectionId, {
        type: 'auth:error',
        payload: { message: 'Authentication failed' },
        timestamp: Date.now(),
      });
    }
  }

  /**
   * Handles workspace subscription
   */
  private async handleSubscribe(
    connectionId: string,
    ws: ExtendedWebSocket,
    payload?: Record<string, unknown>
  ): Promise<void> {
    const workspaceId = payload?.workspaceId as string;

    if (!workspaceId) {
      this.sendToConnection(connectionId, {
        type: 'subscribe:error',
        payload: { message: 'Workspace ID required' },
        timestamp: Date.now(),
      });
      return;
    }

    // Set workspace for this connection
    ws.workspaceId = workspaceId;

    // Add to workspace connections
    if (!this.workspaceConnections.has(workspaceId)) {
      this.workspaceConnections.set(workspaceId, new Set());
    }
    this.workspaceConnections.get(workspaceId)!.add(connectionId);

    this.sendToConnection(connectionId, {
      type: 'subscribe:success',
      payload: { workspaceId },
      timestamp: Date.now(),
    });

    logger.debug({ connectionId, workspaceId }, 'Subscribed to workspace');
  }

  /**
   * Handles unsubscription
   */
  private handleUnsubscribe(connectionId: string, ws: ExtendedWebSocket): void {
    if (ws.workspaceId) {
      const connections = this.workspaceConnections.get(ws.workspaceId);
      if (connections) {
        connections.delete(connectionId);
        if (connections.size === 0) {
          this.workspaceConnections.delete(ws.workspaceId);
        }
      }
      ws.workspaceId = undefined;
    }

    this.sendToConnection(connectionId, {
      type: 'unsubscribe:success',
      payload: {},
      timestamp: Date.now(),
    });
  }

  /**
   * Removes a connection
   */
  private removeConnection(connectionId: string): void {
    const ws = this.connections.get(connectionId);

    if (ws?.workspaceId) {
      const connections = this.workspaceConnections.get(ws.workspaceId);
      if (connections) {
        connections.delete(connectionId);
        if (connections.size === 0) {
          this.workspaceConnections.delete(ws.workspaceId);
        }
      }
    }

    this.connections.delete(connectionId);
  }

  /**
   * Sends message to a specific connection
   */
  sendToConnection(connectionId: string, message: WebSocketMessage): boolean {
    const ws = this.connections.get(connectionId);

    if (ws?.readyState === WebSocket.OPEN) {
      ws.send(JSON.stringify(message));
      return true;
    }

    return false;
  }

  /**
   * Broadcasts message to all connections in a workspace
   */
  broadcastToWorkspace(workspaceId: string, message: WebSocketMessage): number {
    const connections = this.workspaceConnections.get(workspaceId);
    let sentCount = 0;

    if (connections) {
      connections.forEach((connectionId) => {
        if (this.sendToConnection(connectionId, message)) {
          sentCount++;
        }
      });
    }

    return sentCount;
  }

  /**
   * Broadcasts message to all connections
   */
  broadcast(message: WebSocketMessage): number {
    let sentCount = 0;

    this.connections.forEach((ws, connectionId) => {
      if (this.sendToConnection(connectionId, message)) {
        sentCount++;
      }
    });

    return sentCount;
  }

  /**
   * Starts heartbeat interval to check connection health
   */
  private startHeartbeat(): void {
    const interval = setInterval(() => {
      this.connections.forEach((ws, connectionId) => {
        if (!ws.isAlive) {
          ws.terminate();
          this.removeConnection(connectionId);
          return;
        }

        ws.isAlive = false;
        ws.ping();
      });
    }, 30000);

    // Don't prevent process exit
    interval.unref();
  }

  /**
   * Generates unique connection ID
   */
  private generateConnectionId(): string {
    return `ws_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
  }

  /**
   * Gets connection statistics
   */
  getStats(): { totalConnections: number; workspaceSubscriptions: number } {
    return {
      totalConnections: this.connections.size,
      workspaceSubscriptions: this.workspaceConnections.size,
    };
  }
}

// Export singleton instance
export const websocketManager = new WebSocketManager();
export default websocketManager;
