/**
 * @fileoverview OpenClaw Service
 * Core AI integration service for agent management and task execution
 */

import axios, { AxiosInstance, AxiosError } from 'axios';
import { Queue, Job } from 'bullmq';
import { config } from '@config/index';
import { redisBullMq } from '@config/redis';
import { prisma } from '@prisma/client';
import { logger } from '@utils/logger';
import { cache } from '@config/redis';
import {
  Agent,
  AgentExecution,
  OpenClawTask,
  OpenClawResponse,
  ExecutionStatusType,
} from '@types/index';

/**
 * OpenClaw API client configuration
 */
const openclawClient: AxiosInstance = axios.create({
  baseURL: config.openclaw.apiUrl,
  headers: {
    'Authorization': `Bearer ${config.openclaw.apiKey}`,
    'Content-Type': 'application/json',
  },
  timeout: 120000, // 2 minute timeout for AI operations
});

/**
 * BullMQ queue for agent task execution
 */
export const agentQueue = new Queue('agent-execution', {
  connection: redisBullMq,
  defaultJobOptions: {
    attempts: 3,
    backoff: {
      type: 'exponential',
      delay: 5000,
    },
    removeOnComplete: {
      age: 24 * 3600, // Keep completed jobs for 24 hours
      count: 1000,
    },
    removeOnFail: {
      age: 7 * 24 * 3600, // Keep failed jobs for 7 days
    },
  },
});

/**
 * OpenClaw Service - Core AI Operations
 */
export class OpenClawService {
  private static instance: OpenClawService;

  private constructor() {}

  /**
   * Gets singleton instance
   */
  static getInstance(): OpenClawService {
    if (!OpenClawService.instance) {
      OpenClawService.instance = new OpenClawService();
    }
    return OpenClawService.instance;
  }

  // ==================== AGENT MANAGEMENT ====================

  /**
   * Creates a new AI agent in OpenClaw
   * @param agent - Agent configuration
   * @returns Created agent data from OpenClaw
   */
  async createAgent(agent: Agent): Promise<{ success: boolean; openclawAgentId?: string; error?: string }> {
    try {
      logger.info({ agentId: agent.id }, 'Creating agent in OpenClaw');

      const response = await openclawClient.post('/agents', {
        name: agent.name,
        description: agent.description,
        system_prompt: agent.systemPrompt,
        configuration: {
          ...agent.configuration,
          token_limit: agent.tokenLimit,
          memory_enabled: agent.memoryEnabled,
        },
        metadata: {
          workspace_id: agent.workspaceId,
          agent_type: agent.type,
        },
      });

      const openclawAgentId = response.data.id;

      // Cache the agent mapping
      await cache.set(`openclaw:agent:${agent.id}`, { openclawAgentId }, 3600);

      logger.info({ agentId: agent.id, openclawAgentId }, 'Agent created in OpenClaw');

      return { success: true, openclawAgentId };
    } catch (error) {
      const axiosError = error as AxiosError;
      logger.error(
        { agentId: agent.id, error: axiosError.response?.data || axiosError.message },
        'Failed to create agent in OpenClaw'
      );
      return { success: false, error: axiosError.message };
    }
  }

  /**
   * Updates an existing agent in OpenClaw
   * @param agent - Updated agent configuration
   */
  async updateAgent(agent: Agent): Promise<{ success: boolean; error?: string }> {
    try {
      const cached = await cache.get<{ openclawAgentId: string }>(`openclaw:agent:${agent.id}`);
      const openclawAgentId = cached?.openclawAgentId;

      if (!openclawAgentId) {
        return { success: false, error: 'OpenClaw agent ID not found' };
      }

      await openclawClient.patch(`/agents/${openclawAgentId}`, {
        name: agent.name,
        description: agent.description,
        system_prompt: agent.systemPrompt,
        configuration: {
          ...agent.configuration,
          token_limit: agent.tokenLimit,
          memory_enabled: agent.memoryEnabled,
        },
        status: agent.status === 'ACTIVE' ? 'active' : 'paused',
      });

      logger.info({ agentId: agent.id }, 'Agent updated in OpenClaw');
      return { success: true };
    } catch (error) {
      const axiosError = error as AxiosError;
      logger.error({ agentId: agent.id, error: axiosError.message }, 'Failed to update agent');
      return { success: false, error: axiosError.message };
    }
  }

  /**
   * Deletes an agent from OpenClaw
   * @param agentId - Local agent ID
   */
  async deleteAgent(agentId: string): Promise<{ success: boolean; error?: string }> {
    try {
      const cached = await cache.get<{ openclawAgentId: string }>(`openclaw:agent:${agentId}`);
      const openclawAgentId = cached?.openclawAgentId;

      if (!openclawAgentId) {
        return { success: false, error: 'OpenClaw agent ID not found' };
      }

      await openclawClient.delete(`/agents/${openclawAgentId}`);
      await cache.del(`openclaw:agent:${agentId}`);

      logger.info({ agentId }, 'Agent deleted from OpenClaw');
      return { success: true };
    } catch (error) {
      const axiosError = error as AxiosError;
      logger.error({ agentId, error: axiosError.message }, 'Failed to delete agent');
      return { success: false, error: axiosError.message };
    }
  }

  // ==================== TASK EXECUTION ====================

  /**
   * Queues a task for execution
   * @param task - Task to execute
   * @returns Job instance
   */
  async queueTask(task: OpenClawTask): Promise<Job> {
    const job = await agentQueue.add(
      task.type,
      {
        agentId: task.agentId,
        input: task.input,
        taskType: task.type,
      },
      {
        priority: task.priority || 5,
        delay: task.scheduledAt ? new Date(task.scheduledAt).getTime() - Date.now() : undefined,
        jobId: task.id,
      }
    );

    logger.info({ jobId: job.id, agentId: task.agentId, taskType: task.type }, 'Task queued');
    return job;
  }

  /**
   * Executes a task immediately (synchronous)
   * @param agentId - Agent ID
   * @param taskType - Type of task
   * @param input - Task input data
   * @returns Execution result
   */
  async executeTask(
    agentId: string,
    taskType: string,
    input: Record<string, unknown>
  ): Promise<OpenClawResponse> {
    const startTime = Date.now();

    try {
      // Get OpenClaw agent ID
      const cached = await cache.get<{ openclawAgentId: string }>(`openclaw:agent:${agentId}`);
      const openclawAgentId = cached?.openclawAgentId;

      if (!openclawAgentId) {
        // Try to get from database
        const agent = await prisma.agent.findUnique({ where: { id: agentId } });
        if (!agent) {
          return {
            success: false,
            error: 'Agent not found',
            tokensUsed: 0,
            executionTime: 0,
          };
        }

        // Create agent in OpenClaw if not exists
        const createResult = await this.createAgent(agent);
        if (!createResult.success) {
          return {
            success: false,
            error: createResult.error,
            tokensUsed: 0,
            executionTime: 0,
          };
        }
      }

      const finalOpenclawId = (await cache.get<{ openclawAgentId: string }>(`openclaw:agent:${agentId}`))!.openclawAgentId;

      // Execute task
      const response = await openclawClient.post(`/agents/${finalOpenclawId}/execute`, {
        task_type: taskType,
        input,
      });

      const executionTime = Date.now() - startTime;

      logger.info(
        { agentId, taskType, tokensUsed: response.data.tokens_used, executionTime },
        'Task executed successfully'
      );

      return {
        success: true,
        data: response.data.result,
        tokensUsed: response.data.tokens_used || 0,
        executionTime,
      };
    } catch (error) {
      const executionTime = Date.now() - startTime;
      const axiosError = error as AxiosError;

      logger.error(
        { agentId, taskType, error: axiosError.response?.data || axiosError.message },
        'Task execution failed'
      );

      return {
        success: false,
        error: axiosError.response?.data?.message || axiosError.message,
        tokensUsed: 0,
        executionTime,
      };
    }
  }

  /**
   * Monitors execution status
   * @param executionId - Execution ID
   * @returns Current execution status
   */
  async monitorExecution(executionId: string): Promise<{
    status: ExecutionStatusType;
    progress?: number;
    result?: Record<string, unknown>;
    error?: string;
  }> {
    try {
      const response = await openclawClient.get(`/executions/${executionId}`);

      const statusMap: Record<string, ExecutionStatusType> = {
        pending: 'PENDING',
        running: 'RUNNING',
        completed: 'COMPLETED',
        failed: 'FAILED',
        retrying: 'RETRYING',
        cancelled: 'CANCELLED',
      };

      return {
        status: statusMap[response.data.status] || 'PENDING',
        progress: response.data.progress,
        result: response.data.result,
        error: response.data.error,
      };
    } catch (error) {
      logger.error({ executionId, error }, 'Failed to monitor execution');
      return { status: 'FAILED', error: 'Failed to fetch execution status' };
    }
  }

  /**
   * Retries a failed execution
   * @param executionId - Execution ID to retry
   */
  async retryOnFailure(executionId: string): Promise<{ success: boolean; newExecutionId?: string; error?: string }> {
    try {
      const response = await openclawClient.post(`/executions/${executionId}/retry`);

      logger.info({ executionId, newExecutionId: response.data.id }, 'Execution retried');

      return {
        success: true,
        newExecutionId: response.data.id,
      };
    } catch (error) {
      const axiosError = error as AxiosError;
      logger.error({ executionId, error: axiosError.message }, 'Failed to retry execution');
      return { success: false, error: axiosError.message };
    }
  }

  // ==================== TOKEN & MEMORY MANAGEMENT ====================

  /**
   * Tracks token usage for an agent
   * @param agentId - Agent ID
   * @param tokensUsed - Number of tokens used
   */
  async trackTokenUsage(agentId: string, tokensUsed: number): Promise<void> {
    try {
      await prisma.agent.update({
        where: { id: agentId },
        data: {
          tokensUsed: {
            increment: tokensUsed,
          },
        },
      });

      // Update usage log
      const agent = await prisma.agent.findUnique({
        where: { id: agentId },
        select: { workspaceId: true },
      });

      if (agent) {
        await prisma.usageLog.create({
          data: {
            workspaceId: agent.workspaceId,
            resourceType: 'AGENT_TOKENS',
            resourceId: agentId,
            action: 'TOKEN_USAGE',
            quantity: tokensUsed,
          },
        });
      }

      logger.debug({ agentId, tokensUsed }, 'Token usage tracked');
    } catch (error) {
      logger.error({ agentId, tokensUsed, error }, 'Failed to track token usage');
    }
  }

  /**
   * Stores agent memory/context
   * @param agentId - Agent ID
   * @param memoryData - Memory data to store
   */
  async storeAgentMemory(agentId: string, memoryData: Record<string, unknown>): Promise<void> {
    try {
      const cached = await cache.get<{ openclawAgentId: string }>(`openclaw:agent:${agentId}`);
      const openclawAgentId = cached?.openclawAgentId;

      if (openclawAgentId) {
        await openclawClient.post(`/agents/${openclawAgentId}/memory`, {
          memory: memoryData,
        });
      }

      // Also store in database
      await prisma.agent.update({
        where: { id: agentId },
        data: {
          memoryContext: memoryData,
        },
      });

      logger.debug({ agentId }, 'Agent memory stored');
    } catch (error) {
      logger.error({ agentId, error }, 'Failed to store agent memory');
    }
  }

  /**
   * Retrieves agent memory
   * @param agentId - Agent ID
   * @returns Memory context
   */
  async getAgentMemory(agentId: string): Promise<Record<string, unknown>> {
    try {
      const agent = await prisma.agent.findUnique({
        where: { id: agentId },
        select: { memoryContext: true },
      });

      return (agent?.memoryContext as Record<string, unknown>) || {};
    } catch (error) {
      logger.error({ agentId, error }, 'Failed to get agent memory');
      return {};
    }
  }

  // ==================== EXECUTION LOGGING ====================

  /**
   * Logs execution details
   * @param execution - Execution data
   */
  async logExecution(execution: AgentExecution): Promise<void> {
    try {
      await prisma.agentExecution.update({
        where: { id: execution.id },
        data: {
          status: execution.status,
          output: execution.output as any,
          tokensUsed: execution.tokensUsed,
          executionTime: execution.executionTime,
          error: execution.error,
          completedAt: execution.status === 'COMPLETED' ? new Date() : undefined,
        },
      });

      // Update agent execution count
      if (execution.status === 'COMPLETED' || execution.status === 'FAILED') {
        await prisma.agent.update({
          where: { id: execution.agentId },
          data: {
            executionsUsed: {
              increment: 1,
            },
          },
        });
      }

      logger.debug({ executionId: execution.id, status: execution.status }, 'Execution logged');
    } catch (error) {
      logger.error({ executionId: execution.id, error }, 'Failed to log execution');
    }
  }

  /**
   * Gets execution logs for an agent
   * @param agentId - Agent ID
   * @param limit - Number of logs to retrieve
   * @returns Execution logs
   */
  async getExecutionLogs(agentId: string, limit: number = 50): Promise<AgentExecution[]> {
    try {
      const logs = await prisma.agentExecution.findMany({
        where: { agentId },
        orderBy: { createdAt: 'desc' },
        take: limit,
      });

      return logs as AgentExecution[];
    } catch (error) {
      logger.error({ agentId, error }, 'Failed to get execution logs');
      return [];
    }
  }

  // ==================== UTILITY METHODS ====================

  /**
   * Checks if agent has available quota
   * @param agentId - Agent ID
   * @returns Boolean indicating if agent can execute
   */
  async checkAgentQuota(agentId: string): Promise<{ canExecute: boolean; reason?: string }> {
    try {
      const agent = await prisma.agent.findUnique({
        where: { id: agentId },
        include: {
          workspace: {
            include: {
              subscription: true,
            },
          },
        },
      });

      if (!agent) {
        return { canExecute: false, reason: 'Agent not found' };
      }

      if (!agent.isEnabled) {
        return { canExecute: false, reason: 'Agent is disabled' };
      }

      if (agent.status !== 'ACTIVE') {
        return { canExecute: false, reason: `Agent is ${agent.status.toLowerCase()}` };
      }

      // Check token limit
      if (agent.tokensUsed >= agent.tokenLimit) {
        return { canExecute: false, reason: 'Token limit exceeded' };
      }

      // Check execution limit
      if (agent.executionsUsed >= agent.executionLimit) {
        return { canExecute: false, reason: 'Execution limit exceeded' };
      }

      // Check subscription limits
      const subscription = agent.workspace.subscription;
      if (subscription && subscription.status !== 'ACTIVE' && subscription.status !== 'TRIAL') {
        return { canExecute: false, reason: 'Subscription not active' };
      }

      return { canExecute: true };
    } catch (error) {
      logger.error({ agentId, error }, 'Failed to check agent quota');
      return { canExecute: false, reason: 'Error checking quota' };
    }
  }

  /**
   * Gets queue statistics
   * @returns Queue stats
   */
  async getQueueStats(): Promise<{
    waiting: number;
    active: number;
    completed: number;
    failed: number;
    delayed: number;
  }> {
    const [waiting, active, completed, failed, delayed] = await Promise.all([
      agentQueue.getWaitingCount(),
      agentQueue.getActiveCount(),
      agentQueue.getCompletedCount(),
      agentQueue.getFailedCount(),
      agentQueue.getDelayedCount(),
    ]);

    return { waiting, active, completed, failed, delayed };
  }
}

// Export singleton instance
export const openclawService = OpenClawService.getInstance();
export default openclawService;
