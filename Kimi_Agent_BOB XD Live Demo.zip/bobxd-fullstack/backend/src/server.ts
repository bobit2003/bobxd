import Fastify from 'fastify';
import cors from '@fastify/cors';
import helmet from '@fastify/helmet';
import rateLimit from '@fastify/rate-limit';
import jwt from '@fastify/jwt';
import websocket from '@fastify/websocket';
import { config } from './config';
import { logger } from './utils/logger';
import { errorHandler, notFoundHandler } from './middleware/errorHandler';
import { prisma } from './prisma/client';
import { redis } from './config/redis';

// Import routes
import authRoutes from './routes/auth';
import workspaceRoutes from './routes/workspaces';
import leadRoutes from './routes/leads';
import agentRoutes from './routes/agents';
import campaignRoutes from './routes/campaigns';
import subscriptionRoutes from './routes/subscriptions';
import adminRoutes from './routes/admin';
import analyticsRoutes from './routes/analytics';
import webhookRoutes from './routes/webhooks';
import integrationRoutes from './routes/integrations';
import landingRoutes from './routes/landing';

const API_PREFIX = config.API_PREFIX;

async function buildServer() {
  const fastify = Fastify({
    logger: config.isDevelopment,
    trustProxy: true,
  });

  // Register plugins
  await fastify.register(cors, {
    origin: config.FRONTEND_URL,
    credentials: true,
    methods: ['GET', 'POST', 'PUT', 'PATCH', 'DELETE', 'OPTIONS'],
    allowedHeaders: ['Content-Type', 'Authorization', 'X-Requested-With'],
  });

  await fastify.register(helmet, {
    contentSecurityPolicy: {
      directives: {
        defaultSrc: ["'self'"],
        styleSrc: ["'self'", "'unsafe-inline'"],
        scriptSrc: ["'self'"],
        imgSrc: ["'self'", 'data:', 'https:'],
      },
    },
  });

  await fastify.register(rateLimit, {
    max: 100,
    timeWindow: '1 minute',
    redis,
    keyGenerator: (req) => {
      return req.ip || 'anonymous';
    },
    errorResponseBuilder: (req, context) => {
      return {
        success: false,
        error: 'Rate limit exceeded',
        retryAfter: context.after,
      };
    },
  });

  await fastify.register(jwt, {
    secret: config.JWT_SECRET,
    decode: { complete: true },
  });

  await fastify.register(websocket);

  // Error handling
  fastify.setErrorHandler(errorHandler);
  fastify.setNotFoundHandler(notFoundHandler);

  // Health check endpoint
  fastify.get('/health', async (request, reply) => {
    const healthcheck = {
      uptime: process.uptime(),
      message: 'OK',
      timestamp: Date.now(),
      services: {
        database: 'unknown',
        redis: 'unknown',
      },
    };

    try {
      // Check database
      await prisma.$queryRaw`SELECT 1`;
      healthcheck.services.database = 'healthy';
    } catch (error) {
      healthcheck.services.database = 'unhealthy';
      healthcheck.message = 'Database connection failed';
      return reply.status(503).send(healthcheck);
    }

    try {
      // Check Redis
      await redis.ping();
      healthcheck.services.redis = 'healthy';
    } catch (error) {
      healthcheck.services.redis = 'unhealthy';
      healthcheck.message = 'Redis connection failed';
      return reply.status(503).send(healthcheck);
    }

    return reply.send(healthcheck);
  });

  // Register API routes
  await fastify.register(authRoutes, { prefix: `${API_PREFIX}/auth` });
  await fastify.register(workspaceRoutes, { prefix: `${API_PREFIX}/workspaces` });
  await fastify.register(leadRoutes, { prefix: `${API_PREFIX}/leads` });
  await fastify.register(agentRoutes, { prefix: `${API_PREFIX}/agents` });
  await fastify.register(campaignRoutes, { prefix: `${API_PREFIX}/campaigns` });
  await fastify.register(subscriptionRoutes, { prefix: `${API_PREFIX}/subscriptions` });
  await fastify.register(adminRoutes, { prefix: `${API_PREFIX}/admin` });
  await fastify.register(analyticsRoutes, { prefix: `${API_PREFIX}/analytics` });
  await fastify.register(webhookRoutes, { prefix: `${API_PREFIX}/webhooks` });
  await fastify.register(integrationRoutes, { prefix: `${API_PREFIX}/integrations` });
  await fastify.register(landingRoutes, { prefix: '/landing' });

  // WebSocket handler for real-time updates
  fastify.get('/ws', { websocket: true }, (connection, req) => {
    logger.info('WebSocket connection established');

    connection.socket.on('message', (message: any) => {
      try {
        const data = JSON.parse(message.toString());
        
        // Handle different message types
        switch (data.type) {
          case 'subscribe':
            // Subscribe to workspace updates
            connection.socket.send(JSON.stringify({
              type: 'subscribed',
              channel: data.channel,
            }));
            break;

          case 'ping':
            connection.socket.send(JSON.stringify({ type: 'pong' }));
            break;

          default:
            connection.socket.send(JSON.stringify({
              type: 'error',
              message: 'Unknown message type',
            }));
        }
      } catch (error) {
        connection.socket.send(JSON.stringify({
          type: 'error',
          message: 'Invalid message format',
        }));
      }
    });

    connection.socket.on('close', () => {
      logger.info('WebSocket connection closed');
    });

    // Send welcome message
    connection.socket.send(JSON.stringify({
      type: 'connected',
      message: 'Connected to BOB XD real-time updates',
    }));
  });

  // Graceful shutdown
  const closeGracefully = async (signal: string) => {
    logger.info(`Received signal ${signal}, closing server gracefully`);
    
    await fastify.close();
    await prisma.$disconnect();
    await redis.quit();
    
    logger.info('Server closed gracefully');
    process.exit(0);
  };

  process.on('SIGTERM', () => closeGracefully('SIGTERM'));
  process.on('SIGINT', () => closeGracefully('SIGINT'));

  return fastify;
}

async function start() {
  try {
    const server = await buildServer();
    
    await server.listen({
      port: config.PORT,
      host: config.HOST,
    });

    logger.info(`Server listening on ${config.HOST}:${config.PORT}`);
    logger.info(`API prefix: ${API_PREFIX}`);
    logger.info(`Environment: ${config.NODE_ENV}`);
  } catch (error) {
    logger.error(error, 'Error starting server');
    process.exit(1);
  }
}

// Start server if not in test mode
if (process.env.NODE_ENV !== 'test') {
  start();
}

export { buildServer };
