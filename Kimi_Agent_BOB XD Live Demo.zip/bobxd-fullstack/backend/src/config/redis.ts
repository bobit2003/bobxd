import Redis from 'ioredis';
import { config } from '.';
import { logger } from '../utils/logger';

export const redis = new Redis(config.REDIS_URL, {
  retryStrategy: (times) => {
    const delay = Math.min(times * 50, 2000);
    return delay;
  },
  maxRetriesPerRequest: 3,
});

redis.on('connect', () => {
  logger.info('Redis connected successfully');
});

redis.on('error', (err) => {
  logger.error({ error: err.message }, 'Redis connection error');
});

// Cache helpers
export const cacheGet = async <T>(key: string): Promise<T | null> => {
  const data = await redis.get(key);
  if (!data) return null;
  return JSON.parse(data) as T;
};

export const cacheSet = async <T>(
  key: string,
  value: T,
  ttlSeconds: number = 3600
): Promise<void> => {
  await redis.setex(key, ttlSeconds, JSON.stringify(value));
};

export const cacheDelete = async (key: string): Promise<void> => {
  await redis.del(key);
};

export const cacheInvalidatePattern = async (pattern: string): Promise<void> => {
  const keys = await redis.keys(pattern);
  if (keys.length > 0) {
    await redis.del(...keys);
  }
};

// Rate limiting helpers
export const rateLimitCheck = async (
  key: string,
  limit: number,
  windowSeconds: number
): Promise<{ allowed: boolean; remaining: number; resetTime: number }> => {
  const now = Math.floor(Date.now() / 1000);
  const windowStart = now - windowSeconds;
  
  const multi = redis.multi();
  multi.zremrangebyscore(key, 0, windowStart);
  multi.zcard(key);
  multi.zadd(key, now, `${now}-${Math.random()}`);
  multi.pexpire(key, windowSeconds * 1000);
  
  const results = await multi.exec();
  const currentCount = (results?.[1]?.[1] as number) || 0;
  
  return {
    allowed: currentCount < limit,
    remaining: Math.max(0, limit - currentCount - 1),
    resetTime: now + windowSeconds,
  };
};

export default redis;
