import CryptoJS from 'crypto-js';
import bcrypt from 'bcryptjs';
import { config } from '../config';

const SALT_ROUNDS = 12;
const ENCRYPTION_KEY = config.ENCRYPTION_KEY || config.JWT_SECRET;

export const hashPassword = async (password: string): Promise<string> => {
  return bcrypt.hash(password, SALT_ROUNDS);
};

export const comparePassword = async (password: string, hash: string): Promise<boolean> => {
  return bcrypt.compare(password, hash);
};

export const encrypt = (text: string): string => {
  return CryptoJS.AES.encrypt(text, ENCRYPTION_KEY).toString();
};

export const decrypt = (encryptedText: string): string => {
  const bytes = CryptoJS.AES.decrypt(encryptedText, ENCRYPTION_KEY);
  return bytes.toString(CryptoJS.enc.Utf8);
};

export const generateApiKey = (): string => {
  return `bxd_${CryptoJS.lib.WordArray.random(32).toString()}`;
};

export const hashApiKey = (apiKey: string): string => {
  return CryptoJS.SHA256(apiKey).toString();
};
