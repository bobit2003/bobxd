import OpenAI from 'openai';
import { Queue, Job } from 'bullmq';
import { config } from '../config';
import { prisma } from '../prisma/client';
import { redis } from '../config/redis';
import { logger } from '../utils/logger';
import { OpenClawTask, OpenClawResponse, ExecutionStatus } from '../types';

// Initialize OpenAI client (using OpenAI as the AI provider)
const openai = new OpenAI({
  apiKey: config.OPENAI_API_KEY || config.OPENCLAW_API_KEY,
});

// BullMQ queue for agent tasks
export const agentQueue = new Queue('agent-tasks', {
  connection: redis,
  defaultJobOptions: {
    attempts: 3,
    backoff: {
      type: 'exponential',
      delay: 5000,
    },
    removeOnComplete: 100,
    removeOnFail: 50,
  },
});

export class OpenClawService {
  private logger = logger.child({ service: 'OpenClawService' });

  /**
   * Create a new agent in the system
   */
  async createAgent(agent: {
    id: string;
    name: string;
    type: string;
    systemPrompt?: string;
    model?: string;
    temperature?: number;
    maxTokens?: number;
    configuration?: Record<string, unknown>;
  }): Promise<{ success: boolean; openclawAgentId?: string; error?: string }> {
    try {
      this.logger.info({ agentId: agent.id }, 'Creating agent');

      // Generate a unique OpenClaw agent ID
      const openclawAgentId = `bxd_agent_${agent.id}`;

      // Store agent configuration in cache for quick access
      await redis.setex(
        `agent:config:${agent.id}`,
        86400, // 24 hours
        JSON.stringify({
          openclawAgentId,
          name: agent.name,
          type: agent.type,
          systemPrompt: agent.systemPrompt,
          model: agent.model || 'gpt-4',
          temperature: agent.temperature || 0.7,
          maxTokens: agent.maxTokens || 2000,
          configuration: agent.configuration,
        })
      );

      return {
        success: true,
        openclawAgentId,
      };
    } catch (error) {
      this.logger.error({ error, agentId: agent.id }, 'Failed to create agent');
      return {
        success: false,
        error: error instanceof Error ? error.message : 'Unknown error',
      };
    }
  }

  /**
   * Update an existing agent
   */
  async updateAgent(agent: {
    id: string;
    name?: string;
    systemPrompt?: string;
    model?: string;
    temperature?: number;
    maxTokens?: number;
    configuration?: Record<string, unknown>;
  }): Promise<{ success: boolean; error?: string }> {
    try {
      this.logger.info({ agentId: agent.id }, 'Updating agent');

      // Update agent configuration in cache
      const existingConfig = await redis.get(`agent:config:${agent.id}`);
      if (existingConfig) {
        const config = JSON.parse(existingConfig);
        await redis.setex(
          `agent:config:${agent.id}`,
          86400,
          JSON.stringify({
            ...config,
            ...(agent.name && { name: agent.name }),
            ...(agent.systemPrompt && { systemPrompt: agent.systemPrompt }),
            ...(agent.model && { model: agent.model }),
            ...(agent.temperature !== undefined && { temperature: agent.temperature }),
            ...(agent.maxTokens && { maxTokens: agent.maxTokens }),
            ...(agent.configuration && { configuration: { ...config.configuration, ...agent.configuration } }),
          })
        );
      }

      return { success: true };
    } catch (error) {
      this.logger.error({ error, agentId: agent.id }, 'Failed to update agent');
      return {
        success: false,
        error: error instanceof Error ? error.message : 'Unknown error',
      };
    }
  }

  /**
   * Delete an agent
   */
  async deleteAgent(agentId: string): Promise<{ success: boolean; error?: string }> {
    try {
      this.logger.info({ agentId }, 'Deleting agent');

      // Remove agent configuration from cache
      await redis.del(`agent:config:${agentId}`);

      // Cancel any pending jobs for this agent
      const jobs = await agentQueue.getJobs(['waiting', 'delayed']);
      for (const job of jobs) {
        if (job.data.agentId === agentId) {
          await job.remove();
        }
      }

      return { success: true };
    } catch (error) {
      this.logger.error({ error, agentId }, 'Failed to delete agent');
      return {
        success: false,
        error: error instanceof Error ? error.message : 'Unknown error',
      };
    }
  }

  /**
   * Queue a task for execution
   */
  async queueTask(task: OpenClawTask): Promise<Job> {
    try {
      this.logger.info({ agentId: task.agentId, type: task.type }, 'Queueing task');

      const job = await agentQueue.add(
        task.type,
        {
          agentId: task.agentId,
          input: task.input,
        },
        {
          priority: task.priority || 5,
        }
      );

      return job;
    } catch (error) {
      this.logger.error({ error, task }, 'Failed to queue task');
      throw error;
    }
  }

  /**
   * Execute a task immediately
   */
  async executeTask(
    agentId: string,
    taskType: string,
    input: Record<string, unknown>
  ): Promise<OpenClawResponse> {
    try {
      this.logger.info({ agentId, taskType }, 'Executing task');

      // Get agent configuration
      const agentConfig = await redis.get(`agent:config:${agentId}`);
      if (!agentConfig) {
        // Try to get from database
        const agent = await prisma.agent.findUnique({
          where: { id: agentId },
        });
        if (!agent) {
          return {
            success: false,
            error: 'Agent not found',
          };
        }
      }

      const config = agentConfig ? JSON.parse(agentConfig) : {};

      // Create execution record
      const execution = await prisma.agentExecution.create({
        data: {
          agentId,
          type: taskType,
          input,
          status: 'RUNNING',
          startedAt: new Date(),
        },
      });

      // Execute based on task type
      let result: Record<string, unknown>;
      let tokensUsed = 0;
      let cost = 0;

      switch (taskType) {
        case 'qualify_lead':
          ({ result, tokensUsed, cost } = await this.qualifyLead(config, input, execution.id));
          break;
        case 'send_email':
          ({ result, tokensUsed, cost } = await this.generateEmail(config, input, execution.id));
          break;
        case 'schedule_appointment':
          ({ result, tokensUsed, cost } = await this.scheduleAppointment(config, input, execution.id));
          break;
        case 'enrich_data':
          ({ result, tokensUsed, cost } = await this.enrichData(config, input, execution.id));
          break;
        case 'follow_up':
          ({ result, tokensUsed, cost } = await this.generateFollowUp(config, input, execution.id));
          break;
        default:
          ({ result, tokensUsed, cost } = await this.executeCustomTask(config, input, execution.id));
      }

      // Update execution record
      await prisma.agentExecution.update({
        where: { id: execution.id },
        data: {
          status: 'COMPLETED',
          output: result,
          tokensUsed,
          cost,
          completedAt: new Date(),
        },
      });

      // Update agent token usage
      await prisma.agent.update({
        where: { id: agentId },
        data: {
          tokenUsage: { increment: tokensUsed },
          costUsed: { increment: cost },
        },
      });

      return {
        success: true,
        executionId: execution.id,
        result,
      };
    } catch (error) {
      this.logger.error({ error, agentId, taskType }, 'Task execution failed');
      
      // Update execution record with error
      await prisma.agentExecution.updateMany({
        where: {
          agentId,
          status: 'RUNNING',
        },
        data: {
          status: 'FAILED',
          error: error instanceof Error ? error.message : 'Unknown error',
          completedAt: new Date(),
        },
      });

      return {
        success: false,
        error: error instanceof Error ? error.message : 'Unknown error',
      };
    }
  }

  /**
   * Monitor execution status
   */
  async monitorExecution(executionId: string): Promise<{
    status: ExecutionStatus;
    progress?: number;
    result?: Record<string, unknown>;
    error?: string;
  }> {
    try {
      const execution = await prisma.agentExecution.findUnique({
        where: { id: executionId },
      });

      if (!execution) {
        return {
          status: 'FAILED',
          error: 'Execution not found',
        };
      }

      return {
        status: execution.status as ExecutionStatus,
        progress: execution.progress,
        result: execution.output as Record<string, unknown> | undefined,
        error: execution.error || undefined,
      };
    } catch (error) {
      this.logger.error({ error, executionId }, 'Failed to monitor execution');
      return {
        status: 'FAILED',
        error: error instanceof Error ? error.message : 'Unknown error',
      };
    }
  }

  /**
   * Retry a failed execution
   */
  async retryOnFailure(executionId: string): Promise<{
    success: boolean;
    newExecutionId?: string;
    error?: string;
  }> {
    try {
      const execution = await prisma.agentExecution.findUnique({
        where: { id: executionId },
      });

      if (!execution) {
        return {
          success: false,
          error: 'Execution not found',
        };
      }

      if (execution.status !== 'FAILED') {
        return {
          success: false,
          error: 'Only failed executions can be retried',
        };
      }

      // Create new execution
      const newExecution = await prisma.agentExecution.create({
        data: {
          agentId: execution.agentId,
          type: execution.type,
          input: execution.input,
          status: 'PENDING',
        },
      });

      // Queue the task
      await this.queueTask({
        agentId: execution.agentId,
        type: execution.type,
        input: execution.input as Record<string, unknown>,
        priority: 1, // High priority for retries
      });

      return {
        success: true,
        newExecutionId: newExecution.id,
      };
    } catch (error) {
      this.logger.error({ error, executionId }, 'Failed to retry execution');
      return {
        success: false,
        error: error instanceof Error ? error.message : 'Unknown error',
      };
    }
  }

  /**
   * Check agent quota
   */
  async checkAgentQuota(agentId: string): Promise<{ canExecute: boolean; reason?: string }> {
    try {
      const agent = await prisma.agent.findUnique({
        where: { id: agentId },
      });

      if (!agent) {
        return {
          canExecute: false,
          reason: 'Agent not found',
        };
      }

      if (agent.tokenUsage >= agent.tokenLimit) {
        return {
          canExecute: false,
          reason: 'Token limit exceeded',
        };
      }

      if (agent.costLimit && agent.costUsed >= agent.costLimit) {
        return {
          canExecute: false,
          reason: 'Cost limit exceeded',
        };
      }

      return { canExecute: true };
    } catch (error) {
      this.logger.error({ error, agentId }, 'Failed to check agent quota');
      return {
        canExecute: false,
        reason: error instanceof Error ? error.message : 'Unknown error',
      };
    }
  }

  // Private methods for specific task types

  private async qualifyLead(
    config: Record<string, unknown>,
    input: Record<string, unknown>,
    executionId: string
  ): Promise<{ result: Record<string, unknown>; tokensUsed: number; cost: number }> {
    const systemPrompt = (config.systemPrompt as string) || `You are a lead qualification expert. Analyze the lead data and provide:
1. A qualification score (0-100)
2. The lead's likely budget range
3. Their timeline to purchase
4. Key pain points they might have
5. Recommended next actions

Respond in JSON format.`;

    const userPrompt = `Lead Data:
${JSON.stringify(input, null, 2)}

Please analyze this lead and provide qualification insights.`;

    const response = await openai.chat.completions.create({
      model: (config.model as string) || 'gpt-4',
      messages: [
        { role: 'system', content: systemPrompt },
        { role: 'user', content: userPrompt },
      ],
      temperature: (config.temperature as number) || 0.7,
      max_tokens: (config.maxTokens as number) || 2000,
      response_format: { type: 'json_object' },
    });

    const content = response.choices[0].message.content || '{}';
    const result = JSON.parse(content);
    const tokensUsed = response.usage?.total_tokens || 0;
    const cost = this.calculateCost(config.model as string, tokensUsed);

    return { result, tokensUsed, cost };
  }

  private async generateEmail(
    config: Record<string, unknown>,
    input: Record<string, unknown>,
    executionId: string
  ): Promise<{ result: Record<string, unknown>; tokensUsed: number; cost: number }> {
    const systemPrompt = (config.systemPrompt as string) || `You are an expert email copywriter for B2B sales. Write personalized, engaging emails that:
- Have compelling subject lines
- Are concise and professional
- Include a clear call-to-action
- Match the tone appropriate for the recipient

Respond in JSON format with subject and body fields.`;

    const userPrompt = `Email Context:
${JSON.stringify(input, null, 2)}

Please write a personalized email.`;

    const response = await openai.chat.completions.create({
      model: (config.model as string) || 'gpt-4',
      messages: [
        { role: 'system', content: systemPrompt },
        { role: 'user', content: userPrompt },
      ],
      temperature: (config.temperature as number) || 0.7,
      max_tokens: (config.maxTokens as number) || 2000,
      response_format: { type: 'json_object' },
    });

    const content = response.choices[0].message.content || '{}';
    const result = JSON.parse(content);
    const tokensUsed = response.usage?.total_tokens || 0;
    const cost = this.calculateCost(config.model as string, tokensUsed);

    return { result, tokensUsed, cost };
  }

  private async scheduleAppointment(
    config: Record<string, unknown>,
    input: Record<string, unknown>,
    executionId: string
  ): Promise<{ result: Record<string, unknown>; tokensUsed: number; cost: number }> {
    const systemPrompt = (config.systemPrompt as string) || `You are an appointment scheduling assistant. Analyze the conversation and:
1. Determine if the lead is ready to schedule
2. Suggest optimal meeting times based on context
3. Draft a scheduling request message
4. Handle objections professionally

Respond in JSON format.`;

    const userPrompt = `Scheduling Context:
${JSON.stringify(input, null, 2)}`;

    const response = await openai.chat.completions.create({
      model: (config.model as string) || 'gpt-4',
      messages: [
        { role: 'system', content: systemPrompt },
        { role: 'user', content: userPrompt },
      ],
      temperature: (config.temperature as number) || 0.7,
      max_tokens: (config.maxTokens as number) || 2000,
      response_format: { type: 'json_object' },
    });

    const content = response.choices[0].message.content || '{}';
    const result = JSON.parse(content);
    const tokensUsed = response.usage?.total_tokens || 0;
    const cost = this.calculateCost(config.model as string, tokensUsed);

    return { result, tokensUsed, cost };
  }

  private async enrichData(
    config: Record<string, unknown>,
    input: Record<string, unknown>,
    executionId: string
  ): Promise<{ result: Record<string, unknown>; tokensUsed: number; cost: number }> {
    const systemPrompt = (config.systemPrompt as string) || `You are a data enrichment specialist. Given limited lead information, infer and suggest:
1. Company size and industry
2. Likely job responsibilities
3. Decision-making authority
4. Potential technologies used
5. Relevant talking points

Respond in JSON format.`;

    const userPrompt = `Lead Data to Enrich:
${JSON.stringify(input, null, 2)}`;

    const response = await openai.chat.completions.create({
      model: (config.model as string) || 'gpt-4',
      messages: [
        { role: 'system', content: systemPrompt },
        { role: 'user', content: userPrompt },
      ],
      temperature: (config.temperature as number) || 0.7,
      max_tokens: (config.maxTokens as number) || 2000,
      response_format: { type: 'json_object' },
    });

    const content = response.choices[0].message.content || '{}';
    const result = JSON.parse(content);
    const tokensUsed = response.usage?.total_tokens || 0;
    const cost = this.calculateCost(config.model as string, tokensUsed);

    return { result, tokensUsed, cost };
  }

  private async generateFollowUp(
    config: Record<string, unknown>,
    input: Record<string, unknown>,
    executionId: string
  ): Promise<{ result: Record<string, unknown>; tokensUsed: number; cost: number }> {
    const systemPrompt = (config.systemPrompt as string) || `You are a follow-up specialist. Based on previous interactions, create:
1. Context-aware follow-up message
2. Appropriate timing suggestion
3. Alternative contact methods if needed
4. Value-add content to include

Respond in JSON format.`;

    const userPrompt = `Follow-up Context:
${JSON.stringify(input, null, 2)}`;

    const response = await openai.chat.completions.create({
      model: (config.model as string) || 'gpt-4',
      messages: [
        { role: 'system', content: systemPrompt },
        { role: 'user', content: userPrompt },
      ],
      temperature: (config.temperature as number) || 0.7,
      max_tokens: (config.maxTokens as number) || 2000,
      response_format: { type: 'json_object' },
    });

    const content = response.choices[0].message.content || '{}';
    const result = JSON.parse(content);
    const tokensUsed = response.usage?.total_tokens || 0;
    const cost = this.calculateCost(config.model as string, tokensUsed);

    return { result, tokensUsed, cost };
  }

  private async executeCustomTask(
    config: Record<string, unknown>,
    input: Record<string, unknown>,
    executionId: string
  ): Promise<{ result: Record<string, unknown>; tokensUsed: number; cost: number }> {
    const systemPrompt = (config.systemPrompt as string) || 'You are a helpful AI assistant.';

    const userPrompt = `Task Input:
${JSON.stringify(input, null, 2)}`;

    const response = await openai.chat.completions.create({
      model: (config.model as string) || 'gpt-4',
      messages: [
        { role: 'system', content: systemPrompt },
        { role: 'user', content: userPrompt },
      ],
      temperature: (config.temperature as number) || 0.7,
      max_tokens: (config.maxTokens as number) || 2000,
      response_format: { type: 'json_object' },
    });

    const content = response.choices[0].message.content || '{}';
    const result = JSON.parse(content);
    const tokensUsed = response.usage?.total_tokens || 0;
    const cost = this.calculateCost(config.model as string, tokensUsed);

    return { result, tokensUsed, cost };
  }

  private calculateCost(model: string, tokens: number): number {
    // Approximate costs per 1K tokens (input + output)
    const costs: Record<string, number> = {
      'gpt-4': 0.03,
      'gpt-4-turbo': 0.01,
      'gpt-3.5-turbo': 0.0015,
    };

    const costPer1K = costs[model] || costs['gpt-4'];
    return (tokens / 1000) * costPer1K;
  }
}

export const openClawService = new OpenClawService();
