import { FastifyError, FastifyRequest, FastifyReply } from 'fastify';
import { ZodError } from 'zod';
import { Prisma } from '@prisma/client';
import { logger } from '../utils/logger';

interface CustomError extends FastifyError {
  statusCode?: number;
  code?: string;
}

export const errorHandler = (
  error: CustomError,
  request: FastifyRequest,
  reply: FastifyReply
): void => {
  // Log error
  logger.error({
    error: error.message,
    stack: error.stack,
    code: error.code,
    url: request.url,
    method: request.method,
  }, 'Error occurred');

  // Handle Zod validation errors
  if (error instanceof ZodError) {
    const formattedErrors = error.errors.map((err) => ({
      field: err.path.join('.'),
      message: err.message,
    }));

    reply.status(400).send({
      success: false,
      error: 'Validation Error',
      details: formattedErrors,
    });
    return;
  }

  // Handle Prisma errors
  if (error instanceof Prisma.PrismaClientKnownRequestError) {
    switch (error.code) {
      case 'P2002':
        reply.status(409).send({
          success: false,
          error: 'Duplicate entry - Resource already exists',
        });
        return;
      case 'P2025':
        reply.status(404).send({
          success: false,
          error: 'Resource not found',
        });
        return;
      case 'P2003':
        reply.status(400).send({
          success: false,
          error: 'Foreign key constraint failed',
        });
        return;
      default:
        reply.status(500).send({
          success: false,
          error: 'Database error',
        });
        return;
    }
  }

  if (error instanceof Prisma.PrismaClientValidationError) {
    reply.status(400).send({
      success: false,
      error: 'Invalid data provided',
    });
    return;
  }

  // Handle JWT errors
  if (error.message?.includes('jwt') || error.message?.includes('token')) {
    reply.status(401).send({
      success: false,
      error: 'Authentication error - ' + error.message,
    });
    return;
  }

  // Handle rate limit errors
  if (error.code === 'RATE_LIMIT_EXCEEDED') {
    reply.status(429).send({
      success: false,
      error: 'Rate limit exceeded - Please try again later',
    });
    return;
  }

  // Default error response
  const statusCode = error.statusCode || 500;
  const message = error.statusCode ? error.message : 'Internal server error';

  reply.status(statusCode).send({
    success: false,
    error: message,
    ...(process.env.NODE_ENV === 'development' && { stack: error.stack }),
  });
};

// Not found handler
export const notFoundHandler = (
  request: FastifyRequest,
  reply: FastifyReply
): void => {
  reply.status(404).send({
    success: false,
    error: `Route ${request.method} ${request.url} not found`,
  });
};
