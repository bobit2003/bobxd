import { FastifyRequest, FastifyReply, HookHandlerDoneFunction } from 'fastify';
import jwt from 'jsonwebtoken';
import { config } from '../config';
import { prisma } from '../prisma/client';
import { JWTPayload, RequestContext } from '../types';
import { logger } from '../utils/logger';

// Extend FastifyRequest to include user context
declare module 'fastify' {
  interface FastifyRequest {
    user?: RequestContext;
  }
}

export const authenticate = async (
  request: FastifyRequest,
  reply: FastifyReply
): Promise<void> => {
  try {
    const authHeader = request.headers.authorization;
    
    if (!authHeader?.startsWith('Bearer ')) {
      return reply.status(401).send({
        success: false,
        error: 'Unauthorized - No token provided',
      });
    }

    const token = authHeader.substring(7);
    
    // Check if token is blacklisted
    const isBlacklisted = await prisma.session.findFirst({
      where: {
        refreshToken: token,
      },
    });

    if (!isBlacklisted) {
      // Verify JWT
      const decoded = jwt.verify(token, config.JWT_SECRET) as JWTPayload;
      
      // Get user from database
      const user = await prisma.user.findUnique({
        where: { id: decoded.userId },
        select: {
          id: true,
          email: true,
          role: true,
          status: true,
        },
      });

      if (!user || user.status !== 'ACTIVE') {
        return reply.status(401).send({
          success: false,
          error: 'Unauthorized - User not found or inactive',
        });
      }

      request.user = {
        userId: user.id,
        email: user.email,
        role: user.role,
      };
    } else {
      // API Key authentication
      const apiKey = authHeader.startsWith('Bearer ') ? null : authHeader;
      
      if (apiKey) {
        const hashedKey = require('../utils/encryption').hashApiKey(apiKey);
        const keyRecord = await prisma.apiKey.findFirst({
          where: {
            key: hashedKey,
            isActive: true,
            OR: [
              { expiresAt: null },
              { expiresAt: { gt: new Date() } },
            ],
          },
          include: {
            user: {
              select: {
                id: true,
                email: true,
                role: true,
                status: true,
              },
            },
          },
        });

        if (!keyRecord || keyRecord.user.status !== 'ACTIVE') {
          return reply.status(401).send({
            success: false,
            error: 'Unauthorized - Invalid API key',
          });
        }

        // Update last used
        await prisma.apiKey.update({
          where: { id: keyRecord.id },
          data: { lastUsedAt: new Date() },
        });

        request.user = {
          userId: keyRecord.user.id,
          email: keyRecord.user.email,
          role: keyRecord.user.role,
        };
      } else {
        return reply.status(401).send({
          success: false,
          error: 'Unauthorized - Invalid token',
        });
      }
    }
  } catch (error) {
    logger.error({ error }, 'Authentication error');
    return reply.status(401).send({
      success: false,
      error: 'Unauthorized - Invalid token',
    });
  }
};

export const requireRole = (...roles: string[]) => {
  return async (
    request: FastifyRequest,
    reply: FastifyReply
  ): Promise<void> => {
    if (!request.user) {
      return reply.status(401).send({
        success: false,
        error: 'Unauthorized',
      });
    }

    if (!roles.includes(request.user.role)) {
      return reply.status(403).send({
        success: false,
        error: 'Forbidden - Insufficient permissions',
      });
    }
  };
};

export const requireWorkspaceAccess = async (
  request: FastifyRequest,
  reply: FastifyReply
): Promise<void> => {
  try {
    const workspaceId = request.params?.workspaceId || request.body?.workspaceId;
    
    if (!workspaceId) {
      return reply.status(400).send({
        success: false,
        error: 'Bad Request - Workspace ID required',
      });
    }

    if (!request.user) {
      return reply.status(401).send({
        success: false,
        error: 'Unauthorized',
      });
    }

    // Check if user is super admin
    if (request.user.role === 'SUPER_ADMIN') {
      request.user.workspaceId = workspaceId;
      request.user.workspaceRole = 'OWNER';
      return;
    }

    // Check workspace membership
    const membership = await prisma.workspaceMember.findFirst({
      where: {
        workspaceId,
        userId: request.user.userId,
      },
    });

    if (!membership) {
      // Check if user is workspace owner
      const workspace = await prisma.workspace.findFirst({
        where: {
          id: workspaceId,
          ownerId: request.user.userId,
        },
      });

      if (!workspace) {
        return reply.status(403).send({
          success: false,
          error: 'Forbidden - No access to this workspace',
        });
      }

      request.user.workspaceId = workspaceId;
      request.user.workspaceRole = 'OWNER';
    } else {
      request.user.workspaceId = workspaceId;
      request.user.workspaceRole = membership.role;
    }
  } catch (error) {
    logger.error({ error }, 'Workspace access check error');
    return reply.status(500).send({
      success: false,
      error: 'Internal server error',
    });
  }
};

export const requireWorkspaceRole = (...roles: string[]) => {
  return async (
    request: FastifyRequest,
    reply: FastifyReply
  ): Promise<void> => {
    if (!request.user?.workspaceRole) {
      return reply.status(403).send({
        success: false,
        error: 'Forbidden - Workspace access required',
      });
    }

    if (!roles.includes(request.user.workspaceRole)) {
      return reply.status(403).send({
        success: false,
        error: 'Forbidden - Insufficient workspace permissions',
      });
    }
  };
};
