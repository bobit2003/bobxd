import { FastifyInstance, FastifyPluginOptions } from 'fastify';
import { z } from 'zod';
import { prisma } from '../prisma/client';
import { authenticate } from '../middleware/auth';
import { logger } from '../utils/logger';

const createIntegrationSchema = z.object({
  type: z.enum(['SALESFORCE', 'HUBSPOT', 'ZAPIER', 'SLACK', 'MAKE', 'CUSTOM']),
  name: z.string().min(1),
  configuration: z.record(z.any()),
});

const updateIntegrationSchema = z.object({
  name: z.string().optional(),
  configuration: z.record(z.any()).optional(),
  isActive: z.boolean().optional(),
});

const syncLeadsSchema = z.object({
  leadIds: z.array(z.string()).optional(),
  filters: z.record(z.any()).optional(),
});

// Integration configurations
const INTEGRATION_CONFIGS = {
  SALESFORCE: {
    name: 'Salesforce',
    description: 'Sync leads and contacts with Salesforce CRM',
    icon: 'salesforce',
    authType: 'oauth2',
    requiredFields: ['clientId', 'clientSecret', 'instanceUrl'],
    features: ['sync_leads', 'sync_contacts', 'create_opportunities'],
  },
  HUBSPOT: {
    name: 'HubSpot',
    description: 'Integrate with HubSpot CRM and Marketing',
    icon: 'hubspot',
    authType: 'api_key',
    requiredFields: ['apiKey'],
    features: ['sync_leads', 'create_deals', 'enroll_workflows'],
  },
  ZAPIER: {
    name: 'Zapier',
    description: 'Connect with 5000+ apps via Zapier',
    icon: 'zapier',
    authType: 'webhook',
    requiredFields: ['webhookUrl'],
    features: ['trigger_zaps', 'receive_data'],
  },
  SLACK: {
    name: 'Slack',
    description: 'Get notifications and updates in Slack',
    icon: 'slack',
    authType: 'oauth2',
    requiredFields: ['botToken', 'channelId'],
    features: ['notifications', 'commands', 'alerts'],
  },
  MAKE: {
    name: 'Make (Integromat)',
    description: 'Automate workflows with Make',
    icon: 'make',
    authType: 'api_key',
    requiredFields: ['apiKey', 'webhookUrl'],
    features: ['trigger_scenarios', 'sync_data'],
  },
  CUSTOM: {
    name: 'Custom Integration',
    description: 'Build your own custom integration',
    icon: 'custom',
    authType: 'custom',
    requiredFields: ['endpoint', 'headers'],
    features: ['custom_webhooks', 'api_access'],
  },
};

export default async function integrationRoutes(
  fastify: FastifyInstance,
  options: FastifyPluginOptions
): Promise<void> {
  // Apply authentication to all routes
  fastify.addHook('preHandler', authenticate);

  // Get available integration types
  fastify.get('/types', async (request, reply) => {
    return reply.send({
      success: true,
      data: INTEGRATION_CONFIGS,
    });
  });

  // Get integrations for workspace
  fastify.get('/workspace/:workspaceId', async (request, reply) => {
    const { workspaceId } = request.params as { workspaceId: string };
    const userId = request.user!.userId;

    // Check workspace access
    const hasAccess = await prisma.workspace.findFirst({
      where: {
        id: workspaceId,
        OR: [
          { ownerId: userId },
          { members: { some: { userId } } },
        ],
      },
    });

    if (!hasAccess) {
      return reply.status(403).send({
        success: false,
        error: 'Access denied to this workspace',
      });
    }

    const integrations = await prisma.integration.findMany({
      where: { workspaceId },
      orderBy: { createdAt: 'desc' },
    });

    // Add config info to each integration
    const enrichedIntegrations = integrations.map((integration) => ({
      ...integration,
      configInfo: INTEGRATION_CONFIGS[integration.type],
    }));

    return reply.send({
      success: true,
      data: enrichedIntegrations,
    });
  });

  // Get integration by ID
  fastify.get('/:integrationId', async (request, reply) => {
    const { integrationId } = request.params as { integrationId: string };
    const userId = request.user!.userId;

    const integration = await prisma.integration.findFirst({
      where: {
        id: integrationId,
        workspace: {
          OR: [
            { ownerId: userId },
            { members: { some: { userId } } },
          ],
        },
      },
    });

    if (!integration) {
      return reply.status(404).send({
        success: false,
        error: 'Integration not found',
      });
    }

    return reply.send({
      success: true,
      data: {
        ...integration,
        configInfo: INTEGRATION_CONFIGS[integration.type],
      },
    });
  });

  // Create integration
  fastify.post('/workspace/:workspaceId', async (request, reply) => {
    const { workspaceId } = request.params as { workspaceId: string };
    const data = createIntegrationSchema.parse(request.body);
    const userId = request.user!.userId;

    // Check workspace access
    const hasAccess = await prisma.workspace.findFirst({
      where: {
        id: workspaceId,
        OR: [
          { ownerId: userId },
          { members: { some: { userId, role: { in: ['ADMIN', 'OWNER'] } } } },
          ],
      },
    });

    if (!hasAccess) {
      return reply.status(403).send({
        success: false,
        error: 'Access denied to this workspace',
      });
    }

    // Check if integration already exists
    const existing = await prisma.integration.findFirst({
      where: {
        workspaceId,
        type: data.type,
      },
    });

    if (existing) {
      return reply.status(409).send({
        success: false,
        error: `Integration of type ${data.type} already exists for this workspace`,
      });
    }

    // Validate required fields
    const config = INTEGRATION_CONFIGS[data.type];
    const missingFields = config.requiredFields.filter(
      (field) => !data.configuration[field]
    );

    if (missingFields.length > 0) {
      return reply.status(400).send({
        success: false,
        error: `Missing required fields: ${missingFields.join(', ')}`,
      });
    }

    const integration = await prisma.integration.create({
      data: {
        ...data,
        workspaceId,
      },
    });

    logger.info({ integrationId: integration.id, workspaceId }, 'Integration created');

    return reply.status(201).send({
      success: true,
      data: integration,
    });
  });

  // Update integration
  fastify.patch('/:integrationId', async (request, reply) => {
    const { integrationId } = request.params as { integrationId: string };
    const data = updateIntegrationSchema.parse(request.body);
    const userId = request.user!.userId;

    const integration = await prisma.integration.findFirst({
      where: {
        id: integrationId,
        workspace: {
          OR: [
            { ownerId: userId },
            { members: { some: { userId, role: { in: ['ADMIN', 'OWNER'] } } } },
          ],
        },
      },
    });

    if (!integration) {
      return reply.status(404).send({
        success: false,
        error: 'Integration not found',
      });
    }

    const updated = await prisma.integration.update({
      where: { id: integrationId },
      data: {
        ...data,
        updatedAt: new Date(),
      },
    });

    return reply.send({
      success: true,
      data: updated,
    });
  });

  // Delete integration
  fastify.delete('/:integrationId', async (request, reply) => {
    const { integrationId } = request.params as { integrationId: string };
    const userId = request.user!.userId;

    const integration = await prisma.integration.findFirst({
      where: {
        id: integrationId,
        workspace: {
          OR: [
            { ownerId: userId },
            { members: { some: { userId, role: { in: ['ADMIN', 'OWNER'] } } } },
          ],
        },
      },
    });

    if (!integration) {
      return reply.status(404).send({
        success: false,
        error: 'Integration not found',
      });
    }

    await prisma.integration.delete({
      where: { id: integrationId },
    });

    logger.info({ integrationId }, 'Integration deleted');

    return reply.send({
      success: true,
      message: 'Integration deleted successfully',
    });
  });

  // Test integration
  fastify.post('/:integrationId/test', async (request, reply) => {
    const { integrationId } = request.params as { integrationId: string };
    const userId = request.user!.userId;

    const integration = await prisma.integration.findFirst({
      where: {
        id: integrationId,
        workspace: {
          OR: [
            { ownerId: userId },
            { members: { some: { userId, role: { in: ['ADMIN', 'OWNER'] } } } },
          ],
        },
      },
    });

    if (!integration) {
      return reply.status(404).send({
        success: false,
        error: 'Integration not found',
      });
    }

    // Test the integration based on type
    const testResult = await testIntegration(integration);

    return reply.send({
      success: testResult.success,
      data: testResult,
    });
  });

  // Sync leads with integration
  fastify.post('/:integrationId/sync-leads', async (request, reply) => {
    const { integrationId } = request.params as { integrationId: string };
    const data = syncLeadsSchema.parse(request.body);
    const userId = request.user!.userId;

    const integration = await prisma.integration.findFirst({
      where: {
        id: integrationId,
        workspace: {
          OR: [
            { ownerId: userId },
            { members: { some: { userId, role: { in: ['ADMIN', 'OWNER'] } } } },
          ],
        },
      },
    });

    if (!integration) {
      return reply.status(404).send({
        success: false,
        error: 'Integration not found',
      });
    }

    if (!integration.isActive) {
      return reply.status(400).send({
        success: false,
        error: 'Integration is not active',
      });
    }

    // Get leads to sync
    let leads;
    if (data.leadIds) {
      leads = await prisma.lead.findMany({
        where: {
          id: { in: data.leadIds },
          workspaceId: integration.workspaceId,
        },
      });
    } else {
      leads = await prisma.lead.findMany({
        where: {
          workspaceId: integration.workspaceId,
          deletedAt: null,
          ...(data.filters || {}),
        },
        take: 100,
      });
    }

    // Sync leads based on integration type
    const syncResult = await syncLeadsWithIntegration(integration, leads);

    // Update last sync time
    await prisma.integration.update({
      where: { id: integrationId },
      data: { lastSyncAt: new Date() },
    });

    return reply.send({
      success: true,
      data: syncResult,
    });
  });

  // Toggle integration status
  fastify.post('/:integrationId/toggle', async (request, reply) => {
    const { integrationId } = request.params as { integrationId: string };
    const userId = request.user!.userId;

    const integration = await prisma.integration.findFirst({
      where: {
        id: integrationId,
        workspace: {
          OR: [
            { ownerId: userId },
            { members: { some: { userId, role: { in: ['ADMIN', 'OWNER'] } } } },
          ],
        },
      },
    });

    if (!integration) {
      return reply.status(404).send({
        success: false,
        error: 'Integration not found',
      });
    }

    const updated = await prisma.integration.update({
      where: { id: integrationId },
      data: { isActive: !integration.isActive },
    });

    return reply.send({
      success: true,
      data: updated,
    });
  });
}

// Helper functions
async function testIntegration(integration: any): Promise<{ success: boolean; message: string }> {
  try {
    switch (integration.type) {
      case 'SLACK':
        // Test Slack connection
        const slackConfig = integration.configuration;
        const response = await fetch('https://slack.com/api/auth.test', {
          headers: {
            Authorization: `Bearer ${slackConfig.botToken}`,
          },
        });
        const data = await response.json();
        return {
          success: data.ok,
          message: data.ok ? 'Slack connection successful' : data.error,
        };

      case 'ZAPIER':
        // Test Zapier webhook
        const zapierConfig = integration.configuration;
        const zapResponse = await fetch(zapierConfig.webhookUrl, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ test: true }),
        });
        return {
          success: zapResponse.ok,
          message: zapResponse.ok ? 'Zapier webhook test successful' : 'Webhook test failed',
        };

      default:
        return {
          success: true,
          message: 'Integration test not implemented for this type',
        };
    }
  } catch (error) {
    return {
      success: false,
      message: error instanceof Error ? error.message : 'Unknown error',
    };
  }
}

async function syncLeadsWithIntegration(
  integration: any,
  leads: any[]
): Promise<{ synced: number; failed: number; errors: string[] }> {
  const result = {
    synced: 0,
    failed: 0,
    errors: [] as string[],
  };

  for (const lead of leads) {
    try {
      switch (integration.type) {
        case 'SLACK':
          // Send lead notification to Slack
          const slackConfig = integration.configuration;
          await fetch('https://slack.com/api/chat.postMessage', {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json',
              Authorization: `Bearer ${slackConfig.botToken}`,
            },
            body: JSON.stringify({
              channel: slackConfig.channelId,
              text: `New Lead: ${lead.firstName} ${lead.lastName} (${lead.email})`,
              blocks: [
                {
                  type: 'section',
                  text: {
                    type: 'mrkdwn',
                    text: `*New Lead Synced*\n*Name:* ${lead.firstName} ${lead.lastName}\n*Email:* ${lead.email}\n*Company:* ${lead.company || 'N/A'}\n*Status:* ${lead.status}`,
                  },
                },
              ],
            }),
          });
          result.synced++;
          break;

        case 'ZAPIER':
          // Trigger Zapier webhook
          const zapierConfig = integration.configuration;
          await fetch(zapierConfig.webhookUrl, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
              event: 'lead.sync',
              lead: {
                id: lead.id,
                firstName: lead.firstName,
                lastName: lead.lastName,
                email: lead.email,
                company: lead.company,
                status: lead.status,
              },
            }),
          });
          result.synced++;
          break;

        default:
          result.failed++;
          result.errors.push(`Sync not implemented for ${integration.type}`);
      }
    } catch (error) {
      result.failed++;
      result.errors.push(
        `Failed to sync lead ${lead.id}: ${error instanceof Error ? error.message : 'Unknown error'}`
      );
    }
  }

  return result;
}
