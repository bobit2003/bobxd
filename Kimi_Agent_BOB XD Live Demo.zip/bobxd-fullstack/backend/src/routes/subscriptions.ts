import { FastifyInstance, FastifyPluginOptions } from 'fastify';
import { z } from 'zod';
import Stripe from 'stripe';
import { prisma } from '../prisma/client';
import { config } from '../config';
import { authenticate, requireRole } from '../middleware/auth';
import { logger } from '../utils/logger';

// Initialize Stripe
const stripe = config.STRIPE_SECRET_KEY
  ? new Stripe(config.STRIPE_SECRET_KEY, { apiVersion: '2024-06-20' })
  : null;

const createSubscriptionSchema = z.object({
  priceId: z.string(),
  paymentMethodId: z.string().optional(),
});

const updateSubscriptionSchema = z.object({
  priceId: z.string(),
});

const createPaymentIntentSchema = z.object({
  amount: z.number().min(1),
  currency: z.string().default('USD'),
});

// Plan configurations
const PLAN_CONFIGS = {
  FREE: {
    name: 'Free',
    price: 0,
    features: {
      workspaces: 1,
      leads: 100,
      agents: 2,
      campaigns: 3,
      executions: 100,
      support: 'community',
    },
  },
  STARTER: {
    name: 'Starter',
    price: 29,
    features: {
      workspaces: 3,
      leads: 1000,
      agents: 5,
      campaigns: 10,
      executions: 1000,
      support: 'email',
    },
  },
  PROFESSIONAL: {
    name: 'Professional',
    price: 99,
    features: {
      workspaces: 10,
      leads: 10000,
      agents: 20,
      campaigns: 50,
      executions: 10000,
      support: 'priority',
    },
  },
  ENTERPRISE: {
    name: 'Enterprise',
    price: 299,
    features: {
      workspaces: -1, // unlimited
      leads: -1,
      agents: -1,
      campaigns: -1,
      executions: -1,
      support: 'dedicated',
    },
  },
};

export default async function subscriptionRoutes(
  fastify: FastifyInstance,
  options: FastifyPluginOptions
): Promise<void> {
  // Apply authentication to all routes
  fastify.addHook('preHandler', authenticate);

  // Get current subscription
  fastify.get('/', async (request, reply) => {
    const userId = request.user!.userId;

    const subscription = await prisma.subscription.findFirst({
      where: { userId },
      include: {
        invoices: {
          orderBy: { createdAt: 'desc' },
          take: 10,
        },
      },
    });

    if (!subscription) {
      return reply.status(404).send({
        success: false,
        error: 'Subscription not found',
      });
    }

    return reply.send({
      success: true,
      data: {
        subscription,
        planConfig: PLAN_CONFIGS[subscription.plan],
      },
    });
  });

  // Get available plans
  fastify.get('/plans', async (request, reply) => {
    return reply.send({
      success: true,
      data: PLAN_CONFIGS,
    });
  });

  // Create subscription (with Stripe)
  fastify.post('/', async (request, reply) => {
    if (!stripe) {
      return reply.status(503).send({
        success: false,
        error: 'Payment processing is not configured',
      });
    }

    const userId = request.user!.userId;
    const data = createSubscriptionSchema.parse(request.body);

    const user = await prisma.user.findUnique({
      where: { id: userId },
    });

    if (!user) {
      return reply.status(404).send({
        success: false,
        error: 'User not found',
      });
    }

    // Get or create Stripe customer
    let subscription = await prisma.subscription.findFirst({
      where: { userId },
    });

    let customerId = subscription?.stripeCustomerId;

    if (!customerId) {
      const customer = await stripe.customers.create({
        email: user.email,
        name: `${user.firstName} ${user.lastName}`,
        metadata: {
          userId: user.id,
        },
      });
      customerId = customer.id;
    }

    // Attach payment method if provided
    if (data.paymentMethodId) {
      await stripe.paymentMethods.attach(data.paymentMethodId, {
        customer: customerId,
      });

      await stripe.customers.update(customerId, {
        invoice_settings: {
          default_payment_method: data.paymentMethodId,
        },
      });
    }

    // Create subscription
    const stripeSubscription = await stripe.subscriptions.create({
      customer: customerId,
      items: [{ price: data.priceId }],
      payment_behavior: 'default_incomplete',
      expand: ['latest_invoice.payment_intent'],
    });

    // Update or create subscription record
    if (subscription) {
      subscription = await prisma.subscription.update({
        where: { id: subscription.id },
        data: {
          stripeCustomerId: customerId,
          stripeSubscriptionId: stripeSubscription.id,
          status: 'TRIALING',
        },
      });
    } else {
      subscription = await prisma.subscription.create({
        data: {
          userId,
          stripeCustomerId: customerId,
          stripeSubscriptionId: stripeSubscription.id,
          plan: 'STARTER',
          status: 'TRIALING',
        },
      });
    }

    logger.info({ userId, subscriptionId: subscription.id }, 'Subscription created');

    return reply.status(201).send({
      success: true,
      data: {
        subscription,
        clientSecret: (stripeSubscription.latest_invoice as any)?.payment_intent?.client_secret,
      },
    });
  });

  // Update subscription
  fastify.patch('/', async (request, reply) => {
    if (!stripe) {
      return reply.status(503).send({
        success: false,
        error: 'Payment processing is not configured',
      });
    }

    const userId = request.user!.userId;
    const data = updateSubscriptionSchema.parse(request.body);

    const subscription = await prisma.subscription.findFirst({
      where: { userId },
    });

    if (!subscription?.stripeSubscriptionId) {
      return reply.status(404).send({
        success: false,
        error: 'Active subscription not found',
      });
    }

    // Update Stripe subscription
    const stripeSubscription = await stripe.subscriptions.retrieve(
      subscription.stripeSubscriptionId
    );

    await stripe.subscriptions.update(subscription.stripeSubscriptionId, {
      items: [
        {
          id: stripeSubscription.items.data[0].id,
          price: data.priceId,
        },
      ],
    });

    return reply.send({
      success: true,
      message: 'Subscription updated successfully',
    });
  });

  // Cancel subscription
  fastify.delete('/', async (request, reply) => {
    if (!stripe) {
      return reply.status(503).send({
        success: false,
        error: 'Payment processing is not configured',
      });
    }

    const userId = request.user!.userId;

    const subscription = await prisma.subscription.findFirst({
      where: { userId },
    });

    if (!subscription?.stripeSubscriptionId) {
      return reply.status(404).send({
        success: false,
        error: 'Active subscription not found',
      });
    }

    // Cancel at period end
    await stripe.subscriptions.update(subscription.stripeSubscriptionId, {
      cancel_at_period_end: true,
    });

    await prisma.subscription.update({
      where: { id: subscription.id },
      data: {
        cancelAtPeriodEnd: true,
      },
    });

    return reply.send({
      success: true,
      message: 'Subscription will be cancelled at the end of the billing period',
    });
  });

  // Get invoices
  fastify.get('/invoices', async (request, reply) => {
    const userId = request.user!.userId;

    const invoices = await prisma.invoice.findMany({
      where: { userId },
      orderBy: { createdAt: 'desc' },
      include: {
        payments: true,
      },
    });

    return reply.send({
      success: true,
      data: invoices,
    });
  });

  // Get invoice by ID
  fastify.get('/invoices/:invoiceId', async (request, reply) => {
    const { invoiceId } = request.params as { invoiceId: string };
    const userId = request.user!.userId;

    const invoice = await prisma.invoice.findFirst({
      where: {
        id: invoiceId,
        userId,
      },
      include: {
        payments: true,
      },
    });

    if (!invoice) {
      return reply.status(404).send({
        success: false,
        error: 'Invoice not found',
      });
    }

    return reply.send({
      success: true,
      data: invoice,
    });
  });

  // Create payment intent
  fastify.post('/payment-intent', async (request, reply) => {
    if (!stripe) {
      return reply.status(503).send({
        success: false,
        error: 'Payment processing is not configured',
      });
    }

    const userId = request.user!.userId;
    const data = createPaymentIntentSchema.parse(request.body);

    const user = await prisma.user.findUnique({
      where: { id: userId },
    });

    if (!user) {
      return reply.status(404).send({
        success: false,
        error: 'User not found',
      });
    }

    const paymentIntent = await stripe.paymentIntents.create({
      amount: data.amount * 100, // Convert to cents
      currency: data.currency.toLowerCase(),
      metadata: {
        userId: user.id,
      },
    });

    return reply.send({
      success: true,
      data: {
        clientSecret: paymentIntent.client_secret,
      },
    });
  });

  // Get payment methods
  fastify.get('/payment-methods', async (request, reply) => {
    if (!stripe) {
      return reply.status(503).send({
        success: false,
        error: 'Payment processing is not configured',
      });
    }

    const userId = request.user!.userId;

    const subscription = await prisma.subscription.findFirst({
      where: { userId },
    });

    if (!subscription?.stripeCustomerId) {
      return reply.send({
        success: true,
        data: [],
      });
    }

    const paymentMethods = await stripe.paymentMethods.list({
      customer: subscription.stripeCustomerId,
      type: 'card',
    });

    return reply.send({
      success: true,
      data: paymentMethods.data,
    });
  });

  // Stripe webhook handler
  fastify.post('/webhook', async (request, reply) => {
    if (!stripe) {
      return reply.status(503).send({
        success: false,
        error: 'Payment processing is not configured',
      });
    }

    const sig = request.headers['stripe-signature'] as string;
    const payload = request.body as string;

    let event: Stripe.Event;

    try {
      event = stripe.webhooks.constructEvent(
        payload,
        sig,
        config.STRIPE_WEBHOOK_SECRET || ''
      );
    } catch (err: any) {
      logger.error({ error: err.message }, 'Stripe webhook error');
      return reply.status(400).send({
        success: false,
        error: `Webhook Error: ${err.message}`,
      });
    }

    // Handle events
    switch (event.type) {
      case 'invoice.payment_succeeded':
        const invoice = event.data.object as Stripe.Invoice;
        await handleInvoicePaymentSucceeded(invoice);
        break;

      case 'invoice.payment_failed':
        const failedInvoice = event.data.object as Stripe.Invoice;
        await handleInvoicePaymentFailed(failedInvoice);
        break;

      case 'customer.subscription.updated':
        const subscription = event.data.object as Stripe.Subscription;
        await handleSubscriptionUpdated(subscription);
        break;

      case 'customer.subscription.deleted':
        const deletedSubscription = event.data.object as Stripe.Subscription;
        await handleSubscriptionDeleted(deletedSubscription);
        break;

      default:
        logger.info({ eventType: event.type }, 'Unhandled Stripe event');
    }

    return reply.send({ received: true });
  });

  // Get usage stats
  fastify.get('/usage', async (request, reply) => {
    const userId = request.user!.userId;

    const subscription = await prisma.subscription.findFirst({
      where: { userId },
    });

    if (!subscription) {
      return reply.status(404).send({
        success: false,
        error: 'Subscription not found',
      });
    }

    const planConfig = PLAN_CONFIGS[subscription.plan];

    // Get usage stats
    const [
      workspaceCount,
      leadCount,
      agentCount,
      campaignCount,
      executionCount,
    ] = await Promise.all([
      prisma.workspace.count({
        where: { ownerId: userId, deletedAt: null },
      }),
      prisma.lead.count({
        where: {
          workspace: { ownerId: userId },
          deletedAt: null,
        },
      }),
      prisma.agent.count({
        where: {
          workspace: { ownerId: userId },
          deletedAt: null,
        },
      }),
      prisma.campaign.count({
        where: {
          workspace: { ownerId: userId },
          deletedAt: null,
        },
      }),
      prisma.agentExecution.count({
        where: {
          agent: { workspace: { ownerId: userId } },
        },
      }),
    ]);

    return reply.send({
      success: true,
      data: {
        plan: subscription.plan,
        limits: planConfig.features,
        usage: {
          workspaces: workspaceCount,
          leads: leadCount,
          agents: agentCount,
          campaigns: campaignCount,
          executions: executionCount,
        },
        percentages: {
          workspaces: planConfig.features.workspaces > 0
            ? Math.round((workspaceCount / planConfig.features.workspaces) * 100)
            : 0,
          leads: planConfig.features.leads > 0
            ? Math.round((leadCount / planConfig.features.leads) * 100)
            : 0,
          agents: planConfig.features.agents > 0
            ? Math.round((agentCount / planConfig.features.agents) * 100)
            : 0,
          campaigns: planConfig.features.campaigns > 0
            ? Math.round((campaignCount / planConfig.features.campaigns) * 100)
            : 0,
          executions: planConfig.features.executions > 0
            ? Math.round((executionCount / planConfig.features.executions) * 100)
            : 0,
        },
      },
    });
  });
}

// Webhook handlers
async function handleInvoicePaymentSucceeded(invoice: Stripe.Invoice) {
  const subscription = await prisma.subscription.findFirst({
    where: { stripeCustomerId: invoice.customer as string },
  });

  if (subscription) {
    await prisma.invoice.create({
      data: {
        subscriptionId: subscription.id,
        userId: subscription.userId,
        stripeInvoiceId: invoice.id,
        amount: invoice.amount_due / 100,
        currency: invoice.currency.toUpperCase(),
        status: 'PAID',
        paidAt: new Date(),
        pdfUrl: invoice.invoice_pdf,
        lineItems: invoice.lines.data,
      },
    });

    await prisma.subscription.update({
      where: { id: subscription.id },
      data: { status: 'ACTIVE' },
    });
  }
}

async function handleInvoicePaymentFailed(invoice: Stripe.Invoice) {
  const subscription = await prisma.subscription.findFirst({
    where: { stripeCustomerId: invoice.customer as string },
  });

  if (subscription) {
    await prisma.invoice.create({
      data: {
        subscriptionId: subscription.id,
        userId: subscription.userId,
        stripeInvoiceId: invoice.id,
        amount: invoice.amount_due / 100,
        currency: invoice.currency.toUpperCase(),
        status: 'PENDING',
      },
    });

    await prisma.subscription.update({
      where: { id: subscription.id },
      data: { status: 'PAST_DUE' },
    });
  }
}

async function handleSubscriptionUpdated(stripeSub: Stripe.Subscription) {
  const subscription = await prisma.subscription.findFirst({
    where: { stripeSubscriptionId: stripeSub.id },
  });

  if (subscription) {
    const plan = getPlanFromPriceId(stripeSub.items.data[0].price.id);

    await prisma.subscription.update({
      where: { id: subscription.id },
      data: {
        plan,
        status: stripeSub.status === 'active' ? 'ACTIVE' : stripeSub.status.toUpperCase(),
        currentPeriodStart: new Date(stripeSub.current_period_start * 1000),
        currentPeriodEnd: new Date(stripeSub.current_period_end * 1000),
        cancelAtPeriodEnd: stripeSub.cancel_at_period_end,
      },
    });
  }
}

async function handleSubscriptionDeleted(stripeSub: Stripe.Subscription) {
  const subscription = await prisma.subscription.findFirst({
    where: { stripeSubscriptionId: stripeSub.id },
  });

  if (subscription) {
    await prisma.subscription.update({
      where: { id: subscription.id },
      data: {
        status: 'CANCELLED',
        plan: 'FREE',
      },
    });
  }
}

function getPlanFromPriceId(priceId: string): 'FREE' | 'STARTER' | 'PROFESSIONAL' | 'ENTERPRISE' {
  // Map price IDs to plans
  // This should be configured based on your Stripe price IDs
  const priceMap: Record<string, string> = {
    'price_starter': 'STARTER',
    'price_pro': 'PROFESSIONAL',
    'price_enterprise': 'ENTERPRISE',
  };

  return (priceMap[priceId] || 'FREE') as any;
}
