import { FastifyInstance, FastifyPluginOptions } from 'fastify';
import { z } from 'zod';
import { prisma } from '../prisma/client';
import { authenticate } from '../middleware/auth';
import { createCampaignSchema, updateCampaignSchema } from '../types';
import { openClawService, agentQueue } from '../services/openclaw.service';
import { logger } from '../utils/logger';

const querySchema = z.object({
  page: z.string().optional().default('1'),
  limit: z.string().optional().default('20'),
  search: z.string().optional(),
  status: z.string().optional(),
  type: z.string().optional(),
  sortBy: z.string().optional().default('createdAt'),
  sortOrder: z.enum(['asc', 'desc']).optional().default('desc'),
});

const addLeadsSchema = z.object({
  leadIds: z.array(z.string()),
});

const removeLeadsSchema = z.object({
  leadIds: z.array(z.string()),
});

export default async function campaignRoutes(
  fastify: FastifyInstance,
  options: FastifyPluginOptions
): Promise<void> {
  // Apply authentication to all routes
  fastify.addHook('preHandler', authenticate);

  // Get campaigns for workspace
  fastify.get('/workspace/:workspaceId', async (request, reply) => {
    const { workspaceId } = request.params as { workspaceId: string };
    const query = querySchema.parse(request.query);
    const userId = request.user!.userId;

    // Check workspace access
    const hasAccess = await prisma.workspace.findFirst({
      where: {
        id: workspaceId,
        OR: [
          { ownerId: userId },
          { members: { some: { userId } } },
        ],
      },
    });

    if (!hasAccess) {
      return reply.status(403).send({
        success: false,
        error: 'Access denied to this workspace',
      });
    }

    const page = parseInt(query.page, 10);
    const limit = parseInt(query.limit, 10);
    const skip = (page - 1) * limit;

    // Build where clause
    const where: any = {
      workspaceId,
      deletedAt: null,
    };

    if (query.search) {
      where.OR = [
        { name: { contains: query.search, mode: 'insensitive' } },
        { description: { contains: query.search, mode: 'insensitive' } },
      ];
    }

    if (query.status) {
      where.status = query.status;
    }

    if (query.type) {
      where.type = query.type;
    }

    const [campaigns, total] = await Promise.all([
      prisma.campaign.findMany({
        where,
        include: {
          createdBy: {
            select: {
              id: true,
              firstName: true,
              lastName: true,
              email: true,
              avatar: true,
            },
          },
          agents: {
            include: {
              agent: {
                select: {
                  id: true,
                  name: true,
                  type: true,
                  status: true,
                },
              },
            },
          },
          _count: {
            select: {
              leads: true,
            },
          },
        },
        orderBy: { [query.sortBy]: query.sortOrder },
        skip,
        take: limit,
      }),
      prisma.campaign.count({ where }),
    ]);

    return reply.send({
      success: true,
      data: {
        campaigns,
        pagination: {
          page,
          limit,
          total,
          totalPages: Math.ceil(total / limit),
        },
      },
    });
  });

  // Get campaign by ID
  fastify.get('/:campaignId', async (request, reply) => {
    const { campaignId } = request.params as { campaignId: string };
    const userId = request.user!.userId;

    const campaign = await prisma.campaign.findFirst({
      where: {
        id: campaignId,
        deletedAt: null,
        workspace: {
          OR: [
            { ownerId: userId },
            { members: { some: { userId } } },
          ],
        },
      },
      include: {
        createdBy: {
          select: {
            id: true,
            firstName: true,
            lastName: true,
            email: true,
            avatar: true,
          },
        },
        agents: {
          include: {
            agent: {
              select: {
                id: true,
                name: true,
                type: true,
                status: true,
              },
            },
          },
        },
        leads: {
          include: {
            lead: {
              select: {
                id: true,
                firstName: true,
                lastName: true,
                email: true,
                company: true,
                status: true,
              },
            },
          },
          orderBy: { createdAt: 'desc' },
        },
        metrics: {
          orderBy: { date: 'desc' },
          take: 30,
        },
      },
    });

    if (!campaign) {
      return reply.status(404).send({
        success: false,
        error: 'Campaign not found',
      });
    }

    return reply.send({
      success: true,
      data: campaign,
    });
  });

  // Create campaign
  fastify.post('/workspace/:workspaceId', async (request, reply) => {
    const { workspaceId } = request.params as { workspaceId: string };
    const data = createCampaignSchema.parse(request.body);
    const userId = request.user!.userId;

    // Check workspace access
    const hasAccess = await prisma.workspace.findFirst({
      where: {
        id: workspaceId,
        OR: [
          { ownerId: userId },
          { members: { some: { userId } } },
        ],
      },
    });

    if (!hasAccess) {
      return reply.status(403).send({
        success: false,
        error: 'Access denied to this workspace',
      });
    }

    // Create campaign
    const campaign = await prisma.campaign.create({
      data: {
        name: data.name,
        description: data.description,
        type: data.type,
        workspaceId,
        createdById: userId,
        configuration: data.configuration,
        schedule: data.schedule,
        startDate: data.startDate ? new Date(data.startDate) : null,
        endDate: data.endDate ? new Date(data.endDate) : null,
        targetCount: data.targetCount,
      },
      include: {
        createdBy: {
          select: {
            id: true,
            firstName: true,
            lastName: true,
            email: true,
            avatar: true,
          },
        },
      },
    });

    // Add agents if provided
    if (data.agentIds && data.agentIds.length > 0) {
      await prisma.campaignAgent.createMany({
        data: data.agentIds.map((agentId, index) => ({
          campaignId: campaign.id,
          agentId,
          order: index,
        })),
      });
    }

    // Add leads if provided
    if (data.leadIds && data.leadIds.length > 0) {
      await prisma.campaignLead.createMany({
        data: data.leadIds.map((leadId) => ({
          campaignId: campaign.id,
          leadId,
        })),
      });
    }

    logger.info({ campaignId: campaign.id, workspaceId }, 'Campaign created');

    return reply.status(201).send({
      success: true,
      data: campaign,
    });
  });

  // Update campaign
  fastify.patch('/:campaignId', async (request, reply) => {
    const { campaignId } = request.params as { campaignId: string };
    const data = updateCampaignSchema.parse(request.body);
    const userId = request.user!.userId;

    const campaign = await prisma.campaign.findFirst({
      where: {
        id: campaignId,
        deletedAt: null,
        workspace: {
          OR: [
            { ownerId: userId },
            { members: { some: { userId } } },
          ],
        },
      },
    });

    if (!campaign) {
      return reply.status(404).send({
        success: false,
        error: 'Campaign not found',
      });
    }

    // Don't allow updates if campaign is running
    if (campaign.status === 'RUNNING') {
      return reply.status(400).send({
        success: false,
        error: 'Cannot update a running campaign. Pause it first.',
      });
    }

    const updated = await prisma.campaign.update({
      where: { id: campaignId },
      data: {
        ...data,
        startDate: data.startDate ? new Date(data.startDate) : campaign.startDate,
        endDate: data.endDate ? new Date(data.endDate) : campaign.endDate,
        updatedAt: new Date(),
      },
      include: {
        createdBy: {
          select: {
            id: true,
            firstName: true,
            lastName: true,
            email: true,
            avatar: true,
          },
        },
        agents: {
          include: {
            agent: {
              select: {
                id: true,
                name: true,
                type: true,
                status: true,
              },
            },
          },
        },
      },
    });

    return reply.send({
      success: true,
      data: updated,
    });
  });

  // Delete campaign
  fastify.delete('/:campaignId', async (request, reply) => {
    const { campaignId } = request.params as { campaignId: string };
    const userId = request.user!.userId;

    const campaign = await prisma.campaign.findFirst({
      where: {
        id: campaignId,
        deletedAt: null,
        workspace: {
          OR: [
            { ownerId: userId },
            { members: { some: { userId, role: { in: ['ADMIN', 'OWNER'] } } } },
          ],
        },
      },
    });

    if (!campaign) {
      return reply.status(404).send({
        success: false,
        error: 'Campaign not found or access denied',
      });
    }

    // Soft delete
    await prisma.campaign.update({
      where: { id: campaignId },
      data: { deletedAt: new Date() },
    });

    logger.info({ campaignId }, 'Campaign deleted');

    return reply.send({
      success: true,
      message: 'Campaign deleted successfully',
    });
  });

  // Start campaign
  fastify.post('/:campaignId/start', async (request, reply) => {
    const { campaignId } = request.params as { campaignId: string };
    const userId = request.user!.userId;

    const campaign = await prisma.campaign.findFirst({
      where: {
        id: campaignId,
        deletedAt: null,
        workspace: {
          OR: [
            { ownerId: userId },
            { members: { some: { userId } } },
          ],
        },
      },
      include: {
        agents: {
          include: {
            agent: true,
          },
        },
        leads: {
          where: { status: 'PENDING' },
        },
      },
    });

    if (!campaign) {
      return reply.status(404).send({
        success: false,
        error: 'Campaign not found',
      });
    }

    if (campaign.status === 'RUNNING') {
      return reply.status(400).send({
        success: false,
        error: 'Campaign is already running',
      });
    }

    if (campaign.agents.length === 0) {
      return reply.status(400).send({
        success: false,
        error: 'Campaign must have at least one agent',
      });
    }

    if (campaign.leads.length === 0) {
      return reply.status(400).send({
        success: false,
        error: 'Campaign must have at least one lead',
      });
    }

    // Update status
    await prisma.campaign.update({
      where: { id: campaignId },
      data: { status: 'RUNNING' },
    });

    // Queue tasks for each lead
    for (const campaignLead of campaign.leads) {
      for (const campaignAgent of campaign.agents) {
        await openClawService.queueTask({
          agentId: campaignAgent.agentId,
          type: campaign.type.toLowerCase(),
          input: {
            leadId: campaignLead.leadId,
            campaignId,
          },
          priority: 5,
        });
      }
    }

    logger.info({ campaignId }, 'Campaign started');

    return reply.send({
      success: true,
      message: 'Campaign started successfully',
    });
  });

  // Pause campaign
  fastify.post('/:campaignId/pause', async (request, reply) => {
    const { campaignId } = request.params as { campaignId: string };
    const userId = request.user!.userId;

    const campaign = await prisma.campaign.findFirst({
      where: {
        id: campaignId,
        deletedAt: null,
        workspace: {
          OR: [
            { ownerId: userId },
            { members: { some: { userId } } },
          ],
        },
      },
    });

    if (!campaign) {
      return reply.status(404).send({
        success: false,
        error: 'Campaign not found',
      });
    }

    if (campaign.status !== 'RUNNING') {
      return reply.status(400).send({
        success: false,
        error: 'Campaign is not running',
      });
    }

    await prisma.campaign.update({
      where: { id: campaignId },
      data: { status: 'PAUSED' },
    });

    return reply.send({
      success: true,
      message: 'Campaign paused successfully',
    });
  });

  // Add leads to campaign
  fastify.post('/:campaignId/leads', async (request, reply) => {
    const { campaignId } = request.params as { campaignId: string };
    const { leadIds } = addLeadsSchema.parse(request.body);
    const userId = request.user!.userId;

    const campaign = await prisma.campaign.findFirst({
      where: {
        id: campaignId,
        deletedAt: null,
        workspace: {
          OR: [
            { ownerId: userId },
            { members: { some: { userId } } },
          ],
        },
      },
    });

    if (!campaign) {
      return reply.status(404).send({
        success: false,
        error: 'Campaign not found',
      });
    }

    // Filter out already added leads
    const existing = await prisma.campaignLead.findMany({
      where: {
        campaignId,
        leadId: { in: leadIds },
      },
    });

    const existingIds = existing.map((e) => e.leadId);
    const newIds = leadIds.filter((id) => !existingIds.includes(id));

    if (newIds.length > 0) {
      await prisma.campaignLead.createMany({
        data: newIds.map((leadId) => ({
          campaignId,
          leadId,
        })),
      });
    }

    return reply.send({
      success: true,
      data: {
        added: newIds.length,
        skipped: existingIds.length,
      },
    });
  });

  // Remove leads from campaign
  fastify.delete('/:campaignId/leads', async (request, reply) => {
    const { campaignId } = request.params as { campaignId: string };
    const { leadIds } = removeLeadsSchema.parse(request.body);
    const userId = request.user!.userId;

    const campaign = await prisma.campaign.findFirst({
      where: {
        id: campaignId,
        deletedAt: null,
        workspace: {
          OR: [
            { ownerId: userId },
            { members: { some: { userId } } },
          ],
        },
      },
    });

    if (!campaign) {
      return reply.status(404).send({
        success: false,
        error: 'Campaign not found',
      });
    }

    await prisma.campaignLead.deleteMany({
      where: {
        campaignId,
        leadId: { in: leadIds },
      },
    });

    return reply.send({
      success: true,
      message: 'Leads removed from campaign',
    });
  });

  // Get campaign stats
  fastify.get('/:campaignId/stats', async (request, reply) => {
    const { campaignId } = request.params as { campaignId: string };
    const userId = request.user!.userId;

    const campaign = await prisma.campaign.findFirst({
      where: {
        id: campaignId,
        deletedAt: null,
        workspace: {
          OR: [
            { ownerId: userId },
            { members: { some: { userId } } },
          ],
        },
      },
    });

    if (!campaign) {
      return reply.status(404).send({
        success: false,
        error: 'Campaign not found',
      });
    }

    const [
      totalLeads,
      byStatus,
      metrics,
    ] = await Promise.all([
      prisma.campaignLead.count({
        where: { campaignId },
      }),
      prisma.campaignLead.groupBy({
        by: ['status'],
        where: { campaignId },
        _count: { status: true },
      }),
      prisma.campaignMetric.findMany({
        where: { campaignId },
        orderBy: { date: 'desc' },
        take: 30,
      }),
    ]);

    return reply.send({
      success: true,
      data: {
        totalLeads,
        byStatus,
        metrics,
        progress: {
          completed: campaign.completedCount,
          target: campaign.targetCount,
          percentage: campaign.targetCount
            ? Math.round((campaign.completedCount / campaign.targetCount) * 100)
            : 0,
        },
      },
    });
  });
}
