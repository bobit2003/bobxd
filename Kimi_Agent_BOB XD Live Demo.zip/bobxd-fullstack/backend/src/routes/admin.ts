import { FastifyInstance, FastifyPluginOptions } from 'fastify';
import { z } from 'zod';
import { prisma } from '../prisma/client';
import { authenticate, requireRole } from '../middleware/auth';
import { logger } from '../utils/logger';

const querySchema = z.object({
  page: z.string().optional().default('1'),
  limit: z.string().optional().default('20'),
  search: z.string().optional(),
  status: z.string().optional(),
  role: z.string().optional(),
});

const updateUserSchema = z.object({
  firstName: z.string().optional(),
  lastName: z.string().optional(),
  role: z.enum(['USER', 'ADMIN', 'SUPER_ADMIN']).optional(),
  status: z.enum(['ACTIVE', 'INACTIVE', 'SUSPENDED']).optional(),
});

const systemSettingSchema = z.object({
  key: z.string(),
  value: z.any(),
  description: z.string().optional(),
});

export default async function adminRoutes(
  fastify: FastifyInstance,
  options: FastifyPluginOptions
): Promise<void> {
  // Apply authentication and admin role check
  fastify.addHook('preHandler', authenticate);
  fastify.addHook('preHandler', requireRole('ADMIN', 'SUPER_ADMIN'));

  // Dashboard stats
  fastify.get('/dashboard', async (request, reply) => {
    const [
      totalUsers,
      totalWorkspaces,
      totalLeads,
      totalAgents,
      totalCampaigns,
      totalExecutions,
      recentUsers,
      recentWorkspaces,
      subscriptionsByPlan,
      usersByStatus,
    ] = await Promise.all([
      prisma.user.count(),
      prisma.workspace.count({ where: { deletedAt: null } }),
      prisma.lead.count({ where: { deletedAt: null } }),
      prisma.agent.count({ where: { deletedAt: null } }),
      prisma.campaign.count({ where: { deletedAt: null } }),
      prisma.agentExecution.count(),
      prisma.user.findMany({
        orderBy: { createdAt: 'desc' },
        take: 5,
        select: {
          id: true,
          firstName: true,
          lastName: true,
          email: true,
          role: true,
          status: true,
          createdAt: true,
        },
      }),
      prisma.workspace.findMany({
        where: { deletedAt: null },
        orderBy: { createdAt: 'desc' },
        take: 5,
        include: {
          owner: {
            select: {
              id: true,
              firstName: true,
              lastName: true,
              email: true,
            },
          },
        },
      }),
      prisma.subscription.groupBy({
        by: ['plan'],
        _count: { plan: true },
      }),
      prisma.user.groupBy({
        by: ['status'],
        _count: { status: true },
      }),
    ]);

    return reply.send({
      success: true,
      data: {
        stats: {
          totalUsers,
          totalWorkspaces,
          totalLeads,
          totalAgents,
          totalCampaigns,
          totalExecutions,
        },
        recentUsers,
        recentWorkspaces,
        subscriptionsByPlan,
        usersByStatus,
      },
    });
  });

  // Get all users
  fastify.get('/users', async (request, reply) => {
    const query = querySchema.parse(request.query);

    const page = parseInt(query.page, 10);
    const limit = parseInt(query.limit, 10);
    const skip = (page - 1) * limit;

    const where: any = {};

    if (query.search) {
      where.OR = [
        { firstName: { contains: query.search, mode: 'insensitive' } },
        { lastName: { contains: query.search, mode: 'insensitive' } },
        { email: { contains: query.search, mode: 'insensitive' } },
      ];
    }

    if (query.status) {
      where.status = query.status;
    }

    if (query.role) {
      where.role = query.role;
    }

    const [users, total] = await Promise.all([
      prisma.user.findMany({
        where,
        select: {
          id: true,
          email: true,
          firstName: true,
          lastName: true,
          avatar: true,
          role: true,
          status: true,
          lastLoginAt: true,
          createdAt: true,
          _count: {
            select: {
              workspaces: true,
              leads: true,
              agents: true,
            },
          },
        },
        orderBy: { createdAt: 'desc' },
        skip,
        take: limit,
      }),
      prisma.user.count({ where }),
    ]);

    return reply.send({
      success: true,
      data: {
        users,
        pagination: {
          page,
          limit,
          total,
          totalPages: Math.ceil(total / limit),
        },
      },
    });
  });

  // Get user by ID
  fastify.get('/users/:userId', async (request, reply) => {
    const { userId } = request.params as { userId: string };

    const user = await prisma.user.findUnique({
      where: { id: userId },
      select: {
        id: true,
        email: true,
        firstName: true,
        lastName: true,
        avatar: true,
        role: true,
        status: true,
        emailVerified: true,
        lastLoginAt: true,
        createdAt: true,
        workspaces: {
          select: {
            workspace: {
              select: {
                id: true,
                name: true,
                slug: true,
                plan: true,
              },
            },
            role: true,
          },
        },
        subscriptions: {
          orderBy: { createdAt: 'desc' },
          take: 1,
        },
        _count: {
          select: {
            leads: true,
            agents: true,
            campaigns: true,
          },
        },
      },
    });

    if (!user) {
      return reply.status(404).send({
        success: false,
        error: 'User not found',
      });
    }

    return reply.send({
      success: true,
      data: user,
    });
  });

  // Update user
  fastify.patch('/users/:userId', async (request, reply) => {
    const { userId } = request.params as { userId: string };
    const data = updateUserSchema.parse(request.body);

    const user = await prisma.user.findUnique({
      where: { id: userId },
    });

    if (!user) {
      return reply.status(404).send({
        success: false,
        error: 'User not found',
      });
    }

    const updated = await prisma.user.update({
      where: { id: userId },
      data,
      select: {
        id: true,
        email: true,
        firstName: true,
        lastName: true,
        avatar: true,
        role: true,
        status: true,
        lastLoginAt: true,
        createdAt: true,
      },
    });

    logger.info({ userId, adminId: request.user!.userId }, 'User updated by admin');

    return reply.send({
      success: true,
      data: updated,
    });
  });

  // Delete user
  fastify.delete('/users/:userId', async (request, reply) => {
    const { userId } = request.params as { userId: string };

    const user = await prisma.user.findUnique({
      where: { id: userId },
    });

    if (!user) {
      return reply.status(404).send({
        success: false,
        error: 'User not found',
      });
    }

    // Don't allow deleting super admins
    if (user.role === 'SUPER_ADMIN') {
      return reply.status(403).send({
        success: false,
        error: 'Cannot delete super admin users',
      });
    }

    await prisma.user.delete({
      where: { id: userId },
    });

    logger.info({ userId, adminId: request.user!.userId }, 'User deleted by admin');

    return reply.send({
      success: true,
      message: 'User deleted successfully',
    });
  });

  // Get all workspaces
  fastify.get('/workspaces', async (request, reply) => {
    const query = querySchema.parse(request.query);

    const page = parseInt(query.page, 10);
    const limit = parseInt(query.limit, 10);
    const skip = (page - 1) * limit;

    const where: any = { deletedAt: null };

    if (query.search) {
      where.OR = [
        { name: { contains: query.search, mode: 'insensitive' } },
        { slug: { contains: query.search, mode: 'insensitive' } },
      ];
    }

    if (query.status) {
      where.status = query.status;
    }

    const [workspaces, total] = await Promise.all([
      prisma.workspace.findMany({
        where,
        include: {
          owner: {
            select: {
              id: true,
              firstName: true,
              lastName: true,
              email: true,
            },
          },
          _count: {
            select: {
              members: true,
              leads: true,
              agents: true,
              campaigns: true,
            },
          },
        },
        orderBy: { createdAt: 'desc' },
        skip,
        take: limit,
      }),
      prisma.workspace.count({ where }),
    ]);

    return reply.send({
      success: true,
      data: {
        workspaces,
        pagination: {
          page,
          limit,
          total,
          totalPages: Math.ceil(total / limit),
        },
      },
    });
  });

  // Get workspace by ID
  fastify.get('/workspaces/:workspaceId', async (request, reply) => {
    const { workspaceId } = request.params as { workspaceId: string };

    const workspace = await prisma.workspace.findUnique({
      where: { id: workspaceId },
      include: {
        owner: {
          select: {
            id: true,
            firstName: true,
            lastName: true,
            email: true,
          },
        },
        members: {
          include: {
            user: {
              select: {
                id: true,
                firstName: true,
                lastName: true,
                email: true,
              },
            },
          },
        },
        _count: {
          select: {
            leads: true,
            agents: true,
            campaigns: true,
          },
        },
      },
    });

    if (!workspace) {
      return reply.status(404).send({
        success: false,
        error: 'Workspace not found',
      });
    }

    return reply.send({
      success: true,
      data: workspace,
    });
  });

  // Update workspace
  fastify.patch('/workspaces/:workspaceId', async (request, reply) => {
    const { workspaceId } = request.params as { workspaceId: string };
    const data = z.object({
      name: z.string().optional(),
      plan: z.enum(['FREE', 'STARTER', 'PROFESSIONAL', 'ENTERPRISE']).optional(),
      status: z.enum(['ACTIVE', 'INACTIVE', 'SUSPENDED']).optional(),
    }).parse(request.body);

    const workspace = await prisma.workspace.findUnique({
      where: { id: workspaceId },
    });

    if (!workspace) {
      return reply.status(404).send({
        success: false,
        error: 'Workspace not found',
      });
    }

    const updated = await prisma.workspace.update({
      where: { id: workspaceId },
      data,
      include: {
        owner: {
          select: {
            id: true,
            firstName: true,
            lastName: true,
            email: true,
          },
        },
      },
    });

    logger.info({ workspaceId, adminId: request.user!.userId }, 'Workspace updated by admin');

    return reply.send({
      success: true,
      data: updated,
    });
  });

  // Delete workspace
  fastify.delete('/workspaces/:workspaceId', async (request, reply) => {
    const { workspaceId } = request.params as { workspaceId: string };

    const workspace = await prisma.workspace.findUnique({
      where: { id: workspaceId },
    });

    if (!workspace) {
      return reply.status(404).send({
        success: false,
        error: 'Workspace not found',
      });
    }

    await prisma.workspace.update({
      where: { id: workspaceId },
      data: { deletedAt: new Date() },
    });

    logger.info({ workspaceId, adminId: request.user!.userId }, 'Workspace deleted by admin');

    return reply.send({
      success: true,
      message: 'Workspace deleted successfully',
    });
  });

  // Get system settings
  fastify.get('/settings', async (request, reply) => {
    const settings = await prisma.systemSetting.findMany({
      orderBy: { key: 'asc' },
    });

    return reply.send({
      success: true,
      data: settings,
    });
  });

  // Update system setting
  fastify.put('/settings', async (request, reply) => {
    const data = systemSettingSchema.parse(request.body);

    const setting = await prisma.systemSetting.upsert({
      where: { key: data.key },
      update: {
        value: data.value,
        description: data.description,
      },
      create: {
        key: data.key,
        value: data.value,
        description: data.description,
      },
    });

    logger.info({ key: data.key, adminId: request.user!.userId }, 'System setting updated');

    return reply.send({
      success: true,
      data: setting,
    });
  });

  // Get audit logs
  fastify.get('/audit-logs', async (request, reply) => {
    const query = querySchema.parse(request.query);

    const page = parseInt(query.page, 10);
    const limit = parseInt(query.limit, 10);
    const skip = (page - 1) * limit;

    const [logs, total] = await Promise.all([
      prisma.auditLog.findMany({
        include: {
          user: {
            select: {
              id: true,
              firstName: true,
              lastName: true,
              email: true,
            },
          },
          workspace: {
            select: {
              id: true,
              name: true,
            },
          },
        },
        orderBy: { createdAt: 'desc' },
        skip,
        take: limit,
      }),
      prisma.auditLog.count(),
    ]);

    return reply.send({
      success: true,
      data: {
        logs,
        pagination: {
          page,
          limit,
          total,
          totalPages: Math.ceil(total / limit),
        },
      },
    });
  });

  // Get analytics
  fastify.get('/analytics', async (request, reply) => {
    const days = 30;
    const startDate = new Date(Date.now() - days * 24 * 60 * 60 * 1000);

    const [
      userGrowth,
      workspaceGrowth,
      leadGrowth,
      executionStats,
    ] = await Promise.all([
      prisma.user.groupBy({
        by: ['createdAt'],
        where: {
          createdAt: { gte: startDate },
        },
        _count: { id: true },
      }),
      prisma.workspace.groupBy({
        by: ['createdAt'],
        where: {
          createdAt: { gte: startDate },
        },
        _count: { id: true },
      }),
      prisma.lead.groupBy({
        by: ['createdAt'],
        where: {
          createdAt: { gte: startDate },
        },
        _count: { id: true },
      }),
      prisma.agentExecution.groupBy({
        by: ['status'],
        _count: { status: true },
      }),
    ]);

    return reply.send({
      success: true,
      data: {
        userGrowth,
        workspaceGrowth,
        leadGrowth,
        executionStats,
      },
    });
  });
}
