import { FastifyInstance, FastifyPluginOptions } from 'fastify';
import { z } from 'zod';
import { prisma } from '../prisma/client';
import { authenticate, requireWorkspaceAccess, requireWorkspaceRole } from '../middleware/auth';
import { createWorkspaceSchema } from '../types';
import { logger } from '../utils/logger';

const updateWorkspaceSchema = createWorkspaceSchema.partial();

const inviteMemberSchema = z.object({
  email: z.string().email(),
  role: z.enum(['ADMIN', 'MEMBER', 'VIEWER']).default('MEMBER'),
});

const updateMemberSchema = z.object({
  role: z.enum(['ADMIN', 'MEMBER', 'VIEWER']),
});

export default async function workspaceRoutes(
  fastify: FastifyInstance,
  options: FastifyPluginOptions
): Promise<void> {
  // Apply authentication to all routes
  fastify.addHook('preHandler', authenticate);

  // Get all workspaces for current user
  fastify.get('/', async (request, reply) => {
    const userId = request.user!.userId;

    const workspaces = await prisma.workspace.findMany({
      where: {
        OR: [
          { ownerId: userId },
          { members: { some: { userId } } },
        ],
        deletedAt: null,
      },
      include: {
        owner: {
          select: {
            id: true,
            firstName: true,
            lastName: true,
            email: true,
            avatar: true,
          },
        },
        _count: {
          select: {
            members: true,
            leads: true,
            agents: true,
            campaigns: true,
          },
        },
      },
      orderBy: { createdAt: 'desc' },
    });

    return reply.send({
      success: true,
      data: workspaces,
    });
  });

  // Get workspace by ID
  fastify.get('/:workspaceId', async (request, reply) => {
    const { workspaceId } = request.params as { workspaceId: string };
    const userId = request.user!.userId;

    const workspace = await prisma.workspace.findFirst({
      where: {
        id: workspaceId,
        OR: [
          { ownerId: userId },
          { members: { some: { userId } } },
        ],
        deletedAt: null,
      },
      include: {
        owner: {
          select: {
            id: true,
            firstName: true,
            lastName: true,
            email: true,
            avatar: true,
          },
        },
        members: {
          include: {
            user: {
              select: {
                id: true,
                firstName: true,
                lastName: true,
                email: true,
                avatar: true,
              },
            },
          },
        },
        _count: {
          select: {
            leads: true,
            agents: true,
            campaigns: true,
          },
        },
      },
    });

    if (!workspace) {
      return reply.status(404).send({
        success: false,
        error: 'Workspace not found',
      });
    }

    return reply.send({
      success: true,
      data: workspace,
    });
  });

  // Create workspace
  fastify.post('/', async (request, reply) => {
    const data = createWorkspaceSchema.parse(request.body);
    const userId = request.user!.userId;

    // Check if slug is unique
    const existing = await prisma.workspace.findUnique({
      where: { slug: data.slug },
    });

    if (existing) {
      return reply.status(409).send({
        success: false,
        error: 'Workspace slug already exists',
      });
    }

    const workspace = await prisma.workspace.create({
      data: {
        name: data.name,
        slug: data.slug,
        description: data.description,
        ownerId: userId,
      },
      include: {
        owner: {
          select: {
            id: true,
            firstName: true,
            lastName: true,
            email: true,
            avatar: true,
          },
        },
      },
    });

    logger.info({ workspaceId: workspace.id, userId }, 'Workspace created');

    return reply.status(201).send({
      success: true,
      data: workspace,
    });
  });

  // Update workspace
  fastify.patch('/:workspaceId', async (request, reply) => {
    const { workspaceId } = request.params as { workspaceId: string };
    const data = updateWorkspaceSchema.parse(request.body);
    const userId = request.user!.userId;

    // Check access
    const workspace = await prisma.workspace.findFirst({
      where: {
        id: workspaceId,
        OR: [
          { ownerId: userId },
          { members: { some: { userId, role: { in: ['ADMIN', 'OWNER'] } } } },
        ],
      },
    });

    if (!workspace) {
      return reply.status(404).send({
        success: false,
        error: 'Workspace not found or access denied',
      });
    }

    // Check slug uniqueness if provided
    if (data.slug && data.slug !== workspace.slug) {
      const existing = await prisma.workspace.findUnique({
        where: { slug: data.slug },
      });

      if (existing) {
        return reply.status(409).send({
          success: false,
          error: 'Workspace slug already exists',
        });
      }
    }

    const updated = await prisma.workspace.update({
      where: { id: workspaceId },
      data,
      include: {
        owner: {
          select: {
            id: true,
            firstName: true,
            lastName: true,
            email: true,
            avatar: true,
          },
        },
        members: {
          include: {
            user: {
              select: {
                id: true,
                firstName: true,
                lastName: true,
                email: true,
                avatar: true,
              },
            },
          },
        },
      },
    });

    logger.info({ workspaceId, userId }, 'Workspace updated');

    return reply.send({
      success: true,
      data: updated,
    });
  });

  // Delete workspace
  fastify.delete('/:workspaceId', async (request, reply) => {
    const { workspaceId } = request.params as { workspaceId: string };
    const userId = request.user!.userId;

    // Only owner can delete
    const workspace = await prisma.workspace.findFirst({
      where: {
        id: workspaceId,
        ownerId: userId,
      },
    });

    if (!workspace) {
      return reply.status(404).send({
        success: false,
        error: 'Workspace not found or access denied',
      });
    }

    // Soft delete
    await prisma.workspace.update({
      where: { id: workspaceId },
      data: { deletedAt: new Date() },
    });

    logger.info({ workspaceId, userId }, 'Workspace deleted');

    return reply.send({
      success: true,
      message: 'Workspace deleted successfully',
    });
  });

  // Get workspace members
  fastify.get('/:workspaceId/members', async (request, reply) => {
    const { workspaceId } = request.params as { workspaceId: string };
    const userId = request.user!.userId;

    // Check access
    const hasAccess = await prisma.workspace.findFirst({
      where: {
        id: workspaceId,
        OR: [
          { ownerId: userId },
          { members: { some: { userId } } },
        ],
      },
    });

    if (!hasAccess) {
      return reply.status(404).send({
        success: false,
        error: 'Workspace not found or access denied',
      });
    }

    const members = await prisma.workspaceMember.findMany({
      where: { workspaceId },
      include: {
        user: {
          select: {
            id: true,
            firstName: true,
            lastName: true,
            email: true,
            avatar: true,
            lastLoginAt: true,
          },
        },
      },
      orderBy: { joinedAt: 'desc' },
    });

    return reply.send({
      success: true,
      data: members,
    });
  });

  // Invite member
  fastify.post('/:workspaceId/members', async (request, reply) => {
    const { workspaceId } = request.params as { workspaceId: string };
    const data = inviteMemberSchema.parse(request.body);
    const userId = request.user!.userId;

    // Check access (owner or admin)
    const workspace = await prisma.workspace.findFirst({
      where: {
        id: workspaceId,
        OR: [
          { ownerId: userId },
          { members: { some: { userId, role: 'ADMIN' } } },
        ],
      },
    });

    if (!workspace) {
      return reply.status(404).send({
        success: false,
        error: 'Workspace not found or access denied',
      });
    }

    // Find user by email
    const invitedUser = await prisma.user.findUnique({
      where: { email: data.email },
    });

    if (!invitedUser) {
      return reply.status(404).send({
        success: false,
        error: 'User not found with this email',
      });
    }

    // Check if already a member
    const existingMember = await prisma.workspaceMember.findFirst({
      where: {
        workspaceId,
        userId: invitedUser.id,
      },
    });

    if (existingMember) {
      return reply.status(409).send({
        success: false,
        error: 'User is already a member of this workspace',
      });
    }

    const member = await prisma.workspaceMember.create({
      data: {
        workspaceId,
        userId: invitedUser.id,
        role: data.role,
      },
      include: {
        user: {
          select: {
            id: true,
            firstName: true,
            lastName: true,
            email: true,
            avatar: true,
          },
        },
      },
    });

    logger.info({ workspaceId, userId: invitedUser.id }, 'Member invited');

    return reply.status(201).send({
      success: true,
      data: member,
    });
  });

  // Update member role
  fastify.patch('/:workspaceId/members/:memberId', async (request, reply) => {
    const { workspaceId, memberId } = request.params as { workspaceId: string; memberId: string };
    const data = updateMemberSchema.parse(request.body);
    const userId = request.user!.userId;

    // Check access (owner or admin)
    const workspace = await prisma.workspace.findFirst({
      where: {
        id: workspaceId,
        OR: [
          { ownerId: userId },
          { members: { some: { userId, role: 'ADMIN' } } },
        ],
      },
    });

    if (!workspace) {
      return reply.status(404).send({
        success: false,
        error: 'Workspace not found or access denied',
      });
    }

    const member = await prisma.workspaceMember.update({
      where: { id: memberId },
      data: { role: data.role },
      include: {
        user: {
          select: {
            id: true,
            firstName: true,
            lastName: true,
            email: true,
            avatar: true,
          },
        },
      },
    });

    return reply.send({
      success: true,
      data: member,
    });
  });

  // Remove member
  fastify.delete('/:workspaceId/members/:memberId', async (request, reply) => {
    const { workspaceId, memberId } = request.params as { workspaceId: string; memberId: string };
    const userId = request.user!.userId;

    // Check access (owner or admin)
    const workspace = await prisma.workspace.findFirst({
      where: {
        id: workspaceId,
        OR: [
          { ownerId: userId },
          { members: { some: { userId, role: 'ADMIN' } } },
        ],
      },
    });

    if (!workspace) {
      return reply.status(404).send({
        success: false,
        error: 'Workspace not found or access denied',
      });
    }

    await prisma.workspaceMember.delete({
      where: { id: memberId },
    });

    return reply.send({
      success: true,
      message: 'Member removed successfully',
    });
  });

  // Get workspace stats
  fastify.get('/:workspaceId/stats', async (request, reply) => {
    const { workspaceId } = request.params as { workspaceId: string };
    const userId = request.user!.userId;

    // Check access
    const hasAccess = await prisma.workspace.findFirst({
      where: {
        id: workspaceId,
        OR: [
          { ownerId: userId },
          { members: { some: { userId } } },
        ],
      },
    });

    if (!hasAccess) {
      return reply.status(404).send({
        success: false,
        error: 'Workspace not found or access denied',
      });
    }

    const [
      totalLeads,
      newLeadsThisWeek,
      totalCampaigns,
      activeCampaigns,
      totalAgents,
      activeAgents,
    ] = await Promise.all([
      prisma.lead.count({ where: { workspaceId, deletedAt: null } }),
      prisma.lead.count({
        where: {
          workspaceId,
          deletedAt: null,
          createdAt: { gte: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000) },
        },
      }),
      prisma.campaign.count({ where: { workspaceId, deletedAt: null } }),
      prisma.campaign.count({
        where: {
          workspaceId,
          deletedAt: null,
          status: { in: ['RUNNING', 'SCHEDULED'] },
        },
      }),
      prisma.agent.count({ where: { workspaceId, deletedAt: null } }),
      prisma.agent.count({
        where: {
          workspaceId,
          deletedAt: null,
          status: 'ACTIVE',
        },
      }),
    ]);

    return reply.send({
      success: true,
      data: {
        totalLeads,
        newLeadsThisWeek,
        totalCampaigns,
        activeCampaigns,
        totalAgents,
        activeAgents,
      },
    });
  });
}
