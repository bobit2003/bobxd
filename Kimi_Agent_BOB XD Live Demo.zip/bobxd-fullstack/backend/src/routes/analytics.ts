import { FastifyInstance, FastifyPluginOptions } from 'fastify';
import { z } from 'zod';
import { prisma } from '../prisma/client';
import { authenticate } from '../middleware/auth';

const dateRangeSchema = z.object({
  startDate: z.string().datetime().optional(),
  endDate: z.string().datetime().optional(),
  days: z.string().optional().default('30'),
});

export default async function analyticsRoutes(
  fastify: FastifyInstance,
  options: FastifyPluginOptions
): Promise<void> {
  // Apply authentication to all routes
  fastify.addHook('preHandler', authenticate);

  // Get dashboard stats for workspace
  fastify.get('/workspace/:workspaceId/dashboard', async (request, reply) => {
    const { workspaceId } = request.params as { workspaceId: string };
    const userId = request.user!.userId;

    // Check workspace access
    const hasAccess = await prisma.workspace.findFirst({
      where: {
        id: workspaceId,
        OR: [
          { ownerId: userId },
          { members: { some: { userId } } },
        ],
      },
    });

    if (!hasAccess) {
      return reply.status(403).send({
        success: false,
        error: 'Access denied to this workspace',
      });
    }

    const now = new Date();
    const thirtyDaysAgo = new Date(now.getTime() - 30 * 24 * 60 * 60 * 1000);
    const sevenDaysAgo = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000);

    const [
      totalLeads,
      newLeadsThisMonth,
      newLeadsThisWeek,
      leadsByStatus,
      leadsBySource,
      totalCampaigns,
      activeCampaigns,
      campaignsByStatus,
      totalAgents,
      activeAgents,
      agentsByType,
      totalExecutions,
      executionsByStatus,
      recentExecutions,
      conversionStats,
    ] = await Promise.all([
      // Leads
      prisma.lead.count({
        where: { workspaceId, deletedAt: null },
      }),
      prisma.lead.count({
        where: {
          workspaceId,
          deletedAt: null,
          createdAt: { gte: thirtyDaysAgo },
        },
      }),
      prisma.lead.count({
        where: {
          workspaceId,
          deletedAt: null,
          createdAt: { gte: sevenDaysAgo },
        },
      }),
      prisma.lead.groupBy({
        by: ['status'],
        where: { workspaceId, deletedAt: null },
        _count: { status: true },
      }),
      prisma.lead.groupBy({
        by: ['source'],
        where: { workspaceId, deletedAt: null },
        _count: { source: true },
      }),

      // Campaigns
      prisma.campaign.count({
        where: { workspaceId, deletedAt: null },
      }),
      prisma.campaign.count({
        where: {
          workspaceId,
          deletedAt: null,
          status: { in: ['RUNNING', 'SCHEDULED'] },
        },
      }),
      prisma.campaign.groupBy({
        by: ['status'],
        where: { workspaceId, deletedAt: null },
        _count: { status: true },
      }),

      // Agents
      prisma.agent.count({
        where: { workspaceId, deletedAt: null },
      }),
      prisma.agent.count({
        where: {
          workspaceId,
          deletedAt: null,
          status: 'ACTIVE',
        },
      }),
      prisma.agent.groupBy({
        by: ['type'],
        where: { workspaceId, deletedAt: null },
        _count: { type: true },
      }),

      // Executions
      prisma.agentExecution.count({
        where: { agent: { workspaceId } },
      }),
      prisma.agentExecution.groupBy({
        by: ['status'],
        where: { agent: { workspaceId } },
        _count: { status: true },
      }),
      prisma.agentExecution.findMany({
        where: { agent: { workspaceId } },
        orderBy: { createdAt: 'desc' },
        take: 10,
        include: {
          agent: {
            select: {
              id: true,
              name: true,
              type: true,
            },
          },
        },
      }),

      // Conversion stats
      prisma.lead.count({
        where: {
          workspaceId,
          deletedAt: null,
          status: { in: ['WON', 'QUALIFIED'] },
        },
      }),
    ]);

    // Calculate conversion rate
    const conversionRate = totalLeads > 0
      ? Math.round((conversionStats / totalLeads) * 100)
      : 0;

    // Get token usage
    const tokenUsage = await prisma.agent.aggregate({
      where: { workspaceId, deletedAt: null },
      _sum: { tokenUsage: true },
    });

    return reply.send({
      success: true,
      data: {
        leads: {
          total: totalLeads,
          newThisMonth: newLeadsThisMonth,
          newThisWeek: newLeadsThisWeek,
          byStatus: leadsByStatus,
          bySource: leadsBySource,
        },
        campaigns: {
          total: totalCampaigns,
          active: activeCampaigns,
          byStatus: campaignsByStatus,
        },
        agents: {
          total: totalAgents,
          active: activeAgents,
          byType: agentsByType,
        },
        executions: {
          total: totalExecutions,
          byStatus: executionsByStatus,
          recent: recentExecutions,
        },
        conversion: {
          rate: conversionRate,
          qualified: conversionStats,
        },
        usage: {
          tokens: tokenUsage._sum.tokenUsage || 0,
        },
      },
    });
  });

  // Get time series data
  fastify.get('/workspace/:workspaceId/timeseries', async (request, reply) => {
    const { workspaceId } = request.params as { workspaceId: string };
    const query = dateRangeSchema.parse(request.query);
    const userId = request.user!.userId;

    // Check workspace access
    const hasAccess = await prisma.workspace.findFirst({
      where: {
        id: workspaceId,
        OR: [
          { ownerId: userId },
          { members: { some: { userId } } },
        ],
      },
    });

    if (!hasAccess) {
      return reply.status(403).send({
        success: false,
        error: 'Access denied to this workspace',
      });
    }

    const days = parseInt(query.days, 10);
    const startDate = query.startDate
      ? new Date(query.startDate)
      : new Date(Date.now() - days * 24 * 60 * 60 * 1000);
    const endDate = query.endDate ? new Date(query.endDate) : new Date();

    // Get daily lead counts
    const leadsByDay = await prisma.lead.groupBy({
      by: ['createdAt'],
      where: {
        workspaceId,
        deletedAt: null,
        createdAt: {
          gte: startDate,
          lte: endDate,
        },
      },
      _count: { id: true },
    });

    // Get daily execution counts
    const executionsByDay = await prisma.agentExecution.groupBy({
      by: ['createdAt'],
      where: {
        agent: { workspaceId },
        createdAt: {
          gte: startDate,
          lte: endDate,
        },
      },
      _count: { id: true },
    });

    // Format data for charts
    const dateRange: Date[] = [];
    for (let d = new Date(startDate); d <= endDate; d.setDate(d.getDate() + 1)) {
      dateRange.push(new Date(d));
    }

    const leadsTimeSeries = dateRange.map((date) => {
      const dateStr = date.toISOString().split('T')[0];
      const count = leadsByDay.filter(
        (l) => l.createdAt.toISOString().split('T')[0] === dateStr
      ).reduce((sum, l) => sum + l._count.id, 0);
      return { date: dateStr, value: count };
    });

    const executionsTimeSeries = dateRange.map((date) => {
      const dateStr = date.toISOString().split('T')[0];
      const count = executionsByDay.filter(
        (e) => e.createdAt.toISOString().split('T')[0] === dateStr
      ).reduce((sum, e) => sum + e._count.id, 0);
      return { date: dateStr, value: count };
    });

    return reply.send({
      success: true,
      data: {
        leads: leadsTimeSeries,
        executions: executionsTimeSeries,
      },
    });
  });

  // Get lead funnel data
  fastify.get('/workspace/:workspaceId/funnel', async (request, reply) => {
    const { workspaceId } = request.params as { workspaceId: string };
    const userId = request.user!.userId;

    // Check workspace access
    const hasAccess = await prisma.workspace.findFirst({
      where: {
        id: workspaceId,
        OR: [
          { ownerId: userId },
          { members: { some: { userId } } },
        ],
      },
    });

    if (!hasAccess) {
      return reply.status(403).send({
        success: false,
        error: 'Access denied to this workspace',
      });
    }

    const funnelData = await prisma.lead.groupBy({
      by: ['status'],
      where: { workspaceId, deletedAt: null },
      _count: { status: true },
    });

    // Define funnel stages
    const stages = [
      { name: 'New', status: 'NEW', order: 1 },
      { name: 'Contacted', status: 'CONTACTED', order: 2 },
      { name: 'Qualified', status: 'QUALIFIED', order: 3 },
      { name: 'Proposal', status: 'PROPOSAL', order: 4 },
      { name: 'Negotiation', status: 'NEGOTIATION', order: 5 },
      { name: 'Won', status: 'WON', order: 6 },
    ];

    const formattedFunnel = stages.map((stage) => {
      const data = funnelData.find((d) => d.status === stage.status);
      return {
        name: stage.name,
        status: stage.status,
        count: data?._count.status || 0,
      };
    });

    return reply.send({
      success: true,
      data: formattedFunnel,
    });
  });

  // Get agent performance
  fastify.get('/workspace/:workspaceId/agent-performance', async (request, reply) => {
    const { workspaceId } = request.params as { workspaceId: string };
    const userId = request.user!.userId;

    // Check workspace access
    const hasAccess = await prisma.workspace.findFirst({
      where: {
        id: workspaceId,
        OR: [
          { ownerId: userId },
          { members: { some: { userId } } },
        ],
      },
    });

    if (!hasAccess) {
      return reply.status(403).send({
        success: false,
        error: 'Access denied to this workspace',
      });
    }

    const agents = await prisma.agent.findMany({
      where: { workspaceId, deletedAt: null },
      include: {
        executions: {
          select: {
            status: true,
            tokensUsed: true,
            cost: true,
            createdAt: true,
          },
        },
        _count: {
          select: {
            executions: true,
            campaigns: true,
          },
        },
      },
    });

    const performanceData = agents.map((agent) => {
      const completedExecutions = agent.executions.filter(
        (e) => e.status === 'COMPLETED'
      ).length;
      const failedExecutions = agent.executions.filter(
        (e) => e.status === 'FAILED'
      ).length;
      const totalTokens = agent.executions.reduce(
        (sum, e) => sum + e.tokensUsed,
        0
      );
      const totalCost = agent.executions.reduce(
        (sum, e) => sum + Number(e.cost),
        0
      );

      return {
        id: agent.id,
        name: agent.name,
        type: agent.type,
        status: agent.status,
        totalExecutions: agent._count.executions,
        completedExecutions,
        failedExecutions,
        successRate:
          agent._count.executions > 0
            ? Math.round((completedExecutions / agent._count.executions) * 100)
            : 0,
        totalTokens,
        totalCost: Number(totalCost.toFixed(4)),
        campaignCount: agent._count.campaigns,
      };
    });

    return reply.send({
      success: true,
      data: performanceData,
    });
  });

  // Get campaign performance
  fastify.get('/workspace/:workspaceId/campaign-performance', async (request, reply) => {
    const { workspaceId } = request.params as { workspaceId: string };
    const userId = request.user!.userId;

    // Check workspace access
    const hasAccess = await prisma.workspace.findFirst({
      where: {
        id: workspaceId,
        OR: [
          { ownerId: userId },
          { members: { some: { userId } } },
        ],
      },
    });

    if (!hasAccess) {
      return reply.status(403).send({
        success: false,
        error: 'Access denied to this workspace',
      });
    }

    const campaigns = await prisma.campaign.findMany({
      where: { workspaceId, deletedAt: null },
      include: {
        leads: {
          select: {
            status: true,
          },
        },
        metrics: {
          orderBy: { date: 'desc' },
          take: 30,
        },
        _count: {
          select: {
            leads: true,
          },
        },
      },
    });

    const performanceData = campaigns.map((campaign) => {
      const completedLeads = campaign.leads.filter(
        (l) => l.status === 'COMPLETED'
      ).length;
      const failedLeads = campaign.leads.filter(
        (l) => l.status === 'FAILED'
      ).length;

      return {
        id: campaign.id,
        name: campaign.name,
        type: campaign.type,
        status: campaign.status,
        totalLeads: campaign._count.leads,
        completedLeads,
        failedLeads,
        progress:
          campaign.targetCount && campaign.targetCount > 0
            ? Math.round((campaign.completedCount / campaign.targetCount) * 100)
            : 0,
        completionRate:
          campaign._count.leads > 0
            ? Math.round((completedLeads / campaign._count.leads) * 100)
            : 0,
        metrics: campaign.metrics,
      };
    });

    return reply.send({
      success: true,
      data: performanceData,
    });
  });
}
