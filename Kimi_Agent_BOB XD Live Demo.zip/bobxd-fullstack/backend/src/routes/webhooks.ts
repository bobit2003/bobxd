import { FastifyInstance, FastifyPluginOptions } from 'fastify';
import { z } from 'zod';
import { prisma } from '../prisma/client';
import { authenticate } from '../middleware/auth';
import { logger } from '../utils/logger';

const createWebhookSchema = z.object({
  name: z.string().min(1),
  url: z.string().url(),
  events: z.array(z.string()).min(1),
  secret: z.string().optional(),
});

const updateWebhookSchema = z.object({
  name: z.string().optional(),
  url: z.string().url().optional(),
  events: z.array(z.string()).optional(),
  secret: z.string().optional(),
  isActive: z.boolean().optional(),
});

const testWebhookSchema = z.object({
  event: z.string(),
  payload: z.record(z.any()).optional(),
});

// Available webhook events
const WEBHOOK_EVENTS = [
  'lead.created',
  'lead.updated',
  'lead.deleted',
  'lead.status_changed',
  'agent.created',
  'agent.updated',
  'agent.deleted',
  'agent.execution_completed',
  'agent.execution_failed',
  'campaign.created',
  'campaign.updated',
  'campaign.started',
  'campaign.paused',
  'campaign.completed',
  'campaign.lead_enrolled',
  'campaign.lead_processed',
  'workspace.member_invited',
  'workspace.member_removed',
];

export default async function webhookRoutes(
  fastify: FastifyInstance,
  options: FastifyPluginOptions
): Promise<void> {
  // Apply authentication to all routes
  fastify.addHook('preHandler', authenticate);

  // Get available events
  fastify.get('/events', async (request, reply) => {
    return reply.send({
      success: true,
      data: WEBHOOK_EVENTS,
    });
  });

  // Get webhooks for workspace
  fastify.get('/workspace/:workspaceId', async (request, reply) => {
    const { workspaceId } = request.params as { workspaceId: string };
    const userId = request.user!.userId;

    // Check workspace access
    const hasAccess = await prisma.workspace.findFirst({
      where: {
        id: workspaceId,
        OR: [
          { ownerId: userId },
          { members: { some: { userId } } },
        ],
      },
    });

    if (!hasAccess) {
      return reply.status(403).send({
        success: false,
        error: 'Access denied to this workspace',
      });
    }

    const webhooks = await prisma.webhook.findMany({
      where: { workspaceId },
      orderBy: { createdAt: 'desc' },
    });

    return reply.send({
      success: true,
      data: webhooks,
    });
  });

  // Get webhook by ID
  fastify.get('/:webhookId', async (request, reply) => {
    const { webhookId } = request.params as { webhookId: string };
    const userId = request.user!.userId;

    const webhook = await prisma.webhook.findFirst({
      where: {
        id: webhookId,
        workspace: {
          OR: [
            { ownerId: userId },
            { members: { some: { userId } } },
          ],
        },
      },
    });

    if (!webhook) {
      return reply.status(404).send({
        success: false,
        error: 'Webhook not found',
      });
    }

    return reply.send({
      success: true,
      data: webhook,
    });
  });

  // Create webhook
  fastify.post('/workspace/:workspaceId', async (request, reply) => {
    const { workspaceId } = request.params as { workspaceId: string };
    const data = createWebhookSchema.parse(request.body);
    const userId = request.user!.userId;

    // Check workspace access
    const hasAccess = await prisma.workspace.findFirst({
      where: {
        id: workspaceId,
        OR: [
          { ownerId: userId },
          { members: { some: { userId, role: { in: ['ADMIN', 'OWNER'] } } } },
          ],
      },
    });

    if (!hasAccess) {
      return reply.status(403).send({
        success: false,
        error: 'Access denied to this workspace',
      });
    }

    // Validate events
    const invalidEvents = data.events.filter(
      (event) => !WEBHOOK_EVENTS.includes(event)
    );

    if (invalidEvents.length > 0) {
      return reply.status(400).send({
        success: false,
        error: `Invalid events: ${invalidEvents.join(', ')}`,
      });
    }

    const webhook = await prisma.webhook.create({
      data: {
        ...data,
        workspaceId,
      },
    });

    logger.info({ webhookId: webhook.id, workspaceId }, 'Webhook created');

    return reply.status(201).send({
      success: true,
      data: webhook,
    });
  });

  // Update webhook
  fastify.patch('/:webhookId', async (request, reply) => {
    const { webhookId } = request.params as { webhookId: string };
    const data = updateWebhookSchema.parse(request.body);
    const userId = request.user!.userId;

    const webhook = await prisma.webhook.findFirst({
      where: {
        id: webhookId,
        workspace: {
          OR: [
            { ownerId: userId },
            { members: { some: { userId, role: { in: ['ADMIN', 'OWNER'] } } } },
          ],
        },
      },
    });

    if (!webhook) {
      return reply.status(404).send({
        success: false,
        error: 'Webhook not found',
      });
    }

    // Validate events if provided
    if (data.events) {
      const invalidEvents = data.events.filter(
        (event) => !WEBHOOK_EVENTS.includes(event)
      );

      if (invalidEvents.length > 0) {
        return reply.status(400).send({
          success: false,
          error: `Invalid events: ${invalidEvents.join(', ')}`,
        });
      }
    }

    const updated = await prisma.webhook.update({
      where: { id: webhookId },
      data: {
        ...data,
        updatedAt: new Date(),
      },
    });

    return reply.send({
      success: true,
      data: updated,
    });
  });

  // Delete webhook
  fastify.delete('/:webhookId', async (request, reply) => {
    const { webhookId } = request.params as { webhookId: string };
    const userId = request.user!.userId;

    const webhook = await prisma.webhook.findFirst({
      where: {
        id: webhookId,
        workspace: {
          OR: [
            { ownerId: userId },
            { members: { some: { userId, role: { in: ['ADMIN', 'OWNER'] } } } },
          ],
        },
      },
    });

    if (!webhook) {
      return reply.status(404).send({
        success: false,
        error: 'Webhook not found',
      });
    }

    await prisma.webhook.delete({
      where: { id: webhookId },
    });

    logger.info({ webhookId }, 'Webhook deleted');

    return reply.send({
      success: true,
      message: 'Webhook deleted successfully',
    });
  });

  // Test webhook
  fastify.post('/:webhookId/test', async (request, reply) => {
    const { webhookId } = request.params as { webhookId: string };
    const data = testWebhookSchema.parse(request.body);
    const userId = request.user!.userId;

    const webhook = await prisma.webhook.findFirst({
      where: {
        id: webhookId,
        workspace: {
          OR: [
            { ownerId: userId },
            { members: { some: { userId, role: { in: ['ADMIN', 'OWNER'] } } } },
          ],
        },
      },
    });

    if (!webhook) {
      return reply.status(404).send({
        success: false,
        error: 'Webhook not found',
      });
    }

    // Send test payload
    const testPayload = {
      event: data.event,
      timestamp: new Date().toISOString(),
      data: data.payload || { message: 'This is a test webhook' },
    };

    try {
      const response = await fetch(webhook.url, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'X-Webhook-Secret': webhook.secret || '',
          'X-Webhook-Event': data.event,
          'X-Webhook-Test': 'true',
          'User-Agent': 'BOBXD-Webhook/1.0',
        },
        body: JSON.stringify(testPayload),
      });

      // Update last triggered
      await prisma.webhook.update({
        where: { id: webhookId },
        data: { lastTriggeredAt: new Date() },
      });

      return reply.send({
        success: true,
        data: {
          status: response.status,
          statusText: response.statusText,
          sent: true,
        },
      });
    } catch (error) {
      return reply.status(500).send({
        success: false,
        error: 'Failed to send test webhook',
        details: error instanceof Error ? error.message : 'Unknown error',
      });
    }
  });

  // Toggle webhook status
  fastify.post('/:webhookId/toggle', async (request, reply) => {
    const { webhookId } = request.params as { webhookId: string };
    const userId = request.user!.userId;

    const webhook = await prisma.webhook.findFirst({
      where: {
        id: webhookId,
        workspace: {
          OR: [
            { ownerId: userId },
            { members: { some: { userId, role: { in: ['ADMIN', 'OWNER'] } } } },
          ],
        },
      },
    });

    if (!webhook) {
      return reply.status(404).send({
        success: false,
        error: 'Webhook not found',
      });
    }

    const updated = await prisma.webhook.update({
      where: { id: webhookId },
      data: { isActive: !webhook.isActive },
    });

    return reply.send({
      success: true,
      data: updated,
    });
  });
}

// Helper function to trigger webhooks
export async function triggerWebhook(
  workspaceId: string,
  event: string,
  payload: Record<string, unknown>
): Promise<void> {
  try {
    const webhooks = await prisma.webhook.findMany({
      where: {
        workspaceId,
        isActive: true,
        events: { has: event },
      },
    });

    for (const webhook of webhooks) {
      try {
        const webhookPayload = {
          event,
          timestamp: new Date().toISOString(),
          data: payload,
        };

        await fetch(webhook.url, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'X-Webhook-Secret': webhook.secret || '',
            'X-Webhook-Event': event,
            'User-Agent': 'BOBXD-Webhook/1.0',
          },
          body: JSON.stringify(webhookPayload),
        });

        // Update last triggered
        await prisma.webhook.update({
          where: { id: webhook.id },
          data: { lastTriggeredAt: new Date() },
        });

        logger.debug({ webhookId: webhook.id, event }, 'Webhook triggered');
      } catch (error) {
        logger.error(
          { error, webhookId: webhook.id, event },
          'Failed to trigger webhook'
        );
      }
    }
  } catch (error) {
    logger.error({ error, workspaceId, event }, 'Error triggering webhooks');
  }
}
