import { FastifyInstance, FastifyPluginOptions } from 'fastify';
import { z } from 'zod';
import { prisma } from '../prisma/client';
import { authenticate, requireRole } from '../middleware/auth';
import { logger } from '../utils/logger';

const updateLandingContentSchema = z.object({
  content: z.record(z.any()),
  isActive: z.boolean().optional(),
});

// Default landing content
const DEFAULT_LANDING_CONTENT = {
  hero: {
    title: 'BOB XD - AI Operating System for Agencies',
    subtitle: 'Automate lead generation, qualification, and nurturing with intelligent AI agents',
    ctaPrimary: 'Get Started Free',
    ctaSecondary: 'Watch Demo',
    image: '/images/hero-dashboard.png',
  },
  features: [
    {
      title: 'AI Lead Qualification',
      description: 'Let AI agents qualify leads 24/7 based on your criteria',
      icon: 'brain',
    },
    {
      title: 'Automated Campaigns',
      description: 'Run multi-channel campaigns that adapt to lead behavior',
      icon: 'rocket',
    },
    {
      title: 'Smart Follow-ups',
      description: 'Never miss a follow-up with AI-powered scheduling',
      icon: 'clock',
    },
    {
      title: 'Data Enrichment',
      description: 'Automatically enrich lead data from multiple sources',
      icon: 'database',
    },
    {
      title: 'Team Collaboration',
      description: 'Work together with shared workspaces and assignments',
      icon: 'users',
    },
    {
      title: 'Advanced Analytics',
      description: 'Track performance with detailed insights and reports',
      icon: 'chart',
    },
  ],
  pricing: {
    title: 'Simple, Transparent Pricing',
    subtitle: 'Start free, scale as you grow',
    plans: [
      {
        name: 'Free',
        price: 0,
        period: 'forever',
        description: 'Perfect for getting started',
        features: [
          '1 Workspace',
          '100 Leads',
          '2 AI Agents',
          '3 Campaigns',
          'Community Support',
        ],
        cta: 'Get Started',
        highlighted: false,
      },
      {
        name: 'Starter',
        price: 29,
        period: 'month',
        description: 'For growing agencies',
        features: [
          '3 Workspaces',
          '1,000 Leads',
          '5 AI Agents',
          '10 Campaigns',
          'Email Support',
        ],
        cta: 'Start Free Trial',
        highlighted: false,
      },
      {
        name: 'Professional',
        price: 99,
        period: 'month',
        description: 'For established teams',
        features: [
          '10 Workspaces',
          '10,000 Leads',
          '20 AI Agents',
          '50 Campaigns',
          'Priority Support',
        ],
        cta: 'Start Free Trial',
        highlighted: true,
      },
      {
        name: 'Enterprise',
        price: 299,
        period: 'month',
        description: 'For large organizations',
        features: [
          'Unlimited Workspaces',
          'Unlimited Leads',
          'Unlimited Agents',
          'Unlimited Campaigns',
          'Dedicated Support',
        ],
        cta: 'Contact Sales',
        highlighted: false,
      },
    ],
  },
  testimonials: [
    {
      name: 'Sarah Johnson',
      role: 'CEO, Growth Agency',
      content: 'BOB XD transformed our lead generation process. We saw a 300% increase in qualified leads within the first month.',
      avatar: '/images/testimonial-1.jpg',
    },
    {
      name: 'Michael Chen',
      role: 'Sales Director, TechScale',
      content: 'The AI agents work tirelessly, qualifying leads while we sleep. It\'s like having a 24/7 sales team.',
      avatar: '/images/testimonial-2.jpg',
    },
    {
      name: 'Emily Rodriguez',
      role: 'Founder, LeadGen Pro',
      content: 'Best investment we made this year. The automation saved us 40 hours per week on manual lead follow-ups.',
      avatar: '/images/testimonial-3.jpg',
    },
  ],
  cta: {
    title: 'Ready to Supercharge Your Lead Generation?',
    subtitle: 'Join thousands of agencies using BOB XD to grow their business',
    buttonText: 'Start Free Trial',
    buttonSubtext: 'No credit card required',
  },
  footer: {
    company: {
      name: 'BOB XD',
      description: 'The AI Operating System for Modern Agencies',
    },
    links: {
      product: ['Features', 'Pricing', 'Integrations', 'API'],
      company: ['About', 'Blog', 'Careers', 'Contact'],
      resources: ['Documentation', 'Help Center', 'Community', 'Status'],
      legal: ['Privacy', 'Terms', 'Security'],
    },
    social: {
      twitter: 'https://twitter.com/bobxd',
      linkedin: 'https://linkedin.com/company/bobxd',
      github: 'https://github.com/bobxd',
    },
  },
};

export default async function landingRoutes(
  fastify: FastifyInstance,
  options: FastifyPluginOptions
): Promise<void> {
  // Public routes - no authentication required

  // Get all landing content
  fastify.get('/', async (request, reply) => {
    const content = await prisma.landingContent.findMany({
      where: { isActive: true },
    });

    // If no content in database, return default
    if (content.length === 0) {
      return reply.send({
        success: true,
        data: DEFAULT_LANDING_CONTENT,
      });
    }

    // Transform to object format
    const contentMap = content.reduce((acc: any, item: any) => {
      acc[item.section] = item.content;
      return acc;
    }, {});

    return reply.send({
      success: true,
      data: { ...DEFAULT_LANDING_CONTENT, ...contentMap },
    });
  });

  // Get specific section
  fastify.get('/:section', async (request, reply) => {
    const { section } = request.params as { section: string };

    const content = await prisma.landingContent.findUnique({
      where: { section },
    });

    if (!content || !content.isActive) {
      // Return default if available
      const defaultSection = (DEFAULT_LANDING_CONTENT as any)[section];
      if (defaultSection) {
        return reply.send({
          success: true,
          data: defaultSection,
        });
      }

      return reply.status(404).send({
        success: false,
        error: 'Section not found',
      });
    }

    return reply.send({
      success: true,
      data: content.content,
    });
  });

  // Protected routes - admin only
  fastify.register(async function (fastify) {
    fastify.addHook('preHandler', authenticate);
    fastify.addHook('preHandler', requireRole('ADMIN', 'SUPER_ADMIN'));

    // Get all landing content (admin)
    fastify.get('/admin/all', async (request, reply) => {
      const content = await prisma.landingContent.findMany({
        orderBy: { section: 'asc' },
      });

      return reply.send({
        success: true,
        data: content,
      });
    });

    // Update landing content
    fastify.put('/admin/:section', async (request, reply) => {
      const { section } = request.params as { section: string };
      const data = updateLandingContentSchema.parse(request.body);

      const content = await prisma.landingContent.upsert({
        where: { section },
        update: {
          content: data.content,
          ...(data.isActive !== undefined && { isActive: data.isActive }),
        },
        create: {
          section,
          content: data.content,
          isActive: data.isActive ?? true,
        },
      });

      logger.info({ section, adminId: request.user!.userId }, 'Landing content updated');

      return reply.send({
        success: true,
        data: content,
      });
    });

    // Delete landing content section
    fastify.delete('/admin/:section', async (request, reply) => {
      const { section } = request.params as { section: string };

      await prisma.landingContent.delete({
        where: { section },
      });

      logger.info({ section, adminId: request.user!.userId }, 'Landing content deleted');

      return reply.send({
        success: true,
        message: 'Section deleted successfully',
      });
    });

    // Reset to defaults
    fastify.post('/admin/reset', async (request, reply) => {
      // Delete all existing content
      await prisma.landingContent.deleteMany({});

      // Insert default content
      const sections = Object.entries(DEFAULT_LANDING_CONTENT);
      for (const [section, content] of sections) {
        await prisma.landingContent.create({
          data: {
            section,
            content: content as any,
            isActive: true,
          },
        });
      }

      logger.info({ adminId: request.user!.userId }, 'Landing content reset to defaults');

      return reply.send({
        success: true,
        message: 'Landing content reset to defaults',
      });
    });

    // Preview landing page (with draft content)
    fastify.post('/admin/preview', async (request, reply) => {
      const data = z.record(z.any()).parse(request.body);

      // Merge with defaults
      const previewContent = {
        ...DEFAULT_LANDING_CONTENT,
        ...data,
      };

      return reply.send({
        success: true,
        data: previewContent,
      });
    });
  });
}
