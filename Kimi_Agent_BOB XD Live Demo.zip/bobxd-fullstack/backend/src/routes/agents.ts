import { FastifyInstance, FastifyPluginOptions } from 'fastify';
import { z } from 'zod';
import { prisma } from '../prisma/client';
import { authenticate } from '../middleware/auth';
import { createAgentSchema, updateAgentSchema } from '../types';
import { openClawService } from '../services/openclaw.service';
import { logger } from '../utils/logger';

const querySchema = z.object({
  page: z.string().optional().default('1'),
  limit: z.string().optional().default('20'),
  search: z.string().optional(),
  status: z.string().optional(),
  type: z.string().optional(),
  sortBy: z.string().optional().default('createdAt'),
  sortOrder: z.enum(['asc', 'desc']).optional().default('desc'),
});

const executeTaskSchema = z.object({
  taskType: z.string(),
  input: z.record(z.any()),
});

export default async function agentRoutes(
  fastify: FastifyInstance,
  options: FastifyPluginOptions
): Promise<void> {
  // Apply authentication to all routes
  fastify.addHook('preHandler', authenticate);

  // Get agents for workspace
  fastify.get('/workspace/:workspaceId', async (request, reply) => {
    const { workspaceId } = request.params as { workspaceId: string };
    const query = querySchema.parse(request.query);
    const userId = request.user!.userId;

    // Check workspace access
    const hasAccess = await prisma.workspace.findFirst({
      where: {
        id: workspaceId,
        OR: [
          { ownerId: userId },
          { members: { some: { userId } } },
        ],
      },
    });

    if (!hasAccess) {
      return reply.status(403).send({
        success: false,
        error: 'Access denied to this workspace',
      });
    }

    const page = parseInt(query.page, 10);
    const limit = parseInt(query.limit, 10);
    const skip = (page - 1) * limit;

    // Build where clause
    const where: any = {
      workspaceId,
      deletedAt: null,
    };

    if (query.search) {
      where.OR = [
        { name: { contains: query.search, mode: 'insensitive' } },
        { description: { contains: query.search, mode: 'insensitive' } },
      ];
    }

    if (query.status) {
      where.status = query.status;
    }

    if (query.type) {
      where.type = query.type;
    }

    const [agents, total] = await Promise.all([
      prisma.agent.findMany({
        where,
        include: {
          createdBy: {
            select: {
              id: true,
              firstName: true,
              lastName: true,
              email: true,
              avatar: true,
            },
          },
          _count: {
            select: {
              executions: true,
              campaigns: true,
            },
          },
        },
        orderBy: { [query.sortBy]: query.sortOrder },
        skip,
        take: limit,
      }),
      prisma.agent.count({ where }),
    ]);

    return reply.send({
      success: true,
      data: {
        agents,
        pagination: {
          page,
          limit,
          total,
          totalPages: Math.ceil(total / limit),
        },
      },
    });
  });

  // Get agent by ID
  fastify.get('/:agentId', async (request, reply) => {
    const { agentId } = request.params as { agentId: string };
    const userId = request.user!.userId;

    const agent = await prisma.agent.findFirst({
      where: {
        id: agentId,
        deletedAt: null,
        workspace: {
          OR: [
            { ownerId: userId },
            { members: { some: { userId } } },
          ],
        },
      },
      include: {
        createdBy: {
          select: {
            id: true,
            firstName: true,
            lastName: true,
            email: true,
            avatar: true,
          },
        },
        executions: {
          orderBy: { createdAt: 'desc' },
          take: 10,
        },
        campaigns: {
          include: {
            campaign: {
              select: {
                id: true,
                name: true,
                status: true,
              },
            },
          },
        },
      },
    });

    if (!agent) {
      return reply.status(404).send({
        success: false,
        error: 'Agent not found',
      });
    }

    return reply.send({
      success: true,
      data: agent,
    });
  });

  // Create agent
  fastify.post('/workspace/:workspaceId', async (request, reply) => {
    const { workspaceId } = request.params as { workspaceId: string };
    const data = createAgentSchema.parse(request.body);
    const userId = request.user!.userId;

    // Check workspace access
    const hasAccess = await prisma.workspace.findFirst({
      where: {
        id: workspaceId,
        OR: [
          { ownerId: userId },
          { members: { some: { userId } } },
        ],
      },
    });

    if (!hasAccess) {
      return reply.status(403).send({
        success: false,
        error: 'Access denied to this workspace',
      });
    }

    // Create agent in database
    const agent = await prisma.agent.create({
      data: {
        ...data,
        workspaceId,
        createdById: userId,
        status: 'DRAFT',
      },
      include: {
        createdBy: {
          select: {
            id: true,
            firstName: true,
            lastName: true,
            email: true,
            avatar: true,
          },
        },
      },
    });

    // Register with OpenClaw
    const openclawResult = await openClawService.createAgent({
      id: agent.id,
      name: agent.name,
      type: agent.type,
      systemPrompt: agent.systemPrompt || undefined,
      model: agent.model,
      temperature: agent.temperature,
      maxTokens: agent.maxTokens,
      configuration: agent.configuration as Record<string, unknown> | undefined,
    });

    if (openclawResult.success && openclawResult.openclawAgentId) {
      await prisma.agent.update({
        where: { id: agent.id },
        data: { openclawAgentId: openclawResult.openclawAgentId },
      });
    }

    logger.info({ agentId: agent.id, workspaceId }, 'Agent created');

    return reply.status(201).send({
      success: true,
      data: agent,
    });
  });

  // Update agent
  fastify.patch('/:agentId', async (request, reply) => {
    const { agentId } = request.params as { agentId: string };
    const data = updateAgentSchema.parse(request.body);
    const userId = request.user!.userId;

    const agent = await prisma.agent.findFirst({
      where: {
        id: agentId,
        deletedAt: null,
        workspace: {
          OR: [
            { ownerId: userId },
            { members: { some: { userId } } },
          ],
        },
      },
    });

    if (!agent) {
      return reply.status(404).send({
        success: false,
        error: 'Agent not found',
      });
    }

    const updated = await prisma.agent.update({
      where: { id: agentId },
      data: {
        ...data,
        updatedAt: new Date(),
      },
      include: {
        createdBy: {
          select: {
            id: true,
            firstName: true,
            lastName: true,
            email: true,
            avatar: true,
          },
        },
      },
    });

    // Update OpenClaw
    await openClawService.updateAgent({
      id: agentId,
      name: data.name || undefined,
      systemPrompt: data.systemPrompt || undefined,
      model: data.model || undefined,
      temperature: data.temperature,
      maxTokens: data.maxTokens,
      configuration: data.configuration,
    });

    return reply.send({
      success: true,
      data: updated,
    });
  });

  // Delete agent
  fastify.delete('/:agentId', async (request, reply) => {
    const { agentId } = request.params as { agentId: string };
    const userId = request.user!.userId;

    const agent = await prisma.agent.findFirst({
      where: {
        id: agentId,
        deletedAt: null,
        workspace: {
          OR: [
            { ownerId: userId },
            { members: { some: { userId, role: { in: ['ADMIN', 'OWNER'] } } } },
          ],
        },
      },
    });

    if (!agent) {
      return reply.status(404).send({
        success: false,
        error: 'Agent not found or access denied',
      });
    }

    // Soft delete
    await prisma.agent.update({
      where: { id: agentId },
      data: { deletedAt: new Date() },
    });

    // Delete from OpenClaw
    await openClawService.deleteAgent(agentId);

    logger.info({ agentId }, 'Agent deleted');

    return reply.send({
      success: true,
      message: 'Agent deleted successfully',
    });
  });

  // Activate agent
  fastify.post('/:agentId/activate', async (request, reply) => {
    const { agentId } = request.params as { agentId: string };
    const userId = request.user!.userId;

    const agent = await prisma.agent.findFirst({
      where: {
        id: agentId,
        deletedAt: null,
        workspace: {
          OR: [
            { ownerId: userId },
            { members: { some: { userId } } },
          ],
        },
      },
    });

    if (!agent) {
      return reply.status(404).send({
        success: false,
        error: 'Agent not found',
      });
    }

    const updated = await prisma.agent.update({
      where: { id: agentId },
      data: { status: 'ACTIVE' },
    });

    return reply.send({
      success: true,
      data: updated,
    });
  });

  // Pause agent
  fastify.post('/:agentId/pause', async (request, reply) => {
    const { agentId } = request.params as { agentId: string };
    const userId = request.user!.userId;

    const agent = await prisma.agent.findFirst({
      where: {
        id: agentId,
        deletedAt: null,
        workspace: {
          OR: [
            { ownerId: userId },
            { members: { some: { userId } } },
          ],
        },
      },
    });

    if (!agent) {
      return reply.status(404).send({
        success: false,
        error: 'Agent not found',
      });
    }

    const updated = await prisma.agent.update({
      where: { id: agentId },
      data: { status: 'PAUSED' },
    });

    return reply.send({
      success: true,
      data: updated,
    });
  });

  // Execute task
  fastify.post('/:agentId/execute', async (request, reply) => {
    const { agentId } = request.params as { agentId: string };
    const { taskType, input } = executeTaskSchema.parse(request.body);
    const userId = request.user!.userId;

    const agent = await prisma.agent.findFirst({
      where: {
        id: agentId,
        deletedAt: null,
        workspace: {
          OR: [
            { ownerId: userId },
            { members: { some: { userId } } },
          ],
        },
      },
    });

    if (!agent) {
      return reply.status(404).send({
        success: false,
        error: 'Agent not found',
      });
    }

    if (agent.status !== 'ACTIVE') {
      return reply.status(400).send({
        success: false,
        error: 'Agent is not active',
      });
    }

    // Check quota
    const quotaCheck = await openClawService.checkAgentQuota(agentId);
    if (!quotaCheck.canExecute) {
      return reply.status(429).send({
        success: false,
        error: quotaCheck.reason,
      });
    }

    // Execute task
    const result = await openClawService.executeTask(agentId, taskType, input);

    return reply.send({
      success: result.success,
      data: result,
    });
  });

  // Get agent executions
  fastify.get('/:agentId/executions', async (request, reply) => {
    const { agentId } = request.params as { agentId: string };
    const query = querySchema.parse(request.query);
    const userId = request.user!.userId;

    const agent = await prisma.agent.findFirst({
      where: {
        id: agentId,
        deletedAt: null,
        workspace: {
          OR: [
            { ownerId: userId },
            { members: { some: { userId } } },
          ],
        },
      },
    });

    if (!agent) {
      return reply.status(404).send({
        success: false,
        error: 'Agent not found',
      });
    }

    const page = parseInt(query.page, 10);
    const limit = parseInt(query.limit, 10);
    const skip = (page - 1) * limit;

    const [executions, total] = await Promise.all([
      prisma.agentExecution.findMany({
        where: { agentId },
        orderBy: { createdAt: 'desc' },
        skip,
        take: limit,
      }),
      prisma.agentExecution.count({ where: { agentId } }),
    ]);

    return reply.send({
      success: true,
      data: {
        executions,
        pagination: {
          page,
          limit,
          total,
          totalPages: Math.ceil(total / limit),
        },
      },
    });
  });

  // Get execution status
  fastify.get('/executions/:executionId', async (request, reply) => {
    const { executionId } = request.params as { executionId: string };
    const userId = request.user!.userId;

    const execution = await prisma.agentExecution.findFirst({
      where: {
        id: executionId,
        agent: {
          workspace: {
            OR: [
              { ownerId: userId },
              { members: { some: { userId } } },
            ],
          },
        },
      },
    });

    if (!execution) {
      return reply.status(404).send({
        success: false,
        error: 'Execution not found',
      });
    }

    return reply.send({
      success: true,
      data: execution,
    });
  });

  // Retry failed execution
  fastify.post('/executions/:executionId/retry', async (request, reply) => {
    const { executionId } = request.params as { executionId: string };
    const userId = request.user!.userId;

    const execution = await prisma.agentExecution.findFirst({
      where: {
        id: executionId,
        agent: {
          workspace: {
            OR: [
              { ownerId: userId },
              { members: { some: { userId } } },
            ],
          },
        },
      },
    });

    if (!execution) {
      return reply.status(404).send({
        success: false,
        error: 'Execution not found',
      });
    }

    const result = await openClawService.retryOnFailure(executionId);

    return reply.send({
      success: result.success,
      data: result,
    });
  });

  // Get agent stats
  fastify.get('/workspace/:workspaceId/stats', async (request, reply) => {
    const { workspaceId } = request.params as { workspaceId: string };
    const userId = request.user!.userId;

    const hasAccess = await prisma.workspace.findFirst({
      where: {
        id: workspaceId,
        OR: [
          { ownerId: userId },
          { members: { some: { userId } } },
        ],
      },
    });

    if (!hasAccess) {
      return reply.status(403).send({
        success: false,
        error: 'Access denied to this workspace',
      });
    }

    const [
      totalAgents,
      activeAgents,
      byType,
      totalExecutions,
      totalTokensUsed,
    ] = await Promise.all([
      prisma.agent.count({
        where: { workspaceId, deletedAt: null },
      }),
      prisma.agent.count({
        where: { workspaceId, deletedAt: null, status: 'ACTIVE' },
      }),
      prisma.agent.groupBy({
        by: ['type'],
        where: { workspaceId, deletedAt: null },
        _count: { type: true },
      }),
      prisma.agentExecution.count({
        where: { agent: { workspaceId } },
      }),
      prisma.agent.aggregate({
        where: { workspaceId, deletedAt: null },
        _sum: { tokenUsage: true },
      }),
    ]);

    return reply.send({
      success: true,
      data: {
        totalAgents,
        activeAgents,
        byType,
        totalExecutions,
        totalTokensUsed: totalTokensUsed._sum.tokenUsage || 0,
      },
    });
  });
}
