import { FastifyInstance, FastifyPluginOptions } from 'fastify';
import jwt from 'jsonwebtoken';
import { z } from 'zod';
import { prisma } from '../prisma/client';
import { config } from '../config';
import { hashPassword, comparePassword } from '../utils/encryption';
import { loginSchema, registerSchema } from '../types';
import { logger } from '../utils/logger';

const refreshTokenSchema = z.object({
  refreshToken: z.string(),
});

const changePasswordSchema = z.object({
  currentPassword: z.string(),
  newPassword: z.string().min(8),
});

const forgotPasswordSchema = z.object({
  email: z.string().email(),
});

export default async function authRoutes(
  fastify: FastifyInstance,
  options: FastifyPluginOptions
): Promise<void> {
  // Register
  fastify.post('/register', async (request, reply) => {
    const data = registerSchema.parse(request.body);

    // Check if user exists
    const existingUser = await prisma.user.findUnique({
      where: { email: data.email },
    });

    if (existingUser) {
      return reply.status(409).send({
        success: false,
        error: 'User already exists with this email',
      });
    }

    // Hash password
    const hashedPassword = await hashPassword(data.password);

    // Create user
    const user = await prisma.user.create({
      data: {
        email: data.email,
        password: hashedPassword,
        firstName: data.firstName,
        lastName: data.lastName,
      },
      select: {
        id: true,
        email: true,
        firstName: true,
        lastName: true,
        role: true,
        status: true,
        createdAt: true,
      },
    });

    // Create default workspace
    const slug = `${data.firstName.toLowerCase()}-${data.lastName.toLowerCase()}-${Date.now()}`;
    await prisma.workspace.create({
      data: {
        name: `${data.firstName}'s Workspace`,
        slug,
        ownerId: user.id,
      },
    });

    // Create subscription
    await prisma.subscription.create({
      data: {
        userId: user.id,
        plan: 'FREE',
        status: 'ACTIVE',
      },
    });

    // Generate tokens
    const accessToken = jwt.sign(
      { userId: user.id, email: user.email, role: user.role },
      config.JWT_SECRET,
      { expiresIn: config.JWT_ACCESS_EXPIRATION }
    );

    const refreshToken = jwt.sign(
      { userId: user.id },
      config.JWT_REFRESH_SECRET,
      { expiresIn: config.JWT_REFRESH_EXPIRATION }
    );

    // Store refresh token
    await prisma.session.create({
      data: {
        userId: user.id,
        refreshToken,
        expiresAt: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000),
        userAgent: request.headers['user-agent'],
        ipAddress: request.ip,
      },
    });

    logger.info({ userId: user.id }, 'User registered successfully');

    return reply.status(201).send({
      success: true,
      data: {
        user,
        tokens: {
          accessToken,
          refreshToken,
          expiresIn: 900, // 15 minutes
        },
      },
    });
  });

  // Login
  fastify.post('/login', async (request, reply) => {
    const data = loginSchema.parse(request.body);

    // Find user
    const user = await prisma.user.findUnique({
      where: { email: data.email },
    });

    if (!user) {
      return reply.status(401).send({
        success: false,
        error: 'Invalid credentials',
      });
    }

    // Check password
    const isValidPassword = await comparePassword(data.password, user.password);

    if (!isValidPassword) {
      return reply.status(401).send({
        success: false,
        error: 'Invalid credentials',
      });
    }

    // Check if user is active
    if (user.status !== 'ACTIVE') {
      return reply.status(401).send({
        success: false,
        error: 'Account is not active',
      });
    }

    // Update last login
    await prisma.user.update({
      where: { id: user.id },
      data: { lastLoginAt: new Date() },
    });

    // Generate tokens
    const accessToken = jwt.sign(
      { userId: user.id, email: user.email, role: user.role },
      config.JWT_SECRET,
      { expiresIn: config.JWT_ACCESS_EXPIRATION }
    );

    const refreshToken = jwt.sign(
      { userId: user.id },
      config.JWT_REFRESH_SECRET,
      { expiresIn: config.JWT_REFRESH_EXPIRATION }
    );

    // Store refresh token
    await prisma.session.create({
      data: {
        userId: user.id,
        refreshToken,
        expiresAt: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000),
        userAgent: request.headers['user-agent'],
        ipAddress: request.ip,
      },
    });

    logger.info({ userId: user.id }, 'User logged in successfully');

    return reply.send({
      success: true,
      data: {
        user: {
          id: user.id,
          email: user.email,
          firstName: user.firstName,
          lastName: user.lastName,
          avatar: user.avatar,
          role: user.role,
          status: user.status,
        },
        tokens: {
          accessToken,
          refreshToken,
          expiresIn: 900, // 15 minutes
        },
      },
    });
  });

  // Refresh token
  fastify.post('/refresh', async (request, reply) => {
    const { refreshToken } = refreshTokenSchema.parse(request.body);

    // Find session
    const session = await prisma.session.findUnique({
      where: { refreshToken },
      include: { user: true },
    });

    if (!session || session.expiresAt < new Date()) {
      return reply.status(401).send({
        success: false,
        error: 'Invalid or expired refresh token',
      });
    }

    // Generate new access token
    const accessToken = jwt.sign(
      { userId: session.user.id, email: session.user.email, role: session.user.role },
      config.JWT_SECRET,
      { expiresIn: config.JWT_ACCESS_EXPIRATION }
    );

    // Generate new refresh token
    const newRefreshToken = jwt.sign(
      { userId: session.user.id },
      config.JWT_REFRESH_SECRET,
      { expiresIn: config.JWT_REFRESH_EXPIRATION }
    );

    // Update session
    await prisma.session.update({
      where: { id: session.id },
      data: {
        refreshToken: newRefreshToken,
        expiresAt: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000),
      },
    });

    return reply.send({
      success: true,
      data: {
        tokens: {
          accessToken,
          refreshToken: newRefreshToken,
          expiresIn: 900,
        },
      },
    });
  });

  // Logout
  fastify.post('/logout', async (request, reply) => {
    const authHeader = request.headers.authorization;
    
    if (authHeader?.startsWith('Bearer ')) {
      const token = authHeader.substring(7);
      
      // Delete session
      await prisma.session.deleteMany({
        where: { refreshToken: token },
      });
    }

    return reply.send({
      success: true,
      message: 'Logged out successfully',
    });
  });

  // Get current user
  fastify.get('/me', async (request, reply) => {
    const authHeader = request.headers.authorization;
    
    if (!authHeader?.startsWith('Bearer ')) {
      return reply.status(401).send({
        success: false,
        error: 'Unauthorized',
      });
    }

    const token = authHeader.substring(7);
    
    try {
      const decoded = jwt.verify(token, config.JWT_SECRET) as { userId: string };
      
      const user = await prisma.user.findUnique({
        where: { id: decoded.userId },
        select: {
          id: true,
          email: true,
          firstName: true,
          lastName: true,
          avatar: true,
          role: true,
          status: true,
          lastLoginAt: true,
          createdAt: true,
        },
      });

      if (!user) {
        return reply.status(404).send({
          success: false,
          error: 'User not found',
        });
      }

      // Get user's workspaces
      const workspaces = await prisma.workspace.findMany({
        where: {
          OR: [
            { ownerId: user.id },
            { members: { some: { userId: user.id } } },
          ],
        },
        select: {
          id: true,
          name: true,
          slug: true,
          logo: true,
          plan: true,
          ownerId: true,
        },
      });

      // Get subscription
      const subscription = await prisma.subscription.findFirst({
        where: { userId: user.id },
        select: {
          plan: true,
          status: true,
          currentPeriodEnd: true,
        },
      });

      return reply.send({
        success: true,
        data: {
          user,
          workspaces,
          subscription,
        },
      });
    } catch (error) {
      return reply.status(401).send({
        success: false,
        error: 'Invalid token',
      });
    }
  });

  // Change password
  fastify.post('/change-password', async (request, reply) => {
    const authHeader = request.headers.authorization;
    
    if (!authHeader?.startsWith('Bearer ')) {
      return reply.status(401).send({
        success: false,
        error: 'Unauthorized',
      });
    }

    const token = authHeader.substring(7);
    const { currentPassword, newPassword } = changePasswordSchema.parse(request.body);

    try {
      const decoded = jwt.verify(token, config.JWT_SECRET) as { userId: string };
      
      const user = await prisma.user.findUnique({
        where: { id: decoded.userId },
      });

      if (!user) {
        return reply.status(404).send({
          success: false,
          error: 'User not found',
        });
      }

      // Verify current password
      const isValid = await comparePassword(currentPassword, user.password);
      
      if (!isValid) {
        return reply.status(400).send({
          success: false,
          error: 'Current password is incorrect',
        });
      }

      // Hash new password
      const hashedPassword = await hashPassword(newPassword);

      // Update password
      await prisma.user.update({
        where: { id: user.id },
        data: { password: hashedPassword },
      });

      // Delete all sessions
      await prisma.session.deleteMany({
        where: { userId: user.id },
      });

      return reply.send({
        success: true,
        message: 'Password changed successfully. Please log in again.',
      });
    } catch (error) {
      return reply.status(401).send({
        success: false,
        error: 'Invalid token',
      });
    }
  });

  // Forgot password
  fastify.post('/forgot-password', async (request, reply) => {
    const { email } = forgotPasswordSchema.parse(request.body);

    // Find user
    const user = await prisma.user.findUnique({
      where: { email },
    });

    if (!user) {
      // Don't reveal if user exists
      return reply.send({
        success: true,
        message: 'If an account exists, a reset email will be sent.',
      });
    }

    // TODO: Send reset email
    // For now, just return success

    return reply.send({
      success: true,
      message: 'If an account exists, a reset email will be sent.',
    });
  });
}
