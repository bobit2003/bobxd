import { FastifyInstance, FastifyPluginOptions } from 'fastify';
import { z } from 'zod';
import { prisma } from '../prisma/client';
import { authenticate } from '../middleware/auth';
import { createLeadSchema, updateLeadSchema, LeadStatus, LeadPriority } from '../types';
import { logger } from '../utils/logger';

const querySchema = z.object({
  page: z.string().optional().default('1'),
  limit: z.string().optional().default('20'),
  search: z.string().optional(),
  status: z.string().optional(),
  priority: z.string().optional(),
  source: z.string().optional(),
  assignedToId: z.string().optional(),
  tags: z.string().optional(),
  sortBy: z.string().optional().default('createdAt'),
  sortOrder: z.enum(['asc', 'desc']).optional().default('desc'),
});

const createActivitySchema = z.object({
  type: z.enum(['NOTE', 'EMAIL', 'CALL', 'MEETING', 'TASK', 'STATUS_CHANGE', 'ASSIGNMENT']),
  description: z.string(),
  metadata: z.record(z.any()).optional(),
});

const bulkUpdateSchema = z.object({
  leadIds: z.array(z.string()),
  data: updateLeadSchema,
});

const importLeadsSchema = z.array(createLeadSchema);

export default async function leadRoutes(
  fastify: FastifyInstance,
  options: FastifyPluginOptions
): Promise<void> {
  // Apply authentication to all routes
  fastify.addHook('preHandler', authenticate);

  // Get leads for workspace
  fastify.get('/workspace/:workspaceId', async (request, reply) => {
    const { workspaceId } = request.params as { workspaceId: string };
    const query = querySchema.parse(request.query);
    const userId = request.user!.userId;

    // Check workspace access
    const hasAccess = await prisma.workspace.findFirst({
      where: {
        id: workspaceId,
        OR: [
          { ownerId: userId },
          { members: { some: { userId } } },
        ],
      },
    });

    if (!hasAccess) {
      return reply.status(403).send({
        success: false,
        error: 'Access denied to this workspace',
      });
    }

    const page = parseInt(query.page, 10);
    const limit = parseInt(query.limit, 10);
    const skip = (page - 1) * limit;

    // Build where clause
    const where: any = {
      workspaceId,
      deletedAt: null,
    };

    if (query.search) {
      where.OR = [
        { firstName: { contains: query.search, mode: 'insensitive' } },
        { lastName: { contains: query.search, mode: 'insensitive' } },
        { email: { contains: query.search, mode: 'insensitive' } },
        { company: { contains: query.search, mode: 'insensitive' } },
      ];
    }

    if (query.status) {
      where.status = query.status;
    }

    if (query.priority) {
      where.priority = query.priority;
    }

    if (query.source) {
      where.source = query.source;
    }

    if (query.assignedToId) {
      where.assignedToId = query.assignedToId;
    }

    if (query.tags) {
      where.tags = { hasSome: query.tags.split(',') };
    }

    const [leads, total] = await Promise.all([
      prisma.lead.findMany({
        where,
        include: {
          assignedTo: {
            select: {
              id: true,
              firstName: true,
              lastName: true,
              email: true,
              avatar: true,
            },
          },
          createdBy: {
            select: {
              id: true,
              firstName: true,
              lastName: true,
            },
          },
          _count: {
            select: {
              activities: true,
              campaignLeads: true,
            },
          },
        },
        orderBy: { [query.sortBy]: query.sortOrder },
        skip,
        take: limit,
      }),
      prisma.lead.count({ where }),
    ]);

    return reply.send({
      success: true,
      data: {
        leads,
        pagination: {
          page,
          limit,
          total,
          totalPages: Math.ceil(total / limit),
        },
      },
    });
  });

  // Get lead by ID
  fastify.get('/:leadId', async (request, reply) => {
    const { leadId } = request.params as { leadId: string };
    const userId = request.user!.userId;

    const lead = await prisma.lead.findFirst({
      where: {
        id: leadId,
        deletedAt: null,
        workspace: {
          OR: [
            { ownerId: userId },
            { members: { some: { userId } } },
          ],
        },
      },
      include: {
        assignedTo: {
          select: {
            id: true,
            firstName: true,
            lastName: true,
            email: true,
            avatar: true,
          },
        },
        createdBy: {
          select: {
            id: true,
            firstName: true,
            lastName: true,
          },
        },
        activities: {
          include: {
            createdBy: {
              select: {
                id: true,
                firstName: true,
                lastName: true,
              },
            },
          },
          orderBy: { createdAt: 'desc' },
        },
        campaignLeads: {
          include: {
            campaign: {
              select: {
                id: true,
                name: true,
                status: true,
              },
            },
          },
        },
      },
    });

    if (!lead) {
      return reply.status(404).send({
        success: false,
        error: 'Lead not found',
      });
    }

    return reply.send({
      success: true,
      data: lead,
    });
  });

  // Create lead
  fastify.post('/workspace/:workspaceId', async (request, reply) => {
    const { workspaceId } = request.params as { workspaceId: string };
    const data = createLeadSchema.parse(request.body);
    const userId = request.user!.userId;

    // Check workspace access
    const hasAccess = await prisma.workspace.findFirst({
      where: {
        id: workspaceId,
        OR: [
          { ownerId: userId },
          { members: { some: { userId } } },
        ],
      },
    });

    if (!hasAccess) {
      return reply.status(403).send({
        success: false,
        error: 'Access denied to this workspace',
      });
    }

    // Check if email already exists in workspace
    const existingLead = await prisma.lead.findFirst({
      where: {
        workspaceId,
        email: data.email,
        deletedAt: null,
      },
    });

    if (existingLead) {
      return reply.status(409).send({
        success: false,
        error: 'Lead with this email already exists in this workspace',
      });
    }

    const lead = await prisma.lead.create({
      data: {
        ...data,
        workspaceId,
        createdById: userId,
      },
      include: {
        assignedTo: {
          select: {
            id: true,
            firstName: true,
            lastName: true,
            email: true,
            avatar: true,
          },
        },
        createdBy: {
          select: {
            id: true,
            firstName: true,
            lastName: true,
          },
        },
      },
    });

    // Create activity
    await prisma.leadActivity.create({
      data: {
        leadId: lead.id,
        type: 'NOTE',
        description: 'Lead created',
        createdById: userId,
      },
    });

    logger.info({ leadId: lead.id, workspaceId }, 'Lead created');

    return reply.status(201).send({
      success: true,
      data: lead,
    });
  });

  // Update lead
  fastify.patch('/:leadId', async (request, reply) => {
    const { leadId } = request.params as { leadId: string };
    const data = updateLeadSchema.parse(request.body);
    const userId = request.user!.userId;

    const lead = await prisma.lead.findFirst({
      where: {
        id: leadId,
        deletedAt: null,
        workspace: {
          OR: [
            { ownerId: userId },
            { members: { some: { userId } } },
          ],
        },
      },
    });

    if (!lead) {
      return reply.status(404).send({
        success: false,
        error: 'Lead not found',
      });
    }

    // Track changes for activity
    const changes: string[] = [];
    if (data.status && data.status !== lead.status) {
      changes.push(`Status changed from ${lead.status} to ${data.status}`);
    }
    if (data.assignedToId && data.assignedToId !== lead.assignedToId) {
      changes.push('Lead reassigned');
    }

    const updated = await prisma.lead.update({
      where: { id: leadId },
      data: {
        ...data,
        updatedAt: new Date(),
      },
      include: {
        assignedTo: {
          select: {
            id: true,
            firstName: true,
            lastName: true,
            email: true,
            avatar: true,
          },
        },
        createdBy: {
          select: {
            id: true,
            firstName: true,
            lastName: true,
          },
        },
      },
    });

    // Create activity for changes
    if (changes.length > 0) {
      await prisma.leadActivity.create({
        data: {
          leadId,
          type: 'STATUS_CHANGE',
          description: changes.join(', '),
          createdById: userId,
        },
      });
    }

    return reply.send({
      success: true,
      data: updated,
    });
  });

  // Delete lead
  fastify.delete('/:leadId', async (request, reply) => {
    const { leadId } = request.params as { leadId: string };
    const userId = request.user!.userId;

    const lead = await prisma.lead.findFirst({
      where: {
        id: leadId,
        deletedAt: null,
        workspace: {
          OR: [
            { ownerId: userId },
            { members: { some: { userId, role: { in: ['ADMIN', 'OWNER'] } } } },
          ],
        },
      },
    });

    if (!lead) {
      return reply.status(404).send({
        success: false,
        error: 'Lead not found or access denied',
      });
    }

    // Soft delete
    await prisma.lead.update({
      where: { id: leadId },
      data: { deletedAt: new Date() },
    });

    logger.info({ leadId }, 'Lead deleted');

    return reply.send({
      success: true,
      message: 'Lead deleted successfully',
    });
  });

  // Add activity to lead
  fastify.post('/:leadId/activities', async (request, reply) => {
    const { leadId } = request.params as { leadId: string };
    const data = createActivitySchema.parse(request.body);
    const userId = request.user!.userId;

    const lead = await prisma.lead.findFirst({
      where: {
        id: leadId,
        deletedAt: null,
        workspace: {
          OR: [
            { ownerId: userId },
            { members: { some: { userId } } },
          ],
        },
      },
    });

    if (!lead) {
      return reply.status(404).send({
        success: false,
        error: 'Lead not found',
      });
    }

    const activity = await prisma.leadActivity.create({
      data: {
        leadId,
        type: data.type,
        description: data.description,
        metadata: data.metadata,
        createdById: userId,
      },
      include: {
        createdBy: {
          select: {
            id: true,
            firstName: true,
            lastName: true,
          },
        },
      },
    });

    return reply.status(201).send({
      success: true,
      data: activity,
    });
  });

  // Bulk update leads
  fastify.post('/bulk-update', async (request, reply) => {
    const data = bulkUpdateSchema.parse(request.body);
    const userId = request.user!.userId;

    // Verify access to all leads
    const leads = await prisma.lead.findMany({
      where: {
        id: { in: data.leadIds },
        deletedAt: null,
        workspace: {
          OR: [
            { ownerId: userId },
            { members: { some: { userId } } },
          ],
        },
      },
    });

    if (leads.length !== data.leadIds.length) {
      return reply.status(403).send({
        success: false,
        error: 'Access denied to some leads',
      });
    }

    const updated = await prisma.lead.updateMany({
      where: {
        id: { in: data.leadIds },
      },
      data: {
        ...data.data,
        updatedAt: new Date(),
      },
    });

    return reply.send({
      success: true,
      data: {
        updatedCount: updated.count,
      },
    });
  });

  // Import leads
  fastify.post('/workspace/:workspaceId/import', async (request, reply) => {
    const { workspaceId } = request.params as { workspaceId: string };
    const leads = importLeadsSchema.parse(request.body);
    const userId = request.user!.userId;

    // Check workspace access
    const hasAccess = await prisma.workspace.findFirst({
      where: {
        id: workspaceId,
        OR: [
          { ownerId: userId },
          { members: { some: { userId } } },
        ],
      },
    });

    if (!hasAccess) {
      return reply.status(403).send({
        success: false,
        error: 'Access denied to this workspace',
      });
    }

    const results = {
      created: 0,
      skipped: 0,
      errors: [] as string[],
    };

    for (const leadData of leads) {
      try {
        // Check if email already exists
        const existing = await prisma.lead.findFirst({
          where: {
            workspaceId,
            email: leadData.email,
            deletedAt: null,
          },
        });

        if (existing) {
          results.skipped++;
          continue;
        }

        await prisma.lead.create({
          data: {
            ...leadData,
            workspaceId,
            createdById: userId,
            source: 'IMPORT',
          },
        });

        results.created++;
      } catch (error) {
        results.errors.push(`Failed to import ${leadData.email}: ${error instanceof Error ? error.message : 'Unknown error'}`);
      }
    }

    logger.info({ workspaceId, results }, 'Leads imported');

    return reply.send({
      success: true,
      data: results,
    });
  });

  // Get lead stats
  fastify.get('/workspace/:workspaceId/stats', async (request, reply) => {
    const { workspaceId } = request.params as { workspaceId: string };
    const userId = request.user!.userId;

    const hasAccess = await prisma.workspace.findFirst({
      where: {
        id: workspaceId,
        OR: [
          { ownerId: userId },
          { members: { some: { userId } } },
        ],
      },
    });

    if (!hasAccess) {
      return reply.status(403).send({
        success: false,
        error: 'Access denied to this workspace',
      });
    }

    const [
      totalLeads,
      byStatus,
      byPriority,
      bySource,
      recentLeads,
    ] = await Promise.all([
      prisma.lead.count({
        where: { workspaceId, deletedAt: null },
      }),
      prisma.lead.groupBy({
        by: ['status'],
        where: { workspaceId, deletedAt: null },
        _count: { status: true },
      }),
      prisma.lead.groupBy({
        by: ['priority'],
        where: { workspaceId, deletedAt: null },
        _count: { priority: true },
      }),
      prisma.lead.groupBy({
        by: ['source'],
        where: { workspaceId, deletedAt: null },
        _count: { source: true },
      }),
      prisma.lead.count({
        where: {
          workspaceId,
          deletedAt: null,
          createdAt: { gte: new Date(Date.now() - 30 * 24 * 60 * 60 * 1000) },
        },
      }),
    ]);

    return reply.send({
      success: true,
      data: {
        totalLeads,
        byStatus,
        byPriority,
        bySource,
        recentLeads,
      },
    });
  });
}
