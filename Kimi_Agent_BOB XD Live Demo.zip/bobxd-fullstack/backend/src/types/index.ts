import { z } from 'zod';

// User Types
export const UserRole = z.enum(['USER', 'ADMIN', 'SUPER_ADMIN']);
export const UserStatus = z.enum(['ACTIVE', 'INACTIVE', 'SUSPENDED', 'PENDING_VERIFICATION']);

// Workspace Types
export const WorkspacePlan = z.enum(['FREE', 'STARTER', 'PROFESSIONAL', 'ENTERPRISE']);
export const WorkspaceStatus = z.enum(['ACTIVE', 'INACTIVE', 'SUSPENDED']);
export const WorkspaceRole = z.enum(['OWNER', 'ADMIN', 'MEMBER', 'VIEWER']);

// Lead Types
export const LeadSource = z.enum(['MANUAL', 'IMPORT', 'API', 'WEBSITE', 'CAMPAIGN', 'INTEGRATION', 'REFERRAL']);
export const LeadStatus = z.enum(['NEW', 'CONTACTED', 'QUALIFIED', 'PROPOSAL', 'NEGOTIATION', 'WON', 'LOST', 'ARCHIVED']);
export const LeadPriority = z.enum(['LOW', 'MEDIUM', 'HIGH', 'URGENT']);
export const ActivityType = z.enum(['NOTE', 'EMAIL', 'CALL', 'MEETING', 'TASK', 'STATUS_CHANGE', 'ASSIGNMENT', 'CAMPAIGN_ENROLLMENT']);

// Agent Types
export const AgentType = z.enum(['LEAD_QUALIFIER', 'EMAIL_SENDER', 'APPOINTMENT_SCHEDULER', 'DATA_ENRICHER', 'FOLLOW_UP', 'CUSTOM']);
export const AgentStatus = z.enum(['DRAFT', 'ACTIVE', 'PAUSED', 'ERROR', 'ARCHIVED']);
export const ExecutionStatus = z.enum(['PENDING', 'RUNNING', 'COMPLETED', 'FAILED', 'CANCELLED', 'RETRYING']);

// Campaign Types
export const CampaignType = z.enum(['EMAIL_SEQUENCE', 'LEAD_QUALIFICATION', 'APPOINTMENT_SETTING', 'DATA_ENRICHMENT', 'FOLLOW_UP', 'CUSTOM']);
export const CampaignStatus = z.enum(['DRAFT', 'SCHEDULED', 'RUNNING', 'PAUSED', 'COMPLETED', 'CANCELLED']);
export const CampaignLeadStatus = z.enum(['PENDING', 'IN_PROGRESS', 'COMPLETED', 'FAILED', 'SKIPPED']);

// Subscription Types
export const SubscriptionPlan = z.enum(['FREE', 'STARTER', 'PROFESSIONAL', 'ENTERPRISE']);
export const SubscriptionStatus = z.enum(['ACTIVE', 'CANCELLED', 'PAST_DUE', 'UNPAID', 'TRIALING']);
export const InvoiceStatus = z.enum(['PENDING', 'PAID', 'OVERDUE', 'CANCELLED', 'REFUNDED']);
export const PaymentStatus = z.enum(['PENDING', 'COMPLETED', 'FAILED', 'REFUNDED', 'CANCELLED']);

// Integration Types
export const IntegrationType = z.enum(['SALESFORCE', 'HUBSPOT', 'ZAPIER', 'SLACK', 'MAKE', 'CUSTOM']);

// Notification Types
export const NotificationType = z.enum(['INFO', 'SUCCESS', 'WARNING', 'ERROR', 'CAMPAIGN_COMPLETE', 'LEAD_ASSIGNED', 'PAYMENT_RECEIVED', 'SYSTEM']);

// Schemas
export const loginSchema = z.object({
  email: z.string().email(),
  password: z.string().min(6),
});

export const registerSchema = z.object({
  email: z.string().email(),
  password: z.string().min(8),
  firstName: z.string().min(1),
  lastName: z.string().min(1),
});

export const createWorkspaceSchema = z.object({
  name: z.string().min(1),
  slug: z.string().min(3).regex(/^[a-z0-9-]+$/),
  description: z.string().optional(),
});

export const createLeadSchema = z.object({
  firstName: z.string().min(1),
  lastName: z.string().min(1),
  email: z.string().email(),
  phone: z.string().optional(),
  company: z.string().optional(),
  title: z.string().optional(),
  source: LeadSource.default('MANUAL'),
  priority: LeadPriority.default('MEDIUM'),
  tags: z.array(z.string()).default([]),
  notes: z.string().optional(),
  address: z.string().optional(),
  city: z.string().optional(),
  country: z.string().optional(),
  website: z.string().optional(),
  linkedin: z.string().optional(),
  twitter: z.string().optional(),
  assignedToId: z.string().optional(),
  customFields: z.record(z.any()).optional(),
});

export const updateLeadSchema = createLeadSchema.partial();

export const createAgentSchema = z.object({
  name: z.string().min(1),
  description: z.string().optional(),
  type: AgentType,
  configuration: z.record(z.any()).optional(),
  capabilities: z.array(z.string()).default([]),
  systemPrompt: z.string().optional(),
  model: z.string().default('gpt-4'),
  temperature: z.number().min(0).max(2).default(0.7),
  maxTokens: z.number().min(1).max(8000).default(2000),
  tokenLimit: z.number().default(100000),
  costLimit: z.number().optional(),
});

export const updateAgentSchema = createAgentSchema.partial();

export const createCampaignSchema = z.object({
  name: z.string().min(1),
  description: z.string().optional(),
  type: CampaignType,
  configuration: z.record(z.any()).optional(),
  schedule: z.record(z.any()).optional(),
  startDate: z.string().datetime().optional(),
  endDate: z.string().datetime().optional(),
  targetCount: z.number().optional(),
  agentIds: z.array(z.string()).optional(),
  leadIds: z.array(z.string()).optional(),
});

export const updateCampaignSchema = createCampaignSchema.partial();

export const createWebhookSchema = z.object({
  name: z.string().min(1),
  url: z.string().url(),
  events: z.array(z.string()).min(1),
  secret: z.string().optional(),
});

export const createIntegrationSchema = z.object({
  type: IntegrationType,
  name: z.string().min(1),
  configuration: z.record(z.any()),
});

// Type exports
export type LoginInput = z.infer<typeof loginSchema>;
export type RegisterInput = z.infer<typeof registerSchema>;
export type CreateWorkspaceInput = z.infer<typeof createWorkspaceSchema>;
export type CreateLeadInput = z.infer<typeof createLeadSchema>;
export type UpdateLeadInput = z.infer<typeof updateLeadSchema>;
export type CreateAgentInput = z.infer<typeof createAgentSchema>;
export type UpdateAgentInput = z.infer<typeof updateAgentSchema>;
export type CreateCampaignInput = z.infer<typeof createCampaignSchema>;
export type UpdateCampaignInput = z.infer<typeof updateCampaignSchema>;
export type CreateWebhookInput = z.infer<typeof createWebhookSchema>;
export type CreateIntegrationInput = z.infer<typeof createIntegrationSchema>;

// JWT Payload
export interface JWTPayload {
  userId: string;
  email: string;
  role: string;
}

// Request Context
export interface RequestContext {
  userId: string;
  email: string;
  role: string;
  workspaceId?: string;
  workspaceRole?: string;
}

// OpenClaw Types
export interface OpenClawTask {
  agentId: string;
  type: string;
  input: Record<string, unknown>;
  priority?: number;
}

export interface OpenClawResponse {
  success: boolean;
  executionId?: string;
  result?: Record<string, unknown>;
  error?: string;
}

// Pagination
export interface PaginationParams {
  page: number;
  limit: number;
  sortBy?: string;
  sortOrder?: 'asc' | 'desc';
}

export interface PaginatedResponse<T> {
  data: T[];
  pagination: {
    page: number;
    limit: number;
    total: number;
    totalPages: number;
  };
}

// Analytics Types
export interface TimeSeriesData {
  date: string;
  value: number;
}

export interface DashboardStats {
  totalLeads: number;
  newLeadsThisWeek: number;
  totalCampaigns: number;
  activeCampaigns: number;
  totalAgents: number;
  activeAgents: number;
  conversionRate: number;
  revenueThisMonth: number;
}

// WebSocket Events
export interface WebSocketEvent {
  type: string;
  payload: Record<string, unknown>;
}

export interface AgentExecutionEvent extends WebSocketEvent {
  type: 'agent.execution';
  payload: {
    executionId: string;
    agentId: string;
    status: string;
    progress: number;
    result?: Record<string, unknown>;
    error?: string;
  };
}

export interface CampaignUpdateEvent extends WebSocketEvent {
  type: 'campaign.update';
  payload: {
    campaignId: string;
    status: string;
    progress: number;
    completedCount: number;
    targetCount: number;
  };
}
