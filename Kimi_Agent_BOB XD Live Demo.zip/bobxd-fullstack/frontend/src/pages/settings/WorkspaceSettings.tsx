import { useState, useEffect } from 'react';
import { useForm } from 'react-hook-form';
import { useWorkspaceStore } from '../../stores/workspaceStore';
import { workspaceApi } from '../../utils/api';
import toast from 'react-hot-toast';

export default function WorkspaceSettings() {
  const { currentWorkspace, setCurrentWorkspace } = useWorkspaceStore();
  const [isLoading, setIsLoading] = useState(false);
  const [members, setMembers] = useState<any[]>([]);

  const {
    register,
    handleSubmit,
    setValue,
    formState: { errors },
  } = useForm();

  useEffect(() => {
    if (currentWorkspace) {
      setValue('name', currentWorkspace.name);
      setValue('description', currentWorkspace.description);
      loadMembers();
    }
  }, [currentWorkspace]);

  const loadMembers = async () => {
    if (!currentWorkspace) return;
    try {
      const response = await workspaceApi.getMembers(currentWorkspace.id);
      setMembers(response.data.data);
    } catch (error) {
      toast.error('Failed to load members');
    }
  };

  const onSubmit = async (data: any) => {
    if (!currentWorkspace) return;
    
    setIsLoading(true);
    try {
      const response = await workspaceApi.update(currentWorkspace.id, data);
      setCurrentWorkspace(response.data.data);
      toast.success('Workspace updated successfully');
    } catch (error) {
      toast.error('Failed to update workspace');
    } finally {
      setIsLoading(false);
    }
  };

  if (!currentWorkspace) {
    return (
      <div className="text-center py-12">
        <p className="text-dark-500">Please select a workspace</p>
      </div>
    );
  }

  return (
    <div className="max-w-2xl mx-auto space-y-6">
      <div>
        <h1 className="text-2xl font-bold">Workspace Settings</h1>
        <p className="text-dark-500">Manage your workspace</p>
      </div>

      <form onSubmit={handleSubmit(onSubmit)} className="space-y-6">
        <div className="glass-card p-6 space-y-6">
          <h3 className="text-lg font-semibold">General</h3>
          
          <div>
            <label className="block text-sm font-medium mb-2">Workspace Name</label>
            <input
              type="text"
              {...register('name', { required: 'Name is required' })}
              className="input-field"
            />
            {errors.name && (
              <p className="mt-1 text-sm text-red-400">{errors.name.message as string}</p>
            )}
          </div>

          <div>
            <label className="block text-sm font-medium mb-2">Description</label>
            <textarea
              {...register('description')}
              className="input-field"
              rows={3}
            />
          </div>

          <div>
            <label className="block text-sm font-medium mb-2">Slug</label>
            <input
              type="text"
              value={currentWorkspace.slug}
              className="input-field"
              disabled
            />
            <p className="text-sm text-dark-500 mt-1">Slug cannot be changed</p>
          </div>
        </div>

        <button
          type="submit"
          className="btn-primary w-full"
          disabled={isLoading}
        >
          {isLoading ? 'Saving...' : 'Save Changes'}
        </button>
      </form>

      {/* Members */}
      <div className="glass-card p-6">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-lg font-semibold">Team Members</h3>
          <button className="btn-secondary text-sm">
            + Invite Member
          </button>
        </div>
        
        {members.length > 0 ? (
          <div className="space-y-3">
            {members.map((member) => (
              <div key={member.id} className="flex items-center justify-between p-3 bg-dark-700/30 rounded-lg">
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 bg-primary-500/20 rounded-full flex items-center justify-center">
                    <span className="text-sm text-primary-400">
                      {member.user.firstName[0]}
                    </span>
                  </div>
                  <div>
                    <p className="font-medium">{member.user.firstName} {member.user.lastName}</p>
                    <p className="text-sm text-dark-500">{member.user.email}</p>
                  </div>
                </div>
                <span className="badge badge-purple">{member.role}</span>
              </div>
            ))}
          </div>
        ) : (
          <p className="text-dark-500 text-center py-4">No members yet</p>
        )}
      </div>
    </div>
  );
}
