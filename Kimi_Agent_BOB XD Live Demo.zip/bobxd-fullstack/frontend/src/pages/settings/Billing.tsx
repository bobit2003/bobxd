import { useState, useEffect } from 'react';
import { subscriptionApi } from '../../utils/api';
import { CheckIcon } from '@heroicons/react/24/outline';
import toast from 'react-hot-toast';

const plans = [
  {
    name: 'Free',
    price: 0,
    features: ['1 Workspace', '100 Leads', '2 AI Agents', '3 Campaigns', 'Community Support'],
  },
  {
    name: 'Starter',
    price: 29,
    features: ['3 Workspaces', '1,000 Leads', '5 AI Agents', '10 Campaigns', 'Email Support'],
  },
  {
    name: 'Professional',
    price: 99,
    features: ['10 Workspaces', '10,000 Leads', '20 AI Agents', '50 Campaigns', 'Priority Support'],
  },
  {
    name: 'Enterprise',
    price: 299,
    features: ['Unlimited Workspaces', 'Unlimited Leads', 'Unlimited Agents', 'Unlimited Campaigns', 'Dedicated Support'],
  },
];

export default function Billing() {
  const [subscription, setSubscription] = useState<any>(null);
  const [usage, setUsage] = useState<any>(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    loadBillingData();
  }, []);

  const loadBillingData = async () => {
    setIsLoading(true);
    try {
      const [subRes, usageRes] = await Promise.all([
        subscriptionApi.get(),
        subscriptionApi.getUsage(),
      ]);
      setSubscription(subRes.data.data);
      setUsage(usageRes.data.data);
    } catch (error) {
      toast.error('Failed to load billing data');
    } finally {
      setIsLoading(false);
    }
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-96">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary-500" />
      </div>
    );
  }

  const currentPlan = subscription?.subscription?.plan || 'FREE';

  return (
    <div className="space-y-8">
      <div>
        <h1 className="text-2xl font-bold">Billing</h1>
        <p className="text-dark-500">Manage your subscription and usage</p>
      </div>

      {/* Current Plan */}
      <div className="glass-card p-6">
        <div className="flex items-center justify-between mb-4">
          <div>
            <p className="text-dark-500">Current Plan</p>
            <h3 className="text-2xl font-bold">{currentPlan}</h3>
          </div>
          <span className="badge badge-success">{subscription?.subscription?.status || 'ACTIVE'}</span>
        </div>
        
        {usage && (
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mt-6">
            <div>
              <p className="text-sm text-dark-500">Workspaces</p>
              <div className="flex items-center gap-2">
                <div className="flex-1 bg-dark-700 rounded-full h-2">
                  <div 
                    className="bg-primary-500 h-2 rounded-full"
                    style={{ width: `${Math.min(usage.percentages.workspaces, 100)}%` }}
                  />
                </div>
                <span className="text-sm">{usage.usage.workspaces}/{usage.limits.workspaces === -1 ? '∞' : usage.limits.workspaces}</span>
              </div>
            </div>
            <div>
              <p className="text-sm text-dark-500">Leads</p>
              <div className="flex items-center gap-2">
                <div className="flex-1 bg-dark-700 rounded-full h-2">
                  <div 
                    className="bg-primary-500 h-2 rounded-full"
                    style={{ width: `${Math.min(usage.percentages.leads, 100)}%` }}
                  />
                </div>
                <span className="text-sm">{usage.usage.leads}/{usage.limits.leads === -1 ? '∞' : usage.limits.leads}</span>
              </div>
            </div>
            <div>
              <p className="text-sm text-dark-500">Agents</p>
              <div className="flex items-center gap-2">
                <div className="flex-1 bg-dark-700 rounded-full h-2">
                  <div 
                    className="bg-primary-500 h-2 rounded-full"
                    style={{ width: `${Math.min(usage.percentages.agents, 100)}%` }}
                  />
                </div>
                <span className="text-sm">{usage.usage.agents}/{usage.limits.agents === -1 ? '∞' : usage.limits.agents}</span>
              </div>
            </div>
            <div>
              <p className="text-sm text-dark-500">Campaigns</p>
              <div className="flex items-center gap-2">
                <div className="flex-1 bg-dark-700 rounded-full h-2">
                  <div 
                    className="bg-primary-500 h-2 rounded-full"
                    style={{ width: `${Math.min(usage.percentages.campaigns, 100)}%` }}
                  />
                </div>
                <span className="text-sm">{usage.usage.campaigns}/{usage.limits.campaigns === -1 ? '∞' : usage.limits.campaigns}</span>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Plans */}
      <div>
        <h3 className="text-lg font-semibold mb-4">Available Plans</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {plans.map((plan) => (
            <div 
              key={plan.name} 
              className={`glass-card p-6 ${plan.name === currentPlan ? 'border-primary-500/50' : ''}`}
            >
              <h4 className="font-semibold mb-2">{plan.name}</h4>
              <div className="mb-4">
                <span className="text-3xl font-bold">${plan.price}</span>
                <span className="text-dark-500">/month</span>
              </div>
              <ul className="space-y-2 mb-6">
                {plan.features.map((feature) => (
                  <li key={feature} className="flex items-center gap-2 text-sm">
                    <CheckIcon className="w-4 h-4 text-primary-400" />
                    {feature}
                  </li>
                ))}
              </ul>
              {plan.name === currentPlan ? (
                <button className="w-full btn-secondary" disabled>
                  Current Plan
                </button>
              ) : (
                <button className="w-full btn-primary">
                  Upgrade
                </button>
              )}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
