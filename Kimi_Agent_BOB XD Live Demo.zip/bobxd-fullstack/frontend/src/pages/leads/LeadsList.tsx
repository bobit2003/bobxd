import { useState, useEffect } from 'react';
import { useWorkspaceStore } from '../../stores/workspaceStore';
import { leadApi } from '../../utils/api';
import { 
  MagnifyingGlassIcon, 
  FunnelIcon, 
  PlusIcon,
  ChevronLeftIcon,
  ChevronRightIcon,
} from '@heroicons/react/24/outline';
import toast from 'react-hot-toast';

const statusColors: Record<string, string> = {
  NEW: 'badge-info',
  CONTACTED: 'badge-warning',
  QUALIFIED: 'badge-purple',
  PROPOSAL: 'badge-info',
  NEGOTIATION: 'badge-warning',
  WON: 'badge-success',
  LOST: 'badge-error',
  ARCHIVED: 'badge-error',
};

const priorityColors: Record<string, string> = {
  LOW: 'badge-info',
  MEDIUM: 'badge-warning',
  HIGH: 'badge-error',
  URGENT: 'badge-error',
};

export default function LeadsList() {
  const { currentWorkspace } = useWorkspaceStore();
  const [leads, setLeads] = useState<any[]>([]);
  const [pagination, setPagination] = useState<any>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState('');
  const [page, setPage] = useState(1);

  useEffect(() => {
    if (currentWorkspace) {
      loadLeads();
    }
  }, [currentWorkspace, page, statusFilter]);

  const loadLeads = async () => {
    if (!currentWorkspace) return;
    
    setIsLoading(true);
    try {
      const params: Record<string, string> = { page: page.toString(), limit: '20' };
      if (search) params.search = search;
      if (statusFilter) params.status = statusFilter;
      
      const response = await leadApi.list(currentWorkspace.id, params);
      setLeads(response.data.data.leads);
      setPagination(response.data.data.pagination);
    } catch (error) {
      toast.error('Failed to load leads');
    } finally {
      setIsLoading(false);
    }
  };

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    setPage(1);
    loadLeads();
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-96">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary-500" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold">Leads</h1>
          <p className="text-dark-500">Manage and track your leads</p>
        </div>
        <a href="/leads/create" className="btn-primary">
          <PlusIcon className="w-5 h-5" />
          Add Lead
        </a>
      </div>

      {/* Filters */}
      <div className="glass-card p-4">
        <div className="flex flex-col sm:flex-row gap-4">
          <form onSubmit={handleSearch} className="flex-1">
            <div className="relative">
              <MagnifyingGlassIcon className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-dark-500" />
              <input
                type="text"
                placeholder="Search leads..."
                className="input-field pl-10"
                value={search}
                onChange={(e) => setSearch(e.target.value)}
              />
            </div>
          </form>
          <div className="flex gap-3">
            <select
              className="input-field"
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value)}
            >
              <option value="">All Status</option>
              <option value="NEW">New</option>
              <option value="CONTACTED">Contacted</option>
              <option value="QUALIFIED">Qualified</option>
              <option value="PROPOSAL">Proposal</option>
              <option value="NEGOTIATION">Negotiation</option>
              <option value="WON">Won</option>
              <option value="LOST">Lost</option>
            </select>
            <button className="btn-secondary">
              <FunnelIcon className="w-5 h-5" />
              Filter
            </button>
          </div>
        </div>
      </div>

      {/* Leads Table */}
      <div className="table-container">
        <table className="data-table">
          <thead>
            <tr>
              <th>Name</th>
              <th>Email</th>
              <th>Company</th>
              <th>Status</th>
              <th>Priority</th>
              <th>Assigned To</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            {leads.map((lead) => (
              <tr key={lead.id}>
                <td>
                  <div className="font-medium">{lead.firstName} {lead.lastName}</div>
                </td>
                <td>{lead.email}</td>
                <td>{lead.company || '-'}</td>
                <td>
                  <span className={`badge ${statusColors[lead.status] || 'badge-info'}`}>
                    {lead.status}
                  </span>
                </td>
                <td>
                  <span className={`badge ${priorityColors[lead.priority] || 'badge-info'}`}>
                    {lead.priority}
                  </span>
                </td>
                <td>
                  {lead.assignedTo ? (
                    <div className="flex items-center gap-2">
                      <div className="w-6 h-6 bg-primary-500/20 rounded-full flex items-center justify-center">
                        <span className="text-xs text-primary-400">
                          {lead.assignedTo.firstName[0]}
                        </span>
                      </div>
                      <span className="text-sm">{lead.assignedTo.firstName}</span>
                    </div>
                  ) : (
                    <span className="text-dark-500">Unassigned</span>
                  )}
                </td>
                <td>
                  <a
                    href={`/leads/${lead.id}`}
                    className="text-primary-400 hover:text-primary-300"
                  >
                    View
                  </a>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* Pagination */}
      {pagination && (
        <div className="flex items-center justify-between">
          <p className="text-sm text-dark-500">
            Showing {((pagination.page - 1) * pagination.limit) + 1} to{' '}
            {Math.min(pagination.page * pagination.limit, pagination.total)} of{' '}
            {pagination.total} leads
          </p>
          <div className="flex items-center gap-2">
            <button
              className="p-2 rounded-lg hover:bg-dark-700 disabled:opacity-50"
              onClick={() => setPage(page - 1)}
              disabled={page === 1}
            >
              <ChevronLeftIcon className="w-5 h-5" />
            </button>
            <span className="text-sm">
              Page {pagination.page} of {pagination.totalPages}
            </span>
            <button
              className="p-2 rounded-lg hover:bg-dark-700 disabled:opacity-50"
              onClick={() => setPage(page + 1)}
              disabled={page === pagination.totalPages}
            >
              <ChevronRightIcon className="w-5 h-5" />
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
