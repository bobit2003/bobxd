import { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { leadApi } from '../../utils/api';
import { 
  ArrowLeftIcon, 
  PencilIcon, 
  TrashIcon,
  PlusIcon,
} from '@heroicons/react/24/outline';
import toast from 'react-hot-toast';

const statusColors: Record<string, string> = {
  NEW: 'badge-info',
  CONTACTED: 'badge-warning',
  QUALIFIED: 'badge-purple',
  PROPOSAL: 'badge-info',
  NEGOTIATION: 'badge-warning',
  WON: 'badge-success',
  LOST: 'badge-error',
  ARCHIVED: 'badge-error',
};

export default function LeadDetail() {
  const { leadId } = useParams<{ leadId: string }>();
  const navigate = useNavigate();
  const [lead, setLead] = useState<any>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [activeTab, setActiveTab] = useState('overview');

  useEffect(() => {
    if (leadId) {
      loadLead();
    }
  }, [leadId]);

  const loadLead = async () => {
    setIsLoading(true);
    try {
      const response = await leadApi.get(leadId!);
      setLead(response.data.data);
    } catch (error) {
      toast.error('Failed to load lead');
      navigate('/leads');
    } finally {
      setIsLoading(false);
    }
  };

  const handleDelete = async () => {
    if (!confirm('Are you sure you want to delete this lead?')) return;
    
    try {
      await leadApi.delete(leadId!);
      toast.success('Lead deleted successfully');
      navigate('/leads');
    } catch (error) {
      toast.error('Failed to delete lead');
    }
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-96">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary-500" />
      </div>
    );
  }

  if (!lead) return null;

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div className="flex items-center gap-4">
          <button
            onClick={() => navigate('/leads')}
            className="p-2 rounded-lg hover:bg-dark-700 transition-colors"
          >
            <ArrowLeftIcon className="w-5 h-5" />
          </button>
          <div>
            <h1 className="text-2xl font-bold">{lead.firstName} {lead.lastName}</h1>
            <p className="text-dark-500">{lead.email}</p>
          </div>
        </div>
        <div className="flex gap-3">
          <button className="btn-secondary">
            <PencilIcon className="w-5 h-5" />
            Edit
          </button>
          <button onClick={handleDelete} className="btn-outline text-red-400 border-red-400/30 hover:bg-red-400/10">
            <TrashIcon className="w-5 h-5" />
            Delete
          </button>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex gap-1 border-b border-dark-600">
        {['overview', 'activities', 'campaigns'].map((tab) => (
          <button
            key={tab}
            className={`px-4 py-2 font-medium capitalize transition-colors ${
              activeTab === tab
                ? 'text-primary-400 border-b-2 border-primary-400'
                : 'text-dark-500 hover:text-white'
            }`}
            onClick={() => setActiveTab(tab)}
          >
            {tab}
          </button>
        ))}
      </div>

      {/* Content */}
      {activeTab === 'overview' && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Main Info */}
          <div className="lg:col-span-2 space-y-6">
            <div className="glass-card p-6">
              <h3 className="text-lg font-semibold mb-4">Lead Information</h3>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <p className="text-sm text-dark-500">Status</p>
                  <span className={`badge ${statusColors[lead.status]}`}>
                    {lead.status}
                  </span>
                </div>
                <div>
                  <p className="text-sm text-dark-500">Priority</p>
                  <span className="badge badge-info">{lead.priority}</span>
                </div>
                <div>
                  <p className="text-sm text-dark-500">Source</p>
                  <p className="font-medium">{lead.source}</p>
                </div>
                <div>
                  <p className="text-sm text-dark-500">Company</p>
                  <p className="font-medium">{lead.company || '-'}</p>
                </div>
                <div>
                  <p className="text-sm text-dark-500">Title</p>
                  <p className="font-medium">{lead.title || '-'}</p>
                </div>
                <div>
                  <p className="text-sm text-dark-500">Phone</p>
                  <p className="font-medium">{lead.phone || '-'}</p>
                </div>
              </div>
            </div>

            {lead.notes && (
              <div className="glass-card p-6">
                <h3 className="text-lg font-semibold mb-4">Notes</h3>
                <p className="text-dark-500">{lead.notes}</p>
              </div>
            )}
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            <div className="glass-card p-6">
              <h3 className="text-lg font-semibold mb-4">Assignment</h3>
              {lead.assignedTo ? (
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 bg-primary-500/20 rounded-full flex items-center justify-center">
                    <span className="text-primary-400 font-medium">
                      {lead.assignedTo.firstName[0]}
                    </span>
                  </div>
                  <div>
                    <p className="font-medium">{lead.assignedTo.firstName} {lead.assignedTo.lastName}</p>
                    <p className="text-sm text-dark-500">{lead.assignedTo.email}</p>
                  </div>
                </div>
              ) : (
                <p className="text-dark-500">Not assigned</p>
              )}
            </div>

            <div className="glass-card p-6">
              <h3 className="text-lg font-semibold mb-4">Tags</h3>
              {lead.tags && lead.tags.length > 0 ? (
                <div className="flex flex-wrap gap-2">
                  {lead.tags.map((tag: string) => (
                    <span key={tag} className="badge badge-purple">
                      {tag}
                    </span>
                  ))}
                </div>
              ) : (
                <p className="text-dark-500">No tags</p>
              )}
            </div>
          </div>
        </div>
      )}

      {activeTab === 'activities' && (
        <div className="glass-card p-6">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-lg font-semibold">Activities</h3>
            <button className="btn-secondary text-sm">
              <PlusIcon className="w-4 h-4" />
              Add Activity
            </button>
          </div>
          {lead.activities && lead.activities.length > 0 ? (
            <div className="space-y-4">
              {lead.activities.map((activity: any) => (
                <div key={activity.id} className="flex gap-4 p-4 bg-dark-700/30 rounded-lg">
                  <div className="w-2 h-2 bg-primary-400 rounded-full mt-2" />
                  <div className="flex-1">
                    <p className="font-medium">{activity.type}</p>
                    <p className="text-dark-500">{activity.description}</p>
                    <p className="text-sm text-dark-500 mt-1">
                      {new Date(activity.createdAt).toLocaleString()}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <p className="text-dark-500 text-center py-8">No activities yet</p>
          )}
        </div>
      )}

      {activeTab === 'campaigns' && (
        <div className="glass-card p-6">
          <h3 className="text-lg font-semibold mb-4">Campaigns</h3>
          {lead.campaignLeads && lead.campaignLeads.length > 0 ? (
            <div className="space-y-4">
              {lead.campaignLeads.map((cl: any) => (
                <div key={cl.id} className="flex items-center justify-between p-4 bg-dark-700/30 rounded-lg">
                  <div>
                    <p className="font-medium">{cl.campaign.name}</p>
                    <p className="text-sm text-dark-500">Status: {cl.status}</p>
                  </div>
                  <span className={`badge ${cl.status === 'COMPLETED' ? 'badge-success' : 'badge-warning'}`}>
                    {cl.status}
                  </span>
                </div>
              ))}
            </div>
          ) : (
            <p className="text-dark-500 text-center py-8">Not enrolled in any campaigns</p>
          )}
        </div>
      )}
    </div>
  );
}
