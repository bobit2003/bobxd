import { useEffect, useState } from 'react';
import { 
  BoltIcon, 
  RocketLaunchIcon, 
  ClockIcon, 
  CircleStackIcon, 
  UsersIcon, 
  ChartBarIcon,
  CheckIcon,
  StarIcon,
} from '@heroicons/react/24/outline';
import { Link } from 'react-router-dom';

const features = [
  {
    title: 'AI Lead Qualification',
    description: 'Let AI agents qualify leads 24/7 based on your criteria. Never miss a hot lead again.',
    icon: BoltIcon,
  },
  {
    title: 'Automated Campaigns',
    description: 'Run multi-channel campaigns that adapt to lead behavior and engagement.',
    icon: RocketLaunchIcon,
  },
  {
    title: 'Smart Follow-ups',
    description: 'Never miss a follow-up with AI-powered scheduling and reminders.',
    icon: ClockIcon,
  },
  {
    title: 'Data Enrichment',
    description: 'Automatically enrich lead data from multiple sources for better insights.',
    icon: CircleStackIcon,
  },
  {
    title: 'Team Collaboration',
    description: 'Work together with shared workspaces, assignments, and real-time updates.',
    icon: UsersIcon,
  },
  {
    title: 'Advanced Analytics',
    description: 'Track performance with detailed insights, funnels, and conversion reports.',
    icon: ChartBarIcon,
  },
];

const plans = [
  {
    name: 'Free',
    price: 0,
    period: 'forever',
    description: 'Perfect for getting started',
    features: [
      '1 Workspace',
      '100 Leads',
      '2 AI Agents',
      '3 Campaigns',
      'Community Support',
    ],
    cta: 'Get Started',
    highlighted: false,
  },
  {
    name: 'Starter',
    price: 29,
    period: 'month',
    description: 'For growing agencies',
    features: [
      '3 Workspaces',
      '1,000 Leads',
      '5 AI Agents',
      '10 Campaigns',
      'Email Support',
    ],
    cta: 'Start Free Trial',
    highlighted: false,
  },
  {
    name: 'Professional',
    price: 99,
    period: 'month',
    description: 'For established teams',
    features: [
      '10 Workspaces',
      '10,000 Leads',
      '20 AI Agents',
      '50 Campaigns',
      'Priority Support',
    ],
    cta: 'Start Free Trial',
    highlighted: true,
  },
  {
    name: 'Enterprise',
    price: 299,
    period: 'month',
    description: 'For large organizations',
    features: [
      'Unlimited Workspaces',
      'Unlimited Leads',
      'Unlimited Agents',
      'Unlimited Campaigns',
      'Dedicated Support',
    ],
    cta: 'Contact Sales',
    highlighted: false,
  },
];

const testimonials = [
  {
    name: 'Sarah Johnson',
    role: 'CEO, Growth Agency',
    content: 'BOB XD transformed our lead generation process. We saw a 300% increase in qualified leads within the first month.',
    avatar: 'SJ',
  },
  {
    name: 'Michael Chen',
    role: 'Sales Director, TechScale',
    content: "The AI agents work tirelessly, qualifying leads while we sleep. It's like having a 24/7 sales team.",
    avatar: 'MC',
  },
  {
    name: 'Emily Rodriguez',
    role: 'Founder, LeadGen Pro',
    content: 'Best investment we made this year. The automation saved us 40 hours per week on manual lead follow-ups.',
    avatar: 'ER',
  },
];

export default function Landing() {
  const [isVisible, setIsVisible] = useState<Record<string, boolean>>({});

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          setIsVisible((prev) => ({
            ...prev,
            [entry.target.id]: entry.isIntersecting,
          }));
        });
      },
      { threshold: 0.1 }
    );

    document.querySelectorAll('[data-animate]').forEach((el) => {
      observer.observe(el);
    });

    return () => observer.disconnect();
  }, []);

  return (
    <div className="overflow-hidden">
      {/* Hero Section */}
      <section className="relative pt-32 pb-20 lg:pt-48 lg:pb-32">
        {/* Background effects */}
        <div className="absolute inset-0 overflow-hidden pointer-events-none">
          <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-primary-500/20 rounded-full blur-3xl animate-pulse-slow" />
          <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-accent-500/20 rounded-full blur-3xl animate-pulse-slow" style={{ animationDelay: '1s' }} />
          <div className="absolute inset-0 bg-grid-pattern opacity-30" />
        </div>

        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center max-w-4xl mx-auto">
            <div className="inline-flex items-center gap-2 px-4 py-2 bg-primary-500/10 border border-primary-500/30 rounded-full mb-8">
              <StarIcon className="w-4 h-4 text-primary-400" />
              <span className="text-sm text-primary-400">Now with GPT-4 powered agents</span>
            </div>

            <h1 className="text-4xl sm:text-5xl lg:text-7xl font-bold mb-6 leading-tight">
              AI Operating System for{' '}
              <span className="gradient-text">Modern Agencies</span>
            </h1>

            <p className="text-lg sm:text-xl text-dark-500 mb-10 max-w-2xl mx-auto">
              Automate lead generation, qualification, and nurturing with intelligent AI agents. 
              Scale your agency without scaling your team.
            </p>

            <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
              <Link to="/register" className="btn-primary text-lg px-8 py-4">
                Get Started Free
              </Link>
              <a href="#demo" className="btn-outline text-lg px-8 py-4">
                Watch Demo
              </a>
            </div>

            <p className="mt-6 text-sm text-dark-500">
              No credit card required • 14-day free trial • Cancel anytime
            </p>
          </div>

          {/* Dashboard Preview */}
          <div className="mt-20 relative">
            <div className="absolute inset-0 bg-gradient-to-t from-dark-900 via-transparent to-transparent z-10" />
            <div className="glass-card p-2 lg:p-4 neon-border">
              <div className="bg-dark-800 rounded-lg overflow-hidden">
                <div className="flex items-center gap-2 px-4 py-3 border-b border-dark-600">
                  <div className="flex gap-2">
                    <div className="w-3 h-3 rounded-full bg-red-500" />
                    <div className="w-3 h-3 rounded-full bg-yellow-500" />
                    <div className="w-3 h-3 rounded-full bg-green-500" />
                  </div>
                  <div className="flex-1 text-center text-sm text-dark-500">BOB XD Dashboard</div>
                </div>
                <div className="p-6 grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div className="bg-dark-700/50 rounded-lg p-4">
                    <div className="text-dark-500 text-sm mb-2">Total Leads</div>
                    <div className="text-3xl font-bold">2,847</div>
                    <div className="text-green-400 text-sm mt-1">+12.5%</div>
                  </div>
                  <div className="bg-dark-700/50 rounded-lg p-4">
                    <div className="text-dark-500 text-sm mb-2">Active Agents</div>
                    <div className="text-3xl font-bold">12</div>
                    <div className="text-green-400 text-sm mt-1">All running</div>
                  </div>
                  <div className="bg-dark-700/50 rounded-lg p-4">
                    <div className="text-dark-500 text-sm mb-2">Conversion Rate</div>
                    <div className="text-3xl font-bold">24.8%</div>
                    <div className="text-green-400 text-sm mt-1">+3.2%</div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section id="features" className="py-20 lg:py-32">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold mb-4">
              Everything you need to{' '}
              <span className="gradient-text">scale your agency</span>
            </h2>
            <p className="text-lg text-dark-500 max-w-2xl mx-auto">
              Powerful AI-driven tools to automate your lead generation and nurturing process.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {features.map((feature, index) => (
              <div
                key={feature.title}
                className="glass-card p-6 hover:border-primary-500/30 transition-all duration-300 group"
              >
                <div className="w-12 h-12 bg-primary-500/10 rounded-lg flex items-center justify-center mb-4 group-hover:bg-primary-500/20 transition-colors">
                  <feature.icon className="w-6 h-6 text-primary-400" />
                </div>
                <h3 className="text-xl font-semibold mb-2">{feature.title}</h3>
                <p className="text-dark-500">{feature.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Pricing Section */}
      <section id="pricing" className="py-20 lg:py-32 bg-dark-800/50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold mb-4">
              Simple, transparent <span className="gradient-text">pricing</span>
            </h2>
            <p className="text-lg text-dark-500 max-w-2xl mx-auto">
              Start free, scale as you grow. No hidden fees.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {plans.map((plan) => (
              <div
                key={plan.name}
                className={`glass-card p-6 ${
                  plan.highlighted
                    ? 'border-primary-500/50 shadow-lg shadow-primary-500/10'
                    : ''
                }`}
              >
                {plan.highlighted && (
                  <div className="inline-block px-3 py-1 bg-primary-500/20 text-primary-400 text-sm rounded-full mb-4">
                    Most Popular
                  </div>
                )}
                <h3 className="text-xl font-semibold mb-2">{plan.name}</h3>
                <p className="text-dark-500 text-sm mb-4">{plan.description}</p>
                <div className="mb-6">
                  <span className="text-4xl font-bold">${plan.price}</span>
                  <span className="text-dark-500">/{plan.period}</span>
                </div>
                <ul className="space-y-3 mb-6">
                  {plan.features.map((feature) => (
                    <li key={feature} className="flex items-center gap-2">
                      <CheckIcon className="w-5 h-5 text-primary-400 flex-shrink-0" />
                      <span className="text-sm">{feature}</span>
                    </li>
                  ))}
                </ul>
                <Link
                  to="/register"
                  className={`block text-center py-3 rounded-lg font-medium transition-colors ${
                    plan.highlighted
                      ? 'btn-primary'
                      : 'bg-dark-700 hover:bg-dark-600'
                  }`}
                >
                  {plan.cta}
                </Link>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Testimonials Section */}
      <section id="testimonials" className="py-20 lg:py-32">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold mb-4">
              Loved by <span className="gradient-text">agencies worldwide</span>
            </h2>
            <p className="text-lg text-dark-500 max-w-2xl mx-auto">
              See what our customers have to say about BOB XD.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {testimonials.map((testimonial) => (
              <div key={testimonial.name} className="glass-card p-6">
                <div className="flex items-center gap-1 mb-4">
                  {[...Array(5)].map((_, i) => (
                    <StarIcon key={i} className="w-5 h-5 text-yellow-400 fill-current" />
                  ))}
                </div>
                <p className="text-lg mb-6">"{testimonial.content}"</p>
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 bg-primary-500/20 rounded-full flex items-center justify-center">
                    <span className="text-primary-400 font-medium">{testimonial.avatar}</span>
                  </div>
                  <div>
                    <div className="font-medium">{testimonial.name}</div>
                    <div className="text-sm text-dark-500">{testimonial.role}</div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 lg:py-32">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <div className="glass-card p-12 neon-border">
            <h2 className="text-3xl sm:text-4xl font-bold mb-4">
              Ready to supercharge your lead generation?
            </h2>
            <p className="text-lg text-dark-500 mb-8">
              Join thousands of agencies using BOB XD to grow their business.
            </p>
            <Link to="/register" className="btn-primary text-lg px-8 py-4">
              Start Free Trial
            </Link>
            <p className="mt-4 text-sm text-dark-500">
              No credit card required
            </p>
          </div>
        </div>
      </section>
    </div>
  );
}
