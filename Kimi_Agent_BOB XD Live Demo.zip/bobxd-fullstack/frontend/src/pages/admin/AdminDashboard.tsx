import { useState, useEffect } from 'react';
import { adminApi } from '../../utils/api';
import { 
  UsersIcon, 
  BuildingOfficeIcon, 
  UserGroupIcon,
  CpuChipIcon,
} from '@heroicons/react/24/outline';
import toast from 'react-hot-toast';

export default function AdminDashboard() {
  const [stats, setStats] = useState<any>(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    loadStats();
  }, []);

  const loadStats = async () => {
    setIsLoading(true);
    try {
      const response = await adminApi.getDashboard();
      setStats(response.data.data);
    } catch (error) {
      toast.error('Failed to load admin stats');
    } finally {
      setIsLoading(false);
    }
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-96">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary-500" />
      </div>
    );
  }

  const statCards = [
    { title: 'Total Users', value: stats?.stats.totalUsers || 0, icon: UsersIcon, color: 'primary' },
    { title: 'Total Workspaces', value: stats?.stats.totalWorkspaces || 0, icon: BuildingOfficeIcon, color: 'accent' },
    { title: 'Total Leads', value: stats?.stats.totalLeads || 0, icon: UserGroupIcon, color: 'green' },
    { title: 'Total Agents', value: stats?.stats.totalAgents || 0, icon: CpuChipIcon, color: 'purple' },
  ];

  return (
    <div className="space-y-8">
      <div>
        <h1 className="text-2xl font-bold">Admin Dashboard</h1>
        <p className="text-dark-500">System overview and management</p>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-6">
        {statCards.map((card) => (
          <div key={card.title} className="stat-card">
            <div className="flex items-start justify-between">
              <div>
                <p className="text-dark-500 text-sm">{card.title}</p>
                <p className="text-3xl font-bold mt-1">{card.value.toLocaleString()}</p>
              </div>
              <div className={`w-12 h-12 rounded-lg flex items-center justify-center bg-${card.color}-500/20`}>
                <card.icon className={`w-6 h-6 text-${card.color}-400`} />
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Recent Users */}
      <div className="glass-card p-6">
        <h3 className="text-lg font-semibold mb-4">Recent Users</h3>
        {stats?.recentUsers?.length > 0 ? (
          <div className="table-container">
            <table className="data-table">
              <thead>
                <tr>
                  <th>Name</th>
                  <th>Email</th>
                  <th>Role</th>
                  <th>Status</th>
                  <th>Joined</th>
                </tr>
              </thead>
              <tbody>
                {stats.recentUsers.map((user: any) => (
                  <tr key={user.id}>
                    <td>{user.firstName} {user.lastName}</td>
                    <td>{user.email}</td>
                    <td><span className="badge badge-purple">{user.role}</span></td>
                    <td><span className="badge badge-success">{user.status}</span></td>
                    <td>{new Date(user.createdAt).toLocaleDateString()}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        ) : (
          <p className="text-dark-500 text-center py-8">No users yet</p>
        )}
      </div>

      {/* Recent Workspaces */}
      <div className="glass-card p-6">
        <h3 className="text-lg font-semibold mb-4">Recent Workspaces</h3>
        {stats?.recentWorkspaces?.length > 0 ? (
          <div className="table-container">
            <table className="data-table">
              <thead>
                <tr>
                  <th>Name</th>
                  <th>Owner</th>
                  <th>Plan</th>
                  <th>Created</th>
                </tr>
              </thead>
              <tbody>
                {stats.recentWorkspaces.map((workspace: any) => (
                  <tr key={workspace.id}>
                    <td>{workspace.name}</td>
                    <td>{workspace.owner.email}</td>
                    <td><span className="badge badge-info">{workspace.plan}</span></td>
                    <td>{new Date(workspace.createdAt).toLocaleDateString()}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        ) : (
          <p className="text-dark-500 text-center py-8">No workspaces yet</p>
        )}
      </div>
    </div>
  );
}
