import { useEffect, useState } from 'react';
import { 
  UsersIcon, 
  CpuChipIcon, 
  RocketLaunchIcon, 
  ChartBarIcon,
  ArrowTrendingUpIcon,
  ArrowTrendingDownIcon,
} from '@heroicons/react/24/outline';
import { useWorkspaceStore } from '../../stores/workspaceStore';
import { analyticsApi, workspaceApi } from '../../utils/api';
import { 
  LineChart, 
  Line, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer,
  BarChart,
  Bar,
} from 'recharts';
import toast from 'react-hot-toast';

interface DashboardStats {
  leads: {
    total: number;
    newThisMonth: number;
    newThisWeek: number;
    byStatus: Array<{ status: string; _count: { status: number } }>;
  };
  campaigns: {
    total: number;
    active: number;
  };
  agents: {
    total: number;
    active: number;
  };
  conversion: {
    rate: number;
  };
}

export default function Dashboard() {
  const { currentWorkspace } = useWorkspaceStore();
  const [stats, setStats] = useState<DashboardStats | null>(null);
  const [timeSeriesData, setTimeSeriesData] = useState<any[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    if (currentWorkspace) {
      loadDashboardData();
    }
  }, [currentWorkspace]);

  const loadDashboardData = async () => {
    if (!currentWorkspace) return;
    
    setIsLoading(true);
    try {
      const [dashboardRes, timeSeriesRes] = await Promise.all([
        analyticsApi.getDashboard(currentWorkspace.id),
        analyticsApi.getTimeSeries(currentWorkspace.id, { days: '30' }),
      ]);

      setStats(dashboardRes.data.data);
      setTimeSeriesData(timeSeriesRes.data.data.leads);
    } catch (error) {
      toast.error('Failed to load dashboard data');
    } finally {
      setIsLoading(false);
    }
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-96">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary-500" />
      </div>
    );
  }

  const statCards = [
    {
      title: 'Total Leads',
      value: stats?.leads.total || 0,
      change: `+${stats?.leads.newThisWeek || 0} this week`,
      icon: UsersIcon,
      trend: 'up',
      color: 'primary',
    },
    {
      title: 'Active Agents',
      value: stats?.agents.active || 0,
      change: `${stats?.agents.total || 0} total agents`,
      icon: CpuChipIcon,
      trend: 'neutral',
      color: 'accent',
    },
    {
      title: 'Active Campaigns',
      value: stats?.campaigns.active || 0,
      change: `${stats?.campaigns.total || 0} total campaigns`,
      icon: RocketLaunchIcon,
      trend: 'up',
      color: 'purple',
    },
    {
      title: 'Conversion Rate',
      value: `${stats?.conversion.rate || 0}%`,
      change: 'Based on qualified leads',
      icon: ChartBarIcon,
      trend: 'up',
      color: 'green',
    },
  ];

  return (
    <div className="space-y-8">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold">Dashboard</h1>
          <p className="text-dark-500">
            Welcome back! Here's what's happening in {currentWorkspace?.name}.
          </p>
        </div>
        <div className="flex gap-3">
          <a href="/leads/create" className="btn-primary">
            + Add Lead
          </a>
          <a href="/campaigns/create" className="btn-secondary">
            + New Campaign
          </a>
        </div>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
        {statCards.map((card) => (
          <div key={card.title} className="stat-card">
            <div className="flex items-start justify-between">
              <div>
                <p className="text-dark-500 text-sm">{card.title}</p>
                <p className="text-3xl font-bold mt-1">{card.value}</p>
                <div className="flex items-center gap-1 mt-2">
                  {card.trend === 'up' && (
                    <ArrowTrendingUpIcon className="w-4 h-4 text-green-400" />
                  )}
                  {card.trend === 'down' && (
                    <ArrowTrendingDownIcon className="w-4 h-4 text-red-400" />
                  )}
                  <span className="text-sm text-dark-500">{card.change}</span>
                </div>
              </div>
              <div className={`w-12 h-12 rounded-lg flex items-center justify-center ${
                card.color === 'primary' ? 'bg-primary-500/20' :
                card.color === 'accent' ? 'bg-accent-500/20' :
                card.color === 'green' ? 'bg-green-500/20' :
                'bg-purple-500/20'
              }`}>
                <card.icon className={`w-6 h-6 ${
                  card.color === 'primary' ? 'text-primary-400' :
                  card.color === 'accent' ? 'text-accent-400' :
                  card.color === 'green' ? 'text-green-400' :
                  'text-purple-400'
                }`} />
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Charts Row */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Leads Over Time */}
        <div className="glass-card p-6">
          <h3 className="text-lg font-semibold mb-4">Leads Over Time</h3>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={timeSeriesData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#303056" />
                <XAxis 
                  dataKey="date" 
                  stroke="#6b7280"
                  tickFormatter={(value) => new Date(value).toLocaleDateString('en-US', { month: 'short', day: 'numeric' })}
                />
                <YAxis stroke="#6b7280" />
                <Tooltip 
                  contentStyle={{ 
                    backgroundColor: '#1a1a2e', 
                    border: '1px solid #303056',
                    borderRadius: '8px'
                  }}
                />
                <Line 
                  type="monotone" 
                  dataKey="value" 
                  stroke="#8b5cf6" 
                  strokeWidth={2}
                  dot={{ fill: '#8b5cf6', strokeWidth: 0 }}
                />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Lead Status Distribution */}
        <div className="glass-card p-6">
          <h3 className="text-lg font-semibold mb-4">Lead Status Distribution</h3>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={stats?.leads.byStatus || []}>
                <CartesianGrid strokeDasharray="3 3" stroke="#303056" />
                <XAxis 
                  dataKey="status" 
                  stroke="#6b7280"
                  tickFormatter={(value) => value.charAt(0) + value.slice(1).toLowerCase()}
                />
                <YAxis stroke="#6b7280" />
                <Tooltip 
                  contentStyle={{ 
                    backgroundColor: '#1a1a2e', 
                    border: '1px solid #303056',
                    borderRadius: '8px'
                  }}
                />
                <Bar 
                  dataKey="_count.status" 
                  fill="#8b5cf6"
                  radius={[4, 4, 0, 0]}
                />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>

      {/* Quick Actions */}
      <div className="glass-card p-6">
        <h3 className="text-lg font-semibold mb-4">Quick Actions</h3>
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
          <a
            href="/agents/create"
            className="flex flex-col items-center p-4 bg-dark-700/50 rounded-lg hover:bg-dark-700 transition-colors"
          >
            <CpuChipIcon className="w-8 h-8 text-primary-400 mb-2" />
            <span className="text-sm font-medium">Create Agent</span>
          </a>
          <a
            href="/campaigns/create"
            className="flex flex-col items-center p-4 bg-dark-700/50 rounded-lg hover:bg-dark-700 transition-colors"
          >
            <RocketLaunchIcon className="w-8 h-8 text-accent-400 mb-2" />
            <span className="text-sm font-medium">New Campaign</span>
          </a>
          <a
            href="/leads"
            className="flex flex-col items-center p-4 bg-dark-700/50 rounded-lg hover:bg-dark-700 transition-colors"
          >
            <UsersIcon className="w-8 h-8 text-green-400 mb-2" />
            <span className="text-sm font-medium">View Leads</span>
          </a>
          <a
            href="/analytics"
            className="flex flex-col items-center p-4 bg-dark-700/50 rounded-lg hover:bg-dark-700 transition-colors"
          >
            <ChartBarIcon className="w-8 h-8 text-purple-400 mb-2" />
            <span className="text-sm font-medium">Analytics</span>
          </a>
        </div>
      </div>
    </div>
  );
}
