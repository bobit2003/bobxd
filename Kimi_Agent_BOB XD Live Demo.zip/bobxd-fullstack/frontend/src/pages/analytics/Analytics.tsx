import { useState, useEffect } from 'react';
import { useWorkspaceStore } from '../../stores/workspaceStore';
import { analyticsApi } from '../../utils/api';
import { 
  LineChart, 
  Line, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer,
  BarChart,
  Bar,
  PieChart,
  Pie,
  Cell,
} from 'recharts';
import toast from 'react-hot-toast';

const COLORS = ['#8b5cf6', '#3b82f6', '#10b981', '#f59e0b', '#ef4444', '#6b7280'];

export default function Analytics() {
  const { currentWorkspace } = useWorkspaceStore();
  const [dashboardData, setDashboardData] = useState<any>(null);
  const [timeSeriesData, setTimeSeriesData] = useState<any>({ leads: [], executions: [] });
  const [funnelData, setFunnelData] = useState<any[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    if (currentWorkspace) {
      loadAnalytics();
    }
  }, [currentWorkspace]);

  const loadAnalytics = async () => {
    if (!currentWorkspace) return;
    
    setIsLoading(true);
    try {
      const [dashboardRes, timeSeriesRes, funnelRes] = await Promise.all([
        analyticsApi.getDashboard(currentWorkspace.id),
        analyticsApi.getTimeSeries(currentWorkspace.id, { days: '30' }),
        analyticsApi.getFunnel(currentWorkspace.id),
      ]);

      setDashboardData(dashboardRes.data.data);
      setTimeSeriesData(timeSeriesRes.data.data);
      setFunnelData(funnelRes.data.data);
    } catch (error) {
      toast.error('Failed to load analytics');
    } finally {
      setIsLoading(false);
    }
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-96">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary-500" />
      </div>
    );
  }

  return (
    <div className="space-y-8">
      <div>
        <h1 className="text-2xl font-bold">Analytics</h1>
        <p className="text-dark-500">Track your performance and insights</p>
      </div>

      {/* Stats Overview */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="stat-card">
          <p className="text-dark-500 text-sm">Total Leads</p>
          <p className="text-3xl font-bold">{dashboardData?.leads.total || 0}</p>
          <p className="text-sm text-green-400">+{dashboardData?.leads.newThisWeek || 0} this week</p>
        </div>
        <div className="stat-card">
          <p className="text-dark-500 text-sm">Conversion Rate</p>
          <p className="text-3xl font-bold">{dashboardData?.conversion.rate || 0}%</p>
          <p className="text-sm text-dark-500">Qualified leads</p>
        </div>
        <div className="stat-card">
          <p className="text-dark-500 text-sm">Active Campaigns</p>
          <p className="text-3xl font-bold">{dashboardData?.campaigns.active || 0}</p>
          <p className="text-sm text-dark-500">{dashboardData?.campaigns.total || 0} total</p>
        </div>
        <div className="stat-card">
          <p className="text-dark-500 text-sm">Active Agents</p>
          <p className="text-3xl font-bold">{dashboardData?.agents.active || 0}</p>
          <p className="text-sm text-dark-500">{dashboardData?.agents.total || 0} total</p>
        </div>
      </div>

      {/* Charts Row */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Leads Over Time */}
        <div className="glass-card p-6">
          <h3 className="text-lg font-semibold mb-4">Leads Over Time</h3>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={timeSeriesData.leads}>
                <CartesianGrid strokeDasharray="3 3" stroke="#303056" />
                <XAxis 
                  dataKey="date" 
                  stroke="#6b7280"
                  tickFormatter={(value) => new Date(value).toLocaleDateString('en-US', { month: 'short', day: 'numeric' })}
                />
                <YAxis stroke="#6b7280" />
                <Tooltip 
                  contentStyle={{ 
                    backgroundColor: '#1a1a2e', 
                    border: '1px solid #303056',
                    borderRadius: '8px'
                  }}
                />
                <Line 
                  type="monotone" 
                  dataKey="value" 
                  stroke="#8b5cf6" 
                  strokeWidth={2}
                  dot={false}
                />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Lead Status Distribution */}
        <div className="glass-card p-6">
          <h3 className="text-lg font-semibold mb-4">Lead Status Distribution</h3>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={dashboardData?.leads.byStatus || []}
                  cx="50%"
                  cy="50%"
                  innerRadius={60}
                  outerRadius={80}
                  paddingAngle={5}
                  dataKey="_count.status"
                  nameKey="status"
                >
                  {(dashboardData?.leads.byStatus || []).map((entry: any, index: number) => (
                    <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip 
                  contentStyle={{ 
                    backgroundColor: '#1a1a2e', 
                    border: '1px solid #303056',
                    borderRadius: '8px'
                  }}
                />
              </PieChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>

      {/* Funnel Chart */}
      <div className="glass-card p-6">
        <h3 className="text-lg font-semibold mb-4">Lead Funnel</h3>
        <div className="h-64">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={funnelData} layout="vertical">
              <CartesianGrid strokeDasharray="3 3" stroke="#303056" />
              <XAxis type="number" stroke="#6b7280" />
              <YAxis dataKey="name" type="category" stroke="#6b7280" width={100} />
              <Tooltip 
                contentStyle={{ 
                  backgroundColor: '#1a1a2e', 
                  border: '1px solid #303056',
                  borderRadius: '8px'
                }}
              />
              <Bar dataKey="count" fill="#8b5cf6" radius={[0, 4, 4, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Agent Performance */}
      <div className="glass-card p-6">
        <h3 className="text-lg font-semibold mb-4">Agent Types</h3>
        <div className="h-64">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={dashboardData?.agents.byType || []}>
              <CartesianGrid strokeDasharray="3 3" stroke="#303056" />
              <XAxis 
                dataKey="type" 
                stroke="#6b7280"
                tickFormatter={(value) => value.split('_').map((w: string) => w[0] + w.slice(1).toLowerCase()).join(' ')}
              />
              <YAxis stroke="#6b7280" />
              <Tooltip 
                contentStyle={{ 
                  backgroundColor: '#1a1a2e', 
                  border: '1px solid #303056',
                  borderRadius: '8px'
                }}
              />
              <Bar dataKey="_count.type" fill="#3b82f6" radius={[4, 4, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>
    </div>
  );
}
