import { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { campaignApi } from '../../utils/api';
import { 
  ArrowLeftIcon, 
  PlayIcon, 
  PauseIcon,
  TrashIcon,
  PlusIcon,
} from '@heroicons/react/24/outline';
import toast from 'react-hot-toast';

const statusColors: Record<string, string> = {
  PENDING: 'badge-warning',
  IN_PROGRESS: 'badge-info',
  COMPLETED: 'badge-success',
  FAILED: 'badge-error',
  SKIPPED: 'badge-error',
};

export default function CampaignDetail() {
  const { campaignId } = useParams<{ campaignId: string }>();
  const navigate = useNavigate();
  const [campaign, setCampaign] = useState<any>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [activeTab, setActiveTab] = useState('overview');

  useEffect(() => {
    if (campaignId) {
      loadCampaign();
    }
  }, [campaignId]);

  const loadCampaign = async () => {
    setIsLoading(true);
    try {
      const response = await campaignApi.get(campaignId!);
      setCampaign(response.data.data);
    } catch (error) {
      toast.error('Failed to load campaign');
      navigate('/campaigns');
    } finally {
      setIsLoading(false);
    }
  };

  const handleStart = async () => {
    try {
      await campaignApi.start(campaignId!);
      toast.success('Campaign started');
      loadCampaign();
    } catch (error: any) {
      toast.error(error.response?.data?.error || 'Failed to start campaign');
    }
  };

  const handlePause = async () => {
    try {
      await campaignApi.pause(campaignId!);
      toast.success('Campaign paused');
      loadCampaign();
    } catch (error) {
      toast.error('Failed to pause campaign');
    }
  };

  const handleDelete = async () => {
    if (!confirm('Are you sure you want to delete this campaign?')) return;
    
    try {
      await campaignApi.delete(campaignId!);
      toast.success('Campaign deleted');
      navigate('/campaigns');
    } catch (error) {
      toast.error('Failed to delete campaign');
    }
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-96">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary-500" />
      </div>
    );
  }

  if (!campaign) return null;

  const progress = campaign.targetCount
    ? Math.round((campaign.completedCount / campaign.targetCount) * 100)
    : 0;

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div className="flex items-center gap-4">
          <button
            onClick={() => navigate('/campaigns')}
            className="p-2 rounded-lg hover:bg-dark-700 transition-colors"
          >
            <ArrowLeftIcon className="w-5 h-5" />
          </button>
          <div>
            <h1 className="text-2xl font-bold">{campaign.name}</h1>
            <p className="text-dark-500">{campaign.type}</p>
          </div>
        </div>
        <div className="flex gap-3">
          {campaign.status === 'RUNNING' ? (
            <button onClick={handlePause} className="btn-outline">
              <PauseIcon className="w-5 h-5" />
              Pause
            </button>
          ) : campaign.status === 'DRAFT' || campaign.status === 'PAUSED' ? (
            <button onClick={handleStart} className="btn-primary">
              <PlayIcon className="w-5 h-5" />
              Start
            </button>
          ) : null}
          <button onClick={handleDelete} className="btn-outline text-red-400 border-red-400/30">
            <TrashIcon className="w-5 h-5" />
          </button>
        </div>
      </div>

      {/* Progress */}
      {campaign.targetCount && (
        <div className="glass-card p-6">
          <div className="flex items-center justify-between mb-2">
            <span className="text-sm text-dark-500">Progress</span>
            <span className="text-sm font-medium">{progress}%</span>
          </div>
          <div className="w-full bg-dark-700 rounded-full h-3">
            <div
              className="bg-gradient-to-r from-primary-500 to-accent-500 h-3 rounded-full transition-all"
              style={{ width: `${progress}%` }}
            />
          </div>
          <div className="flex items-center justify-between mt-2 text-sm">
            <span className="text-dark-500">{campaign.completedCount} completed</span>
            <span className="text-dark-500">{campaign.targetCount} target</span>
          </div>
        </div>
      )}

      {/* Tabs */}
      <div className="flex gap-1 border-b border-dark-600">
        {['overview', 'leads', 'agents'].map((tab) => (
          <button
            key={tab}
            className={`px-4 py-2 font-medium capitalize transition-colors ${
              activeTab === tab
                ? 'text-primary-400 border-b-2 border-primary-400'
                : 'text-dark-500 hover:text-white'
            }`}
            onClick={() => setActiveTab(tab)}
          >
            {tab}
          </button>
        ))}
      </div>

      {activeTab === 'overview' && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <div className="glass-card p-6">
            <h3 className="text-lg font-semibold mb-4">Campaign Information</h3>
            <div className="space-y-4">
              <div>
                <p className="text-sm text-dark-500">Status</p>
                <span className="badge badge-info">{campaign.status}</span>
              </div>
              <div>
                <p className="text-sm text-dark-500">Type</p>
                <p className="font-medium">{campaign.type}</p>
              </div>
              <div>
                <p className="text-sm text-dark-500">Created</p>
                <p className="font-medium">{new Date(campaign.createdAt).toLocaleString()}</p>
              </div>
              {campaign.startDate && (
                <div>
                  <p className="text-sm text-dark-500">Start Date</p>
                  <p className="font-medium">{new Date(campaign.startDate).toLocaleString()}</p>
                </div>
              )}
            </div>
          </div>

          <div className="glass-card p-6">
            <h3 className="text-lg font-semibold mb-4">Statistics</h3>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <p className="text-sm text-dark-500">Total Leads</p>
                <p className="text-2xl font-bold">{campaign._count?.leads || 0}</p>
              </div>
              <div>
                <p className="text-sm text-dark-500">Agents</p>
                <p className="text-2xl font-bold">{campaign.agents?.length || 0}</p>
              </div>
            </div>
          </div>
        </div>
      )}

      {activeTab === 'leads' && (
        <div className="glass-card p-6">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-lg font-semibold">Enrolled Leads</h3>
            <button className="btn-secondary text-sm">
              <PlusIcon className="w-4 h-4" />
              Add Leads
            </button>
          </div>
          {campaign.leads && campaign.leads.length > 0 ? (
            <div className="space-y-3">
              {campaign.leads.map((cl: any) => (
                <div key={cl.id} className="flex items-center justify-between p-4 bg-dark-700/30 rounded-lg">
                  <div>
                    <p className="font-medium">{cl.lead.firstName} {cl.lead.lastName}</p>
                    <p className="text-sm text-dark-500">{cl.lead.email}</p>
                  </div>
                  <span className={`badge ${statusColors[cl.status]}`}>
                    {cl.status}
                  </span>
                </div>
              ))}
            </div>
          ) : (
            <p className="text-dark-500 text-center py-8">No leads enrolled</p>
          )}
        </div>
      )}

      {activeTab === 'agents' && (
        <div className="glass-card p-6">
          <h3 className="text-lg font-semibold mb-4">Assigned Agents</h3>
          {campaign.agents && campaign.agents.length > 0 ? (
            <div className="space-y-3">
              {campaign.agents.map((ca: any) => (
                <div key={ca.id} className="flex items-center justify-between p-4 bg-dark-700/30 rounded-lg">
                  <div>
                    <p className="font-medium">{ca.agent.name}</p>
                    <p className="text-sm text-dark-500">{ca.agent.type}</p>
                  </div>
                  <span className={`badge ${ca.agent.status === 'ACTIVE' ? 'badge-success' : 'badge-warning'}`}>
                    {ca.agent.status}
                  </span>
                </div>
              ))}
            </div>
          ) : (
            <p className="text-dark-500 text-center py-8">No agents assigned</p>
          )}
        </div>
      )}
    </div>
  );
}
