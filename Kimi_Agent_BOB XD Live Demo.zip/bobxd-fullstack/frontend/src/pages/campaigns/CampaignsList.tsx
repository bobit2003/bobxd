import { useState, useEffect } from 'react';
import { useWorkspaceStore } from '../../stores/workspaceStore';
import { campaignApi } from '../../utils/api';
import { 
  PlusIcon, 
  PlayIcon, 
  PauseIcon,
  RocketLaunchIcon,
} from '@heroicons/react/24/outline';
import toast from 'react-hot-toast';

const statusColors: Record<string, string> = {
  DRAFT: 'badge-info',
  SCHEDULED: 'badge-warning',
  RUNNING: 'badge-success',
  PAUSED: 'badge-warning',
  COMPLETED: 'badge-purple',
  CANCELLED: 'badge-error',
};

const typeLabels: Record<string, string> = {
  EMAIL_SEQUENCE: 'Email Sequence',
  LEAD_QUALIFICATION: 'Lead Qualification',
  APPOINTMENT_SETTING: 'Appointment Setting',
  DATA_ENRICHMENT: 'Data Enrichment',
  FOLLOW_UP: 'Follow Up',
  CUSTOM: 'Custom',
};

export default function CampaignsList() {
  const { currentWorkspace } = useWorkspaceStore();
  const [campaigns, setCampaigns] = useState<any[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    if (currentWorkspace) {
      loadCampaigns();
    }
  }, [currentWorkspace]);

  const loadCampaigns = async () => {
    if (!currentWorkspace) return;
    
    setIsLoading(true);
    try {
      const response = await campaignApi.list(currentWorkspace.id);
      setCampaigns(response.data.data.campaigns);
    } catch (error) {
      toast.error('Failed to load campaigns');
    } finally {
      setIsLoading(false);
    }
  };

  const handleStart = async (campaignId: string) => {
    try {
      await campaignApi.start(campaignId);
      toast.success('Campaign started');
      loadCampaigns();
    } catch (error: any) {
      toast.error(error.response?.data?.error || 'Failed to start campaign');
    }
  };

  const handlePause = async (campaignId: string) => {
    try {
      await campaignApi.pause(campaignId);
      toast.success('Campaign paused');
      loadCampaigns();
    } catch (error) {
      toast.error('Failed to pause campaign');
    }
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-96">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary-500" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold">Campaigns</h1>
          <p className="text-dark-500">Manage your lead campaigns</p>
        </div>
        <a href="/campaigns/create" className="btn-primary">
          <PlusIcon className="w-5 h-5" />
          New Campaign
        </a>
      </div>

      {campaigns.length > 0 ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {campaigns.map((campaign) => (
            <div key={campaign.id} className="glass-card p-6 hover:border-primary-500/30 transition-all">
              <div className="flex items-start justify-between mb-4">
                <div className="w-12 h-12 bg-accent-500/20 rounded-lg flex items-center justify-center">
                  <RocketLaunchIcon className="w-6 h-6 text-accent-400" />
                </div>
                <span className={`badge ${statusColors[campaign.status]}`}>
                  {campaign.status}
                </span>
              </div>

              <h3 className="text-lg font-semibold mb-1">{campaign.name}</h3>
              <p className="text-sm text-dark-500 mb-4">{typeLabels[campaign.type] || campaign.type}</p>

              <div className="space-y-2 mb-4">
                <div className="flex justify-between text-sm">
                  <span className="text-dark-500">Leads</span>
                  <span>{campaign._count?.leads || 0}</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-dark-500">Agents</span>
                  <span>{campaign.agents?.length || 0}</span>
                </div>
                {campaign.targetCount && (
                  <div className="flex justify-between text-sm">
                    <span className="text-dark-500">Progress</span>
                    <span>{Math.round((campaign.completedCount / campaign.targetCount) * 100)}%</span>
                  </div>
                )}
              </div>

              {campaign.targetCount && (
                <div className="w-full bg-dark-700 rounded-full h-2 mb-4">
                  <div
                    className="bg-primary-500 h-2 rounded-full transition-all"
                    style={{ width: `${(campaign.completedCount / campaign.targetCount) * 100}%` }}
                  />
                </div>
              )}

              <div className="flex gap-2">
                <a
                  href={`/campaigns/${campaign.id}`}
                  className="flex-1 btn-secondary text-center text-sm py-2"
                >
                  View
                </a>
                {campaign.status === 'RUNNING' ? (
                  <button
                    onClick={() => handlePause(campaign.id)}
                    className="p-2 btn-outline"
                  >
                    <PauseIcon className="w-4 h-4" />
                  </button>
                ) : campaign.status === 'DRAFT' || campaign.status === 'PAUSED' ? (
                  <button
                    onClick={() => handleStart(campaign.id)}
                    className="p-2 btn-primary"
                  >
                    <PlayIcon className="w-4 h-4" />
                  </button>
                ) : null}
              </div>
            </div>
          ))}
        </div>
      ) : (
        <div className="glass-card p-12 text-center">
          <RocketLaunchIcon className="w-16 h-16 text-dark-600 mx-auto mb-4" />
          <h3 className="text-xl font-semibold mb-2">No campaigns yet</h3>
          <p className="text-dark-500 mb-6">Create your first campaign to start engaging leads</p>
          <a href="/campaigns/create" className="btn-primary">
            Create Campaign
          </a>
        </div>
      )}
    </div>
  );
}
