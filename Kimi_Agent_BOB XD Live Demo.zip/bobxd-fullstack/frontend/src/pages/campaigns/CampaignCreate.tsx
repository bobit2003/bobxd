import { useState, useEffect } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { useNavigate } from 'react-router-dom';
import { useWorkspaceStore } from '../../stores/workspaceStore';
import { campaignApi, agentApi } from '../../utils/api';
import toast from 'react-hot-toast';

const campaignSchema = z.object({
  name: z.string().min(1, 'Name is required'),
  description: z.string().optional(),
  type: z.enum(['EMAIL_SEQUENCE', 'LEAD_QUALIFICATION', 'APPOINTMENT_SETTING', 'DATA_ENRICHMENT', 'FOLLOW_UP', 'CUSTOM']),
  agentIds: z.array(z.string()).min(1, 'Select at least one agent'),
  startDate: z.string().optional(),
  targetCount: z.number().optional(),
});

type CampaignForm = z.infer<typeof campaignSchema>;

const campaignTypes = [
  { value: 'EMAIL_SEQUENCE', label: 'Email Sequence', description: 'Send automated email sequences to leads' },
  { value: 'LEAD_QUALIFICATION', label: 'Lead Qualification', description: 'Qualify leads using AI agents' },
  { value: 'APPOINTMENT_SETTING', label: 'Appointment Setting', description: 'Schedule appointments with qualified leads' },
  { value: 'DATA_ENRICHMENT', label: 'Data Enrichment', description: 'Enrich lead data automatically' },
  { value: 'FOLLOW_UP', label: 'Follow Up', description: 'Automated follow-up sequences' },
  { value: 'CUSTOM', label: 'Custom', description: 'Create a custom campaign' },
];

export default function CampaignCreate() {
  const [isLoading, setIsLoading] = useState(false);
  const [agents, setAgents] = useState<any[]>([]);
  const navigate = useNavigate();
  const { currentWorkspace } = useWorkspaceStore();

  const {
    register,
    handleSubmit,
    watch,
    setValue,
    formState: { errors },
  } = useForm<CampaignForm>({
    resolver: zodResolver(campaignSchema),
    defaultValues: {
      type: 'LEAD_QUALIFICATION',
      agentIds: [],
    },
  });

  const selectedAgents = watch('agentIds');
  const selectedType = watch('type');

  useEffect(() => {
    if (currentWorkspace) {
      loadAgents();
    }
  }, [currentWorkspace]);

  const loadAgents = async () => {
    if (!currentWorkspace) return;
    try {
      const response = await agentApi.list(currentWorkspace.id);
      setAgents(response.data.data.agents.filter((a: any) => a.status === 'ACTIVE'));
    } catch (error) {
      toast.error('Failed to load agents');
    }
  };

  const toggleAgent = (agentId: string) => {
    const current = selectedAgents || [];
    if (current.includes(agentId)) {
      setValue('agentIds', current.filter((id) => id !== agentId));
    } else {
      setValue('agentIds', [...current, agentId]);
    }
  };

  const onSubmit = async (data: CampaignForm) => {
    if (!currentWorkspace) {
      toast.error('Please select a workspace');
      return;
    }

    setIsLoading(true);
    try {
      const response = await campaignApi.create(currentWorkspace.id, data);
      toast.success('Campaign created successfully');
      navigate(`/campaigns/${response.data.data.id}`);
    } catch (error: any) {
      toast.error(error.response?.data?.error || 'Failed to create campaign');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="max-w-2xl mx-auto">
      <div className="mb-6">
        <h1 className="text-2xl font-bold">Create Campaign</h1>
        <p className="text-dark-500">Set up a new lead engagement campaign</p>
      </div>

      <form onSubmit={handleSubmit(onSubmit)} className="space-y-6">
        <div className="glass-card p-6 space-y-6">
          <div>
            <label className="block text-sm font-medium mb-2">Campaign Name</label>
            <input
              type="text"
              {...register('name')}
              className="input-field"
              placeholder="e.g., Q1 Lead Qualification"
            />
            {errors.name && (
              <p className="mt-1 text-sm text-red-400">{errors.name.message}</p>
            )}
          </div>

          <div>
            <label className="block text-sm font-medium mb-2">Description</label>
            <textarea
              {...register('description')}
              className="input-field"
              rows={3}
              placeholder="What is this campaign about?"
            />
          </div>

          <div>
            <label className="block text-sm font-medium mb-4">Campaign Type</label>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              {campaignTypes.map((type) => (
                <label
                  key={type.value}
                  className={`p-4 rounded-lg border cursor-pointer transition-all ${
                    selectedType === type.value
                      ? 'border-primary-500 bg-primary-500/10'
                      : 'border-dark-600 hover:border-dark-500'
                  }`}
                >
                  <input
                    type="radio"
                    {...register('type')}
                    value={type.value}
                    className="sr-only"
                  />
                  <p className="font-medium">{type.label}</p>
                  <p className="text-sm text-dark-500">{type.description}</p>
                </label>
              ))}
            </div>
          </div>
        </div>

        <div className="glass-card p-6 space-y-6">
          <h3 className="text-lg font-semibold">Select Agents</h3>
          {errors.agentIds && (
            <p className="text-sm text-red-400">{errors.agentIds.message}</p>
          )}
          
          {agents.length > 0 ? (
            <div className="space-y-3">
              {agents.map((agent) => (
                <label
                  key={agent.id}
                  className={`flex items-center gap-4 p-4 rounded-lg border cursor-pointer transition-all ${
                    selectedAgents?.includes(agent.id)
                      ? 'border-primary-500 bg-primary-500/10'
                      : 'border-dark-600 hover:border-dark-500'
                  }`}
                >
                  <input
                    type="checkbox"
                    checked={selectedAgents?.includes(agent.id) || false}
                    onChange={() => toggleAgent(agent.id)}
                    className="w-5 h-5 rounded border-dark-600 bg-dark-800 text-primary-500 focus:ring-primary-500"
                  />
                  <div className="flex-1">
                    <p className="font-medium">{agent.name}</p>
                    <p className="text-sm text-dark-500">{agent.type}</p>
                  </div>
                </label>
              ))}
            </div>
          ) : (
            <p className="text-dark-500 text-center py-4">
              No active agents available. <a href="/agents/create" className="text-primary-400">Create one</a>
            </p>
          )}
        </div>

        <div className="glass-card p-6 space-y-6">
          <h3 className="text-lg font-semibold">Schedule (Optional)</h3>
          
          <div>
            <label className="block text-sm font-medium mb-2">Start Date</label>
            <input
              type="datetime-local"
              {...register('startDate')}
              className="input-field"
            />
          </div>

          <div>
            <label className="block text-sm font-medium mb-2">Target Lead Count</label>
            <input
              type="number"
              {...register('targetCount', { valueAsNumber: true })}
              className="input-field"
              placeholder="Number of leads to process"
            />
          </div>
        </div>

        <div className="flex gap-4">
          <button
            type="button"
            onClick={() => navigate('/campaigns')}
            className="btn-secondary flex-1"
          >
            Cancel
          </button>
          <button
            type="submit"
            className="btn-primary flex-1"
            disabled={isLoading}
          >
            {isLoading ? 'Creating...' : 'Create Campaign'}
          </button>
        </div>
      </form>
    </div>
  );
}
