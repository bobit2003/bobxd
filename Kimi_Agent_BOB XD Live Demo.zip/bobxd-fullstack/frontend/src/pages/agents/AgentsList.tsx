import { useState, useEffect } from 'react';
import { useWorkspaceStore } from '../../stores/workspaceStore';
import { agentApi } from '../../utils/api';
import { 
  PlusIcon, 
  PlayIcon, 
  PauseIcon,
  CpuChipIcon,
} from '@heroicons/react/24/outline';
import toast from 'react-hot-toast';

const statusColors: Record<string, string> = {
  DRAFT: 'badge-info',
  ACTIVE: 'badge-success',
  PAUSED: 'badge-warning',
  ERROR: 'badge-error',
  ARCHIVED: 'badge-error',
};

const typeLabels: Record<string, string> = {
  LEAD_QUALIFIER: 'Lead Qualifier',
  EMAIL_SENDER: 'Email Sender',
  APPOINTMENT_SCHEDULER: 'Appointment Scheduler',
  DATA_ENRICHER: 'Data Enricher',
  FOLLOW_UP: 'Follow Up',
  CUSTOM: 'Custom',
};

export default function AgentsList() {
  const { currentWorkspace } = useWorkspaceStore();
  const [agents, setAgents] = useState<any[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    if (currentWorkspace) {
      loadAgents();
    }
  }, [currentWorkspace]);

  const loadAgents = async () => {
    if (!currentWorkspace) return;
    
    setIsLoading(true);
    try {
      const response = await agentApi.list(currentWorkspace.id);
      setAgents(response.data.data.agents);
    } catch (error) {
      toast.error('Failed to load agents');
    } finally {
      setIsLoading(false);
    }
  };

  const handleActivate = async (agentId: string) => {
    try {
      await agentApi.activate(agentId);
      toast.success('Agent activated');
      loadAgents();
    } catch (error) {
      toast.error('Failed to activate agent');
    }
  };

  const handlePause = async (agentId: string) => {
    try {
      await agentApi.pause(agentId);
      toast.success('Agent paused');
      loadAgents();
    } catch (error) {
      toast.error('Failed to pause agent');
    }
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-96">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary-500" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold">AI Agents</h1>
          <p className="text-dark-500">Manage your AI-powered agents</p>
        </div>
        <a href="/agents/create" className="btn-primary">
          <PlusIcon className="w-5 h-5" />
          Create Agent
        </a>
      </div>

      {/* Agents Grid */}
      {agents.length > 0 ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {agents.map((agent) => (
            <div key={agent.id} className="glass-card p-6 hover:border-primary-500/30 transition-all">
              <div className="flex items-start justify-between mb-4">
                <div className="w-12 h-12 bg-primary-500/20 rounded-lg flex items-center justify-center">
                  <CpuChipIcon className="w-6 h-6 text-primary-400" />
                </div>
                <span className={`badge ${statusColors[agent.status]}`}>
                  {agent.status}
                </span>
              </div>

              <h3 className="text-lg font-semibold mb-1">{agent.name}</h3>
              <p className="text-sm text-dark-500 mb-4">{typeLabels[agent.type] || agent.type}</p>

              <div className="space-y-2 mb-4">
                <div className="flex justify-between text-sm">
                  <span className="text-dark-500">Model</span>
                  <span>{agent.model}</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-dark-500">Executions</span>
                  <span>{agent._count?.executions || 0}</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-dark-500">Token Usage</span>
                  <span>{agent.tokenUsage?.toLocaleString()}</span>
                </div>
              </div>

              <div className="flex gap-2">
                <a
                  href={`/agents/${agent.id}`}
                  className="flex-1 btn-secondary text-center text-sm py-2"
                >
                  View
                </a>
                {agent.status === 'ACTIVE' ? (
                  <button
                    onClick={() => handlePause(agent.id)}
                    className="p-2 btn-outline"
                  >
                    <PauseIcon className="w-4 h-4" />
                  </button>
                ) : (
                  <button
                    onClick={() => handleActivate(agent.id)}
                    className="p-2 btn-primary"
                  >
                    <PlayIcon className="w-4 h-4" />
                  </button>
                )}
              </div>
            </div>
          ))}
        </div>
      ) : (
        <div className="glass-card p-12 text-center">
          <CpuChipIcon className="w-16 h-16 text-dark-600 mx-auto mb-4" />
          <h3 className="text-xl font-semibold mb-2">No agents yet</h3>
          <p className="text-dark-500 mb-6">Create your first AI agent to start automating</p>
          <a href="/agents/create" className="btn-primary">
            Create Agent
          </a>
        </div>
      )}
    </div>
  );
}
