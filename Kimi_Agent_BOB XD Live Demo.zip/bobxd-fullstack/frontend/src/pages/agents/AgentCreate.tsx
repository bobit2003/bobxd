import { useState } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { useNavigate } from 'react-router-dom';
import { useWorkspaceStore } from '../../stores/workspaceStore';
import { agentApi } from '../../utils/api';
import toast from 'react-hot-toast';

const agentSchema = z.object({
  name: z.string().min(1, 'Name is required'),
  description: z.string().optional(),
  type: z.enum(['LEAD_QUALIFIER', 'EMAIL_SENDER', 'APPOINTMENT_SCHEDULER', 'DATA_ENRICHER', 'FOLLOW_UP', 'CUSTOM']),
  systemPrompt: z.string().optional(),
  model: z.string().default('gpt-4'),
  temperature: z.number().min(0).max(2).default(0.7),
  maxTokens: z.number().min(1).max(8000).default(2000),
});

type AgentForm = z.infer<typeof agentSchema>;

const agentTypes = [
  { value: 'LEAD_QUALIFIER', label: 'Lead Qualifier', description: 'Qualify leads based on your criteria' },
  { value: 'EMAIL_SENDER', label: 'Email Sender', description: 'Send personalized emails to leads' },
  { value: 'APPOINTMENT_SCHEDULER', label: 'Appointment Scheduler', description: 'Schedule meetings with qualified leads' },
  { value: 'DATA_ENRICHER', label: 'Data Enricher', description: 'Enrich lead data from external sources' },
  { value: 'FOLLOW_UP', label: 'Follow Up', description: 'Automated follow-up sequences' },
  { value: 'CUSTOM', label: 'Custom', description: 'Create a custom agent for your needs' },
];

export default function AgentCreate() {
  const [isLoading, setIsLoading] = useState(false);
  const navigate = useNavigate();
  const { currentWorkspace } = useWorkspaceStore();

  const {
    register,
    handleSubmit,
    watch,
    formState: { errors },
  } = useForm<AgentForm>({
    resolver: zodResolver(agentSchema),
    defaultValues: {
      type: 'LEAD_QUALIFIER',
      model: 'gpt-4',
      temperature: 0.7,
      maxTokens: 2000,
    },
  });

  const selectedType = watch('type');

  const onSubmit = async (data: AgentForm) => {
    if (!currentWorkspace) {
      toast.error('Please select a workspace');
      return;
    }

    setIsLoading(true);
    try {
      const response = await agentApi.create(currentWorkspace.id, data);
      toast.success('Agent created successfully');
      navigate(`/agents/${response.data.data.id}`);
    } catch (error: any) {
      toast.error(error.response?.data?.error || 'Failed to create agent');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="max-w-2xl mx-auto">
      <div className="mb-6">
        <h1 className="text-2xl font-bold">Create AI Agent</h1>
        <p className="text-dark-500">Configure your new AI-powered agent</p>
      </div>

      <form onSubmit={handleSubmit(onSubmit)} className="space-y-6">
        <div className="glass-card p-6 space-y-6">
          <div>
            <label className="block text-sm font-medium mb-2">Agent Name</label>
            <input
              type="text"
              {...register('name')}
              className="input-field"
              placeholder="e.g., Lead Qualifier Bot"
            />
            {errors.name && (
              <p className="mt-1 text-sm text-red-400">{errors.name.message}</p>
            )}
          </div>

          <div>
            <label className="block text-sm font-medium mb-2">Description</label>
            <textarea
              {...register('description')}
              className="input-field"
              rows={3}
              placeholder="What does this agent do?"
            />
          </div>

          <div>
            <label className="block text-sm font-medium mb-4">Agent Type</label>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              {agentTypes.map((type) => (
                <label
                  key={type.value}
                  className={`p-4 rounded-lg border cursor-pointer transition-all ${
                    selectedType === type.value
                      ? 'border-primary-500 bg-primary-500/10'
                      : 'border-dark-600 hover:border-dark-500'
                  }`}
                >
                  <input
                    type="radio"
                    {...register('type')}
                    value={type.value}
                    className="sr-only"
                  />
                  <p className="font-medium">{type.label}</p>
                  <p className="text-sm text-dark-500">{type.description}</p>
                </label>
              ))}
            </div>
          </div>
        </div>

        <div className="glass-card p-6 space-y-6">
          <h3 className="text-lg font-semibold">AI Configuration</h3>

          <div>
            <label className="block text-sm font-medium mb-2">Model</label>
            <select {...register('model')} className="input-field">
              <option value="gpt-4">GPT-4 (Recommended)</option>
              <option value="gpt-4-turbo">GPT-4 Turbo</option>
              <option value="gpt-3.5-turbo">GPT-3.5 Turbo (Faster)</option>
            </select>
          </div>

          <div>
            <label className="block text-sm font-medium mb-2">
              Temperature: {watch('temperature')}
            </label>
            <input
              type="range"
              {...register('temperature', { valueAsNumber: true })}
              min="0"
              max="2"
              step="0.1"
              className="w-full"
            />
            <p className="text-sm text-dark-500 mt-1">
              Lower = more focused, Higher = more creative
            </p>
          </div>

          <div>
            <label className="block text-sm font-medium mb-2">Max Tokens</label>
            <input
              type="number"
              {...register('maxTokens', { valueAsNumber: true })}
              className="input-field"
              min="1"
              max="8000"
            />
          </div>

          <div>
            <label className="block text-sm font-medium mb-2">System Prompt</label>
            <textarea
              {...register('systemPrompt')}
              className="input-field font-mono text-sm"
              rows={6}
              placeholder="Enter instructions for how the agent should behave..."
            />
            <p className="text-sm text-dark-500 mt-1">
              Define the personality and behavior of your AI agent
            </p>
          </div>
        </div>

        <div className="flex gap-4">
          <button
            type="button"
            onClick={() => navigate('/agents')}
            className="btn-secondary flex-1"
          >
            Cancel
          </button>
          <button
            type="submit"
            className="btn-primary flex-1"
            disabled={isLoading}
          >
            {isLoading ? 'Creating...' : 'Create Agent'}
          </button>
        </div>
      </form>
    </div>
  );
}
