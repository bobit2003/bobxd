import { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { agentApi } from '../../utils/api';
import { 
  ArrowLeftIcon, 
  PlayIcon, 
  PauseIcon,
  TrashIcon,
  BoltIcon,
} from '@heroicons/react/24/outline';
import toast from 'react-hot-toast';

const statusColors: Record<string, string> = {
  PENDING: 'badge-warning',
  RUNNING: 'badge-info',
  COMPLETED: 'badge-success',
  FAILED: 'badge-error',
  CANCELLED: 'badge-error',
  RETRYING: 'badge-warning',
};

export default function AgentDetail() {
  const { agentId } = useParams<{ agentId: string }>();
  const navigate = useNavigate();
  const [agent, setAgent] = useState<any>(null);
  const [executions, setExecutions] = useState<any[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [activeTab, setActiveTab] = useState('overview');

  useEffect(() => {
    if (agentId) {
      loadAgent();
    }
  }, [agentId]);

  const loadAgent = async () => {
    setIsLoading(true);
    try {
      const [agentRes, executionsRes] = await Promise.all([
        agentApi.get(agentId!),
        agentApi.getExecutions(agentId!),
      ]);
      setAgent(agentRes.data.data);
      setExecutions(executionsRes.data.data.executions);
    } catch (error) {
      toast.error('Failed to load agent');
      navigate('/agents');
    } finally {
      setIsLoading(false);
    }
  };

  const handleActivate = async () => {
    try {
      await agentApi.activate(agentId!);
      toast.success('Agent activated');
      loadAgent();
    } catch (error) {
      toast.error('Failed to activate agent');
    }
  };

  const handlePause = async () => {
    try {
      await agentApi.pause(agentId!);
      toast.success('Agent paused');
      loadAgent();
    } catch (error) {
      toast.error('Failed to pause agent');
    }
  };

  const handleDelete = async () => {
    if (!confirm('Are you sure you want to delete this agent?')) return;
    
    try {
      await agentApi.delete(agentId!);
      toast.success('Agent deleted');
      navigate('/agents');
    } catch (error) {
      toast.error('Failed to delete agent');
    }
  };

  const handleTest = async () => {
    try {
      await agentApi.execute(agentId!, {
        taskType: 'test',
        input: { message: 'Hello, this is a test' },
      });
      toast.success('Test execution started');
    } catch (error) {
      toast.error('Failed to start test');
    }
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-96">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary-500" />
      </div>
    );
  }

  if (!agent) return null;

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div className="flex items-center gap-4">
          <button
            onClick={() => navigate('/agents')}
            className="p-2 rounded-lg hover:bg-dark-700 transition-colors"
          >
            <ArrowLeftIcon className="w-5 h-5" />
          </button>
          <div>
            <h1 className="text-2xl font-bold">{agent.name}</h1>
            <p className="text-dark-500">{agent.type}</p>
          </div>
        </div>
        <div className="flex gap-3">
          <button onClick={handleTest} className="btn-secondary">
            <BoltIcon className="w-5 h-5" />
            Test
          </button>
          {agent.status === 'ACTIVE' ? (
            <button onClick={handlePause} className="btn-outline">
              <PauseIcon className="w-5 h-5" />
              Pause
            </button>
          ) : (
            <button onClick={handleActivate} className="btn-primary">
              <PlayIcon className="w-5 h-5" />
              Activate
            </button>
          )}
          <button onClick={handleDelete} className="btn-outline text-red-400 border-red-400/30">
            <TrashIcon className="w-5 h-5" />
          </button>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex gap-1 border-b border-dark-600">
        {['overview', 'executions', 'settings'].map((tab) => (
          <button
            key={tab}
            className={`px-4 py-2 font-medium capitalize transition-colors ${
              activeTab === tab
                ? 'text-primary-400 border-b-2 border-primary-400'
                : 'text-dark-500 hover:text-white'
            }`}
            onClick={() => setActiveTab(tab)}
          >
            {tab}
          </button>
        ))}
      </div>

      {activeTab === 'overview' && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2 space-y-6">
            <div className="glass-card p-6">
              <h3 className="text-lg font-semibold mb-4">Agent Information</h3>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <p className="text-sm text-dark-500">Status</p>
                  <span className={`badge ${statusColors[agent.status] || 'badge-info'}`}>
                    {agent.status}
                  </span>
                </div>
                <div>
                  <p className="text-sm text-dark-500">Type</p>
                  <p className="font-medium">{agent.type}</p>
                </div>
                <div>
                  <p className="text-sm text-dark-500">Model</p>
                  <p className="font-medium">{agent.model}</p>
                </div>
                <div>
                  <p className="text-sm text-dark-500">Temperature</p>
                  <p className="font-medium">{agent.temperature}</p>
                </div>
              </div>
            </div>

            {agent.description && (
              <div className="glass-card p-6">
                <h3 className="text-lg font-semibold mb-4">Description</h3>
                <p className="text-dark-500">{agent.description}</p>
              </div>
            )}
          </div>

          <div className="space-y-6">
            <div className="glass-card p-6">
              <h3 className="text-lg font-semibold mb-4">Usage</h3>
              <div className="space-y-4">
                <div>
                  <p className="text-sm text-dark-500">Token Usage</p>
                  <p className="text-2xl font-bold">{agent.tokenUsage?.toLocaleString()}</p>
                </div>
                <div>
                  <p className="text-sm text-dark-500">Cost Used</p>
                  <p className="text-2xl font-bold">${Number(agent.costUsed).toFixed(4)}</p>
                </div>
                <div>
                  <p className="text-sm text-dark-500">Total Executions</p>
                  <p className="text-2xl font-bold">{agent._count?.executions || 0}</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {activeTab === 'executions' && (
        <div className="glass-card p-6">
          <h3 className="text-lg font-semibold mb-4">Recent Executions</h3>
          {executions.length > 0 ? (
            <div className="space-y-4">
              {executions.map((execution) => (
                <div key={execution.id} className="flex items-center justify-between p-4 bg-dark-700/30 rounded-lg">
                  <div>
                    <p className="font-medium">{execution.type}</p>
                    <p className="text-sm text-dark-500">
                      {new Date(execution.createdAt).toLocaleString()}
                    </p>
                  </div>
                  <div className="flex items-center gap-4">
                    <span className="text-sm text-dark-500">
                      {execution.tokensUsed} tokens
                    </span>
                    <span className={`badge ${statusColors[execution.status]}`}>
                      {execution.status}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <p className="text-dark-500 text-center py-8">No executions yet</p>
          )}
        </div>
      )}

      {activeTab === 'settings' && (
        <div className="glass-card p-6">
          <h3 className="text-lg font-semibold mb-4">System Prompt</h3>
          <pre className="bg-dark-800 p-4 rounded-lg text-sm font-mono overflow-x-auto">
            {agent.systemPrompt || 'No system prompt configured'}
          </pre>
        </div>
      )}
    </div>
  );
}
