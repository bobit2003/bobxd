import { Outlet } from 'react-router-dom';
import { useState, useEffect } from 'react';
import { Bars3Icon, XMarkIcon } from '@heroicons/react/24/outline';

const navigation = [
  { name: 'Features', href: '#features' },
  { name: 'Pricing', href: '#pricing' },
  { name: 'Testimonials', href: '#testimonials' },
  { name: 'Docs', href: '#docs' },
];

export default function LandingLayout() {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 50);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <div className="min-h-screen bg-dark-900">
      {/* Navigation */}
      <header
        className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
          scrolled
            ? 'bg-dark-900/80 backdrop-blur-xl border-b border-dark-600'
            : 'bg-transparent'
        }`}
      >
        <nav className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16 lg:h-20">
            {/* Logo */}
            <a href="/" className="flex items-center gap-2">
              <span className="text-2xl font-bold gradient-text">BOB XD</span>
            </a>

            {/* Desktop navigation */}
            <div className="hidden lg:flex items-center gap-8">
              {navigation.map((item) => (
                <a
                  key={item.name}
                  href={item.href}
                  className="text-dark-500 hover:text-white transition-colors"
                >
                  {item.name}
                </a>
              ))}
            </div>

            {/* CTA buttons */}
            <div className="hidden lg:flex items-center gap-4">
              <a
                href="/login"
                className="text-dark-500 hover:text-white transition-colors"
              >
                Sign in
              </a>
              <a
                href="/register"
                className="btn-primary"
              >
                Get Started
              </a>
            </div>

            {/* Mobile menu button */}
            <button
              className="lg:hidden p-2 rounded-lg hover:bg-dark-700"
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            >
              {mobileMenuOpen ? (
                <XMarkIcon className="w-6 h-6" />
              ) : (
                <Bars3Icon className="w-6 h-6" />
              )}
            </button>
          </div>

          {/* Mobile menu */}
          {mobileMenuOpen && (
            <div className="lg:hidden py-4 border-t border-dark-600">
              <div className="space-y-4">
                {navigation.map((item) => (
                  <a
                    key={item.name}
                    href={item.href}
                    className="block text-dark-500 hover:text-white transition-colors"
                    onClick={() => setMobileMenuOpen(false)}
                  >
                    {item.name}
                  </a>
                ))}
                <div className="pt-4 border-t border-dark-600 space-y-3">
                  <a
                    href="/login"
                    className="block text-dark-500 hover:text-white transition-colors"
                  >
                    Sign in
                  </a>
                  <a
                    href="/register"
                    className="btn-primary block text-center"
                  >
                    Get Started
                  </a>
                </div>
              </div>
            </div>
          )}
        </nav>
      </header>

      {/* Main content */}
      <main>
        <Outlet />
      </main>

      {/* Footer */}
      <footer className="bg-dark-800 border-t border-dark-600">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
          <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-5 gap-8">
            {/* Brand */}
            <div className="col-span-2 lg:col-span-2">
              <span className="text-xl font-bold gradient-text">BOB XD</span>
              <p className="mt-4 text-dark-500 max-w-sm">
                The AI Operating System for modern agencies. Automate lead generation, 
                qualification, and nurturing with intelligent AI agents.
              </p>
            </div>

            {/* Links */}
            <div>
              <h3 className="font-semibold mb-4">Product</h3>
              <ul className="space-y-2">
                <li><a href="#features" className="text-dark-500 hover:text-white transition-colors">Features</a></li>
                <li><a href="#pricing" className="text-dark-500 hover:text-white transition-colors">Pricing</a></li>
                <li><a href="#" className="text-dark-500 hover:text-white transition-colors">Integrations</a></li>
                <li><a href="#" className="text-dark-500 hover:text-white transition-colors">API</a></li>
              </ul>
            </div>

            <div>
              <h3 className="font-semibold mb-4">Company</h3>
              <ul className="space-y-2">
                <li><a href="#" className="text-dark-500 hover:text-white transition-colors">About</a></li>
                <li><a href="#" className="text-dark-500 hover:text-white transition-colors">Blog</a></li>
                <li><a href="#" className="text-dark-500 hover:text-white transition-colors">Careers</a></li>
                <li><a href="#" className="text-dark-500 hover:text-white transition-colors">Contact</a></li>
              </ul>
            </div>

            <div>
              <h3 className="font-semibold mb-4">Resources</h3>
              <ul className="space-y-2">
                <li><a href="#" className="text-dark-500 hover:text-white transition-colors">Documentation</a></li>
                <li><a href="#" className="text-dark-500 hover:text-white transition-colors">Help Center</a></li>
                <li><a href="#" className="text-dark-500 hover:text-white transition-colors">Community</a></li>
                <li><a href="#" className="text-dark-500 hover:text-white transition-colors">Status</a></li>
              </ul>
            </div>
          </div>

          <div className="mt-12 pt-8 border-t border-dark-600 flex flex-col md:flex-row items-center justify-between gap-4">
            <p className="text-dark-500 text-sm">
              © {new Date().getFullYear()} BOB XD. All rights reserved.
            </p>
            <div className="flex items-center gap-6">
              <a href="#" className="text-dark-500 hover:text-white text-sm transition-colors">Privacy</a>
              <a href="#" className="text-dark-500 hover:text-white text-sm transition-colors">Terms</a>
              <a href="#" className="text-dark-500 hover:text-white text-sm transition-colors">Security</a>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}
