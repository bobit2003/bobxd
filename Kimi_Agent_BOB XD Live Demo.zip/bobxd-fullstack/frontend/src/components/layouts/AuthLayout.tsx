import { Outlet } from 'react-router-dom';

export default function AuthLayout() {
  return (
    <div className="min-h-screen bg-dark-900 flex items-center justify-center p-4">
      {/* Background effects */}
      <div className="fixed inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-0 left-1/4 w-96 h-96 bg-primary-500/10 rounded-full blur-3xl" />
        <div className="absolute bottom-0 right-1/4 w-96 h-96 bg-accent-500/10 rounded-full blur-3xl" />
        <div className="absolute inset-0 bg-grid-pattern opacity-50" />
      </div>

      <div className="relative w-full max-w-md">
        {/* Logo */}
        <div className="text-center mb-8">
          <h1 className="text-3xl font-bold gradient-text mb-2">BOB XD</h1>
          <p className="text-dark-500">AI Operating System for Agencies</p>
        </div>

        {/* Auth form container */}
        <div className="glass-card p-8">
          <Outlet />
        </div>

        {/* Footer */}
        <p className="text-center text-dark-500 text-sm mt-8">
          By continuing, you agree to our{' '}
          <a href="#" className="text-primary-400 hover:text-primary-300">Terms of Service</a>
          {' '}and{' '}
          <a href="#" className="text-primary-400 hover:text-primary-300">Privacy Policy</a>
        </p>
      </div>
    </div>
  );
}
