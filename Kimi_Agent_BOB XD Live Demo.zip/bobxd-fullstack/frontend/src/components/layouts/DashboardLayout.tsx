import { useState, useEffect } from 'react';
import { Outlet, useNavigate, useLocation } from 'react-router-dom';
import { 
  HomeIcon, 
  UsersIcon, 
  CpuChipIcon, 
  RocketLaunchIcon, 
  ChartBarIcon, 
  CogIcon,
  Bars3Icon,
  XMarkIcon,
  BellIcon,
  UserCircleIcon,
  BuildingOfficeIcon,
  ChevronDownIcon,
  ShieldCheckIcon,
} from '@heroicons/react/24/outline';
import { useAuthStore } from '../../stores/authStore';
import { useWorkspaceStore } from '../../stores/workspaceStore';
import { workspaceApi } from '../../utils/api';
import toast from 'react-hot-toast';

const navigation = [
  { name: 'Dashboard', href: '/dashboard', icon: HomeIcon },
  { name: 'Leads', href: '/leads', icon: UsersIcon },
  { name: 'Agents', href: '/agents', icon: CpuChipIcon },
  { name: 'Campaigns', href: '/campaigns', icon: RocketLaunchIcon },
  { name: 'Analytics', href: '/analytics', icon: ChartBarIcon },
];

const settingsNavigation = [
  { name: 'Settings', href: '/settings', icon: CogIcon },
  { name: 'Workspace', href: '/settings/workspace', icon: BuildingOfficeIcon },
  { name: 'Billing', href: '/settings/billing', icon: ChartBarIcon },
];

export default function DashboardLayout() {
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [workspaceDropdownOpen, setWorkspaceDropdownOpen] = useState(false);
  const { user, logout } = useAuthStore();
  const { workspaces, currentWorkspace, setWorkspaces, setCurrentWorkspace } = useWorkspaceStore();
  const navigate = useNavigate();
  const location = useLocation();

  useEffect(() => {
    loadWorkspaces();
  }, []);

  const loadWorkspaces = async () => {
    try {
      const response = await workspaceApi.list();
      const workspaceList = response.data.data;
      setWorkspaces(workspaceList);
      
      if (!currentWorkspace && workspaceList.length > 0) {
        setCurrentWorkspace(workspaceList[0]);
      }
    } catch (error) {
      toast.error('Failed to load workspaces');
    }
  };

  const handleLogout = () => {
    logout();
    navigate('/login');
  };

  const handleWorkspaceChange = (workspace: any) => {
    setCurrentWorkspace(workspace);
    setWorkspaceDropdownOpen(false);
    toast.success(`Switched to ${workspace.name}`);
  };

  const isAdmin = user?.role === 'ADMIN' || user?.role === 'SUPER_ADMIN';

  return (
    <div className="min-h-screen bg-dark-900">
      {/* Mobile sidebar */}
      {sidebarOpen && (
        <div className="fixed inset-0 z-50 lg:hidden">
          <div 
            className="fixed inset-0 bg-black/50 backdrop-blur-sm"
            onClick={() => setSidebarOpen(false)}
          />
          <div className="fixed inset-y-0 left-0 w-64 bg-dark-800 border-r border-dark-600">
            <div className="flex items-center justify-between p-4 border-b border-dark-600">
              <span className="text-xl font-bold gradient-text">BOB XD</span>
              <button onClick={() => setSidebarOpen(false)}>
                <XMarkIcon className="w-6 h-6" />
              </button>
            </div>
            <nav className="p-4 space-y-1">
              {navigation.map((item) => (
                <a
                  key={item.name}
                  href={item.href}
                  className={`sidebar-link ${location.pathname === item.href ? 'active' : ''}`}
                >
                  <item.icon className="w-5 h-5" />
                  {item.name}
                </a>
              ))}
              {isAdmin && (
                <a
                  href="/admin"
                  className={`sidebar-link ${location.pathname.startsWith('/admin') ? 'active' : ''}`}
                >
                  <ShieldCheckIcon className="w-5 h-5" />
                  Admin
                </a>
              )}
            </nav>
          </div>
        </div>
      )}

      {/* Desktop sidebar */}
      <div className="hidden lg:fixed lg:inset-y-0 lg:flex lg:w-64 lg:flex-col">
        <div className="flex flex-col flex-1 bg-dark-800 border-r border-dark-600">
          <div className="flex items-center h-16 px-6 border-b border-dark-600">
            <span className="text-xl font-bold gradient-text">BOB XD</span>
          </div>
          <nav className="flex-1 p-4 space-y-1 overflow-y-auto scrollbar-thin">
            {navigation.map((item) => (
              <a
                key={item.name}
                href={item.href}
                className={`sidebar-link ${location.pathname === item.href ? 'active' : ''}`}
              >
                <item.icon className="w-5 h-5" />
                {item.name}
              </a>
            ))}
            {isAdmin && (
              <a
                href="/admin"
                className={`sidebar-link ${location.pathname.startsWith('/admin') ? 'active' : ''}`}
              >
                <ShieldCheckIcon className="w-5 h-5" />
                Admin
              </a>
            )}
          </nav>
          <div className="p-4 border-t border-dark-600">
            <div className="space-y-1">
              {settingsNavigation.map((item) => (
                <a
                  key={item.name}
                  href={item.href}
                  className={`sidebar-link ${location.pathname === item.href ? 'active' : ''}`}
                >
                  <item.icon className="w-5 h-5" />
                  {item.name}
                </a>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Main content */}
      <div className="lg:pl-64">
        {/* Header */}
        <header className="sticky top-0 z-40 bg-dark-800/80 backdrop-blur-xl border-b border-dark-600">
          <div className="flex items-center justify-between h-16 px-4 sm:px-6 lg:px-8">
            <div className="flex items-center gap-4">
              <button
                className="lg:hidden p-2 rounded-lg hover:bg-dark-700"
                onClick={() => setSidebarOpen(true)}
              >
                <Bars3Icon className="w-6 h-6" />
              </button>

              {/* Workspace Selector */}
              {currentWorkspace && (
                <div className="relative">
                  <button
                    className="flex items-center gap-2 px-4 py-2 bg-dark-700 rounded-lg hover:bg-dark-600 transition-colors"
                    onClick={() => setWorkspaceDropdownOpen(!workspaceDropdownOpen)}
                  >
                    <BuildingOfficeIcon className="w-5 h-5 text-primary-400" />
                    <span className="font-medium">{currentWorkspace.name}</span>
                    <ChevronDownIcon className={`w-4 h-4 transition-transform ${workspaceDropdownOpen ? 'rotate-180' : ''}`} />
                  </button>

                  {workspaceDropdownOpen && (
                    <div className="absolute top-full left-0 mt-2 w-64 bg-dark-800 border border-dark-600 rounded-xl shadow-xl z-50">
                      <div className="p-2">
                        <p className="px-3 py-2 text-xs font-medium text-dark-500 uppercase">
                          Your Workspaces
                        </p>
                        {workspaces.map((workspace) => (
                          <button
                            key={workspace.id}
                            className={`w-full flex items-center gap-3 px-3 py-2 rounded-lg text-left transition-colors ${
                              currentWorkspace.id === workspace.id
                                ? 'bg-primary-500/20 text-primary-400'
                                : 'hover:bg-dark-700'
                            }`}
                            onClick={() => handleWorkspaceChange(workspace)}
                          >
                            <BuildingOfficeIcon className="w-5 h-5" />
                            <div>
                              <p className="font-medium">{workspace.name}</p>
                              <p className="text-xs text-dark-500">{workspace.plan} Plan</p>
                            </div>
                          </button>
                        ))}
                      </div>
                      <div className="border-t border-dark-600 p-2">
                        <button
                          className="w-full flex items-center gap-3 px-3 py-2 rounded-lg text-left hover:bg-dark-700 transition-colors text-primary-400"
                          onClick={() => {
                            setWorkspaceDropdownOpen(false);
                            navigate('/settings/workspace');
                          }}
                        >
                          <span className="text-sm">+ Create New Workspace</span>
                        </button>
                      </div>
                    </div>
                  )}
                </div>
              )}
            </div>

            <div className="flex items-center gap-4">
              <button className="relative p-2 rounded-lg hover:bg-dark-700 transition-colors">
                <BellIcon className="w-6 h-6" />
                <span className="absolute top-1 right-1 w-2 h-2 bg-primary-500 rounded-full" />
              </button>

              <div className="relative group">
                <button className="flex items-center gap-3 p-2 rounded-lg hover:bg-dark-700 transition-colors">
                  {user?.avatar ? (
                    <img
                      src={user.avatar}
                      alt={user.firstName}
                      className="w-8 h-8 rounded-full"
                    />
                  ) : (
                    <UserCircleIcon className="w-8 h-8 text-dark-500" />
                  )}
                  <div className="hidden sm:block text-left">
                    <p className="text-sm font-medium">{user?.firstName} {user?.lastName}</p>
                    <p className="text-xs text-dark-500">{user?.email}</p>
                  </div>
                </button>

                <div className="absolute right-0 top-full mt-2 w-48 bg-dark-800 border border-dark-600 rounded-xl shadow-xl opacity-0 invisible group-hover:opacity-100 group-hover:visible transition-all z-50">
                  <div className="p-2">
                    <a
                      href="/settings"
                      className="flex items-center gap-3 px-3 py-2 rounded-lg hover:bg-dark-700 transition-colors"
                    >
                      <CogIcon className="w-5 h-5" />
                      <span>Settings</span>
                    </a>
                    <button
                      onClick={handleLogout}
                      className="w-full flex items-center gap-3 px-3 py-2 rounded-lg hover:bg-dark-700 transition-colors text-red-400"
                    >
                      <span>Logout</span>
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </header>

        {/* Page content */}
        <main className="p-4 sm:p-6 lg:p-8">
          <Outlet />
        </main>
      </div>
    </div>
  );
}
