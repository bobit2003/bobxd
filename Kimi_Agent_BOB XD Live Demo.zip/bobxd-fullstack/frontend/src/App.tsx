import { Routes, Route, Navigate } from 'react-router-dom';
import { useAuthStore } from './stores/authStore';

// Layouts
import DashboardLayout from './components/layouts/DashboardLayout';
import AuthLayout from './components/layouts/AuthLayout';
import LandingLayout from './components/layouts/LandingLayout';

// Pages - Auth
import Login from './pages/auth/Login';
import Register from './pages/auth/Register';

// Pages - Landing
import Landing from './pages/landing/Landing';

// Pages - Dashboard
import Dashboard from './pages/dashboard/Dashboard';

// Pages - Leads
import LeadsList from './pages/leads/LeadsList';
import LeadDetail from './pages/leads/LeadDetail';

// Pages - Agents
import AgentsList from './pages/agents/AgentsList';
import AgentDetail from './pages/agents/AgentDetail';
import AgentCreate from './pages/agents/AgentCreate';

// Pages - Campaigns
import CampaignsList from './pages/campaigns/CampaignsList';
import CampaignDetail from './pages/campaigns/CampaignDetail';
import CampaignCreate from './pages/campaigns/CampaignCreate';

// Pages - Analytics
import Analytics from './pages/analytics/Analytics';

// Pages - Settings
import Settings from './pages/settings/Settings';
import WorkspaceSettings from './pages/settings/WorkspaceSettings';
import Billing from './pages/settings/Billing';

// Pages - Admin
import AdminDashboard from './pages/admin/AdminDashboard';
import AdminUsers from './pages/admin/AdminUsers';
import AdminWorkspaces from './pages/admin/AdminWorkspaces';

// Components
import ProtectedRoute from './components/ProtectedRoute';
import AdminRoute from './components/AdminRoute';

function App() {
  const { isAuthenticated, user } = useAuthStore();

  return (
    <Routes>
      {/* Landing Page Routes */}
      <Route element={<LandingLayout />}>
        <Route path="/" element={<Landing />} />
      </Route>

      {/* Auth Routes */}
      <Route element={<AuthLayout />}>
        <Route 
          path="/login" 
          element={isAuthenticated ? <Navigate to="/dashboard" /> : <Login />} 
        />
        <Route 
          path="/register" 
          element={isAuthenticated ? <Navigate to="/dashboard" /> : <Register />} 
        />
      </Route>

      {/* Protected Dashboard Routes */}
      <Route element={<ProtectedRoute />}>        <Route element={<DashboardLayout />}>
          <Route path="/dashboard" element={<Dashboard />} />
          
          {/* Leads */}
          <Route path="/leads" element={<LeadsList />} />
          <Route path="/leads/:leadId" element={<LeadDetail />} />
          
          {/* Agents */}
          <Route path="/agents" element={<AgentsList />} />
          <Route path="/agents/create" element={<AgentCreate />} />
          <Route path="/agents/:agentId" element={<AgentDetail />} />
          
          {/* Campaigns */}
          <Route path="/campaigns" element={<CampaignsList />} />
          <Route path="/campaigns/create" element={<CampaignCreate />} />
          <Route path="/campaigns/:campaignId" element={<CampaignDetail />} />
          
          {/* Analytics */}
          <Route path="/analytics" element={<Analytics />} />
          
          {/* Settings */}
          <Route path="/settings" element={<Settings />} />
          <Route path="/settings/workspace" element={<WorkspaceSettings />} />
          <Route path="/settings/billing" element={<Billing />} />
        </Route>
      </Route>

      {/* Admin Routes */}
      <Route element={<AdminRoute />}>
        <Route element={<DashboardLayout />}>
          <Route path="/admin" element={<AdminDashboard />} />
          <Route path="/admin/users" element={<AdminUsers />} />
          <Route path="/admin/workspaces" element={<AdminWorkspaces />} />
        </Route>
      </Route>

      {/* 404 */}
      <Route path="*" element={<Navigate to="/" />} />
    </Routes>
  );
}

export default App;
