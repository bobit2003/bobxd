import axios from 'axios';
import { useAuthStore } from '../stores/authStore';

const API_BASE_URL = import.meta.env.VITE_API_URL || '/api/v1';

export const api = axios.create({
  baseURL: API_BASE_URL,
  headers: {
    'Content-Type': 'application/json',
  },
});

// Request interceptor to add auth token
api.interceptors.request.use(
  (config) => {
    const tokens = useAuthStore.getState().tokens;
    if (tokens?.accessToken) {
      config.headers.Authorization = `Bearer ${tokens.accessToken}`;
    }
    return config;
  },
  (error) => Promise.reject(error)
);

// Response interceptor to handle token refresh
api.interceptors.response.use(
  (response) => response,
  async (error) => {
    const originalRequest = error.config;

    // If error is 401 and we haven't tried to refresh token yet
    if (error.response?.status === 401 && !originalRequest._retry) {
      originalRequest._retry = true;

      try {
        const tokens = useAuthStore.getState().tokens;
        if (tokens?.refreshToken) {
          const response = await axios.post(`${API_BASE_URL}/auth/refresh`, {
            refreshToken: tokens.refreshToken,
          });

          const { tokens: newTokens } = response.data.data;
          useAuthStore.getState().setTokens(newTokens);

          // Retry original request with new token
          originalRequest.headers.Authorization = `Bearer ${newTokens.accessToken}`;
          return api(originalRequest);
        }
      } catch (refreshError) {
        // Refresh failed, logout user
        useAuthStore.getState().logout();
        window.location.href = '/login';
        return Promise.reject(refreshError);
      }
    }

    return Promise.reject(error);
  }
);

// API endpoints
export const authApi = {
  login: (email: string, password: string) =>
    api.post('/auth/login', { email, password }),
  
  register: (data: { email: string; password: string; firstName: string; lastName: string }) =>
    api.post('/auth/register', data),
  
  logout: () => api.post('/auth/logout'),
  
  me: () => api.get('/auth/me'),
  
  refresh: (refreshToken: string) =>
    api.post('/auth/refresh', { refreshToken }),
  
  changePassword: (currentPassword: string, newPassword: string) =>
    api.post('/auth/change-password', { currentPassword, newPassword }),
};

export const workspaceApi = {
  list: () => api.get('/workspaces'),
  
  get: (workspaceId: string) => api.get(`/workspaces/${workspaceId}`),
  
  create: (data: { name: string; slug: string; description?: string }) =>
    api.post('/workspaces', data),
  
  update: (workspaceId: string, data: Partial<{ name: string; description: string }>) =>
    api.patch(`/workspaces/${workspaceId}`, data),
  
  delete: (workspaceId: string) => api.delete(`/workspaces/${workspaceId}`),
  
  getMembers: (workspaceId: string) =>
    api.get(`/workspaces/${workspaceId}/members`),
  
  inviteMember: (workspaceId: string, data: { email: string; role: string }) =>
    api.post(`/workspaces/${workspaceId}/members`, data),
  
  removeMember: (workspaceId: string, memberId: string) =>
    api.delete(`/workspaces/${workspaceId}/members/${memberId}`),
  
  getStats: (workspaceId: string) =>
    api.get(`/workspaces/${workspaceId}/stats`),
};

export const leadApi = {
  list: (workspaceId: string, params?: Record<string, string>) =>
    api.get(`/leads/workspace/${workspaceId}`, { params }),
  
  get: (leadId: string) => api.get(`/leads/${leadId}`),
  
  create: (workspaceId: string, data: any) =>
    api.post(`/leads/workspace/${workspaceId}`, data),
  
  update: (leadId: string, data: any) =>
    api.patch(`/leads/${leadId}`, data),
  
  delete: (leadId: string) => api.delete(`/leads/${leadId}`),
  
  addActivity: (leadId: string, data: any) =>
    api.post(`/leads/${leadId}/activities`, data),
  
  import: (workspaceId: string, leads: any[]) =>
    api.post(`/leads/workspace/${workspaceId}/import`, leads),
  
  bulkUpdate: (data: { leadIds: string[]; data: any }) =>
    api.post('/leads/bulk-update', data),
  
  getStats: (workspaceId: string) =>
    api.get(`/leads/workspace/${workspaceId}/stats`),
};

export const agentApi = {
  list: (workspaceId: string, params?: Record<string, string>) =>
    api.get(`/agents/workspace/${workspaceId}`, { params }),
  
  get: (agentId: string) => api.get(`/agents/${agentId}`),
  
  create: (workspaceId: string, data: any) =>
    api.post(`/agents/workspace/${workspaceId}`, data),
  
  update: (agentId: string, data: any) =>
    api.patch(`/agents/${agentId}`, data),
  
  delete: (agentId: string) => api.delete(`/agents/${agentId}`),
  
  activate: (agentId: string) =>
    api.post(`/agents/${agentId}/activate`),
  
  pause: (agentId: string) =>
    api.post(`/agents/${agentId}/pause`),
  
  execute: (agentId: string, data: { taskType: string; input: any }) =>
    api.post(`/agents/${agentId}/execute`, data),
  
  getExecutions: (agentId: string, params?: Record<string, string>) =>
    api.get(`/agents/${agentId}/executions`, { params }),
  
  getStats: (workspaceId: string) =>
    api.get(`/agents/workspace/${workspaceId}/stats`),
};

export const campaignApi = {
  list: (workspaceId: string, params?: Record<string, string>) =>
    api.get(`/campaigns/workspace/${workspaceId}`, { params }),
  
  get: (campaignId: string) => api.get(`/campaigns/${campaignId}`),
  
  create: (workspaceId: string, data: any) =>
    api.post(`/campaigns/workspace/${workspaceId}`, data),
  
  update: (campaignId: string, data: any) =>
    api.patch(`/campaigns/${campaignId}`, data),
  
  delete: (campaignId: string) => api.delete(`/campaigns/${campaignId}`),
  
  start: (campaignId: string) =>
    api.post(`/campaigns/${campaignId}/start`),
  
  pause: (campaignId: string) =>
    api.post(`/campaigns/${campaignId}/pause`),
  
  addLeads: (campaignId: string, leadIds: string[]) =>
    api.post(`/campaigns/${campaignId}/leads`, { leadIds }),
  
  removeLeads: (campaignId: string, leadIds: string[]) =>
    api.delete(`/campaigns/${campaignId}/leads`, { data: { leadIds } }),
  
  getStats: (campaignId: string) =>
    api.get(`/campaigns/${campaignId}/stats`),
};

export const analyticsApi = {
  getDashboard: (workspaceId: string) =>
    api.get(`/analytics/workspace/${workspaceId}/dashboard`),
  
  getTimeSeries: (workspaceId: string, params?: Record<string, string>) =>
    api.get(`/analytics/workspace/${workspaceId}/timeseries`, { params }),
  
  getFunnel: (workspaceId: string) =>
    api.get(`/analytics/workspace/${workspaceId}/funnel`),
  
  getAgentPerformance: (workspaceId: string) =>
    api.get(`/analytics/workspace/${workspaceId}/agent-performance`),
  
  getCampaignPerformance: (workspaceId: string) =>
    api.get(`/analytics/workspace/${workspaceId}/campaign-performance`),
};

export const subscriptionApi = {
  get: () => api.get('/subscriptions'),
  
  getPlans: () => api.get('/subscriptions/plans'),
  
  create: (data: { priceId: string; paymentMethodId?: string }) =>
    api.post('/subscriptions', data),
  
  update: (data: { priceId: string }) =>
    api.patch('/subscriptions', data),
  
  cancel: () => api.delete('/subscriptions'),
  
  getInvoices: () => api.get('/subscriptions/invoices'),
  
  getUsage: () => api.get('/subscriptions/usage'),
  
  createPaymentIntent: (amount: number, currency?: string) =>
    api.post('/subscriptions/payment-intent', { amount, currency }),
};

export const adminApi = {
  getDashboard: () => api.get('/admin/dashboard'),
  
  getUsers: (params?: Record<string, string>) =>
    api.get('/admin/users', { params }),
  
  getUser: (userId: string) => api.get(`/admin/users/${userId}`),
  
  updateUser: (userId: string, data: any) =>
    api.patch(`/admin/users/${userId}`, data),
  
  deleteUser: (userId: string) => api.delete(`/admin/users/${userId}`),
  
  getWorkspaces: (params?: Record<string, string>) =>
    api.get('/admin/workspaces', { params }),
  
  getWorkspace: (workspaceId: string) =>
    api.get(`/admin/workspaces/${workspaceId}`),
  
  updateWorkspace: (workspaceId: string, data: any) =>
    api.patch(`/admin/workspaces/${workspaceId}`, data),
  
  deleteWorkspace: (workspaceId: string) =>
    api.delete(`/admin/workspaces/${workspaceId}`),
  
  getSettings: () => api.get('/admin/settings'),
  
  updateSetting: (data: { key: string; value: any; description?: string }) =>
    api.put('/admin/settings', data),
  
  getAuditLogs: (params?: Record<string, string>) =>
    api.get('/admin/audit-logs', { params }),
  
  getAnalytics: () => api.get('/admin/analytics'),
};
