# BOB XD - AI Operating System for Agencies

A comprehensive full-stack SaaS platform for automating lead generation, qualification, and nurturing with intelligent AI agents.

## Features

### Core Features
- **AI Agents**: Create and manage AI-powered agents for lead qualification, email sending, appointment scheduling, and more
- **Lead Management**: Comprehensive CRM for tracking and managing leads
- **Campaigns**: Multi-channel campaigns with automated workflows
- **Analytics**: Detailed insights and performance tracking
- **Team Collaboration**: Multi-tenant workspaces with role-based access
- **Integrations**: Connect with Salesforce, HubSpot, Slack, Zapier, and more

### AI Capabilities
- Lead qualification using GPT-4
- Automated email generation and sending
- Smart follow-up scheduling
- Data enrichment from multiple sources
- Custom agent creation with configurable prompts

## Tech Stack

### Backend
- **Framework**: Fastify (Node.js)
- **Language**: TypeScript
- **Database**: PostgreSQL with Prisma ORM
- **Cache/Queue**: Redis with BullMQ
- **Authentication**: JWT with refresh tokens
- **AI Integration**: OpenAI GPT-4
- **Payments**: Stripe

### Frontend
- **Framework**: React 18
- **Language**: TypeScript
- **Styling**: Tailwind CSS
- **State Management**: Zustand
- **Data Fetching**: React Query
- **Charts**: Recharts
- **Build Tool**: Vite

## Quick Start

### Prerequisites
- Node.js 20+
- PostgreSQL 16+
- Redis 7+
- Docker (optional)

### Local Development

1. **Clone the repository**
```bash
git clone <repository-url>
cd bobxd-fullstack
```

2. **Set up environment variables**
```bash
cp backend/.env.example backend/.env
# Edit backend/.env with your configuration
```

3. **Start with Docker Compose**
```bash
docker-compose up -d
```

Or manually:

4. **Install dependencies**
```bash
# Backend
cd backend
npm install

# Frontend
cd ../frontend
npm install
```

5. **Set up database**
```bash
cd backend
npx prisma migrate dev
npx prisma generate
```

6. **Start development servers**
```bash
# Backend (port 3000)
cd backend
npm run dev

# Frontend (port 5173)
cd frontend
npm run dev
```

7. **Access the application**
- Frontend: http://localhost:5173
- Backend API: http://localhost:3000
- API Documentation: http://localhost:3000/api/v1

## Project Structure

```
bobxd-fullstack/
├── backend/
│   ├── src/
│   │   ├── config/         # Configuration files
│   │   ├── middleware/     # Express/Fastify middleware
│   │   ├── prisma/         # Database schema and client
│   │   ├── routes/         # API routes
│   │   ├── services/       # Business logic services
│   │   ├── types/          # TypeScript types
│   │   └── utils/          # Utility functions
│   ├── Dockerfile
│   └── package.json
├── frontend/
│   ├── src/
│   │   ├── components/     # React components
│   │   ├── pages/          # Page components
│   │   ├── stores/         # Zustand stores
│   │   └── utils/          # Utility functions
│   ├── Dockerfile
│   └── package.json
└── docker-compose.yml
```

## API Endpoints

### Authentication
- `POST /api/v1/auth/register` - Register new user
- `POST /api/v1/auth/login` - Login
- `POST /api/v1/auth/refresh` - Refresh access token
- `POST /api/v1/auth/logout` - Logout
- `GET /api/v1/auth/me` - Get current user

### Workspaces
- `GET /api/v1/workspaces` - List workspaces
- `POST /api/v1/workspaces` - Create workspace
- `GET /api/v1/workspaces/:id` - Get workspace details
- `PATCH /api/v1/workspaces/:id` - Update workspace
- `DELETE /api/v1/workspaces/:id` - Delete workspace

### Leads
- `GET /api/v1/leads/workspace/:workspaceId` - List leads
- `POST /api/v1/leads/workspace/:workspaceId` - Create lead
- `GET /api/v1/leads/:id` - Get lead details
- `PATCH /api/v1/leads/:id` - Update lead
- `DELETE /api/v1/leads/:id` - Delete lead

### Agents
- `GET /api/v1/agents/workspace/:workspaceId` - List agents
- `POST /api/v1/agents/workspace/:workspaceId` - Create agent
- `GET /api/v1/agents/:id` - Get agent details
- `PATCH /api/v1/agents/:id` - Update agent
- `POST /api/v1/agents/:id/activate` - Activate agent
- `POST /api/v1/agents/:id/pause` - Pause agent
- `POST /api/v1/agents/:id/execute` - Execute agent task

### Campaigns
- `GET /api/v1/campaigns/workspace/:workspaceId` - List campaigns
- `POST /api/v1/campaigns/workspace/:workspaceId` - Create campaign
- `GET /api/v1/campaigns/:id` - Get campaign details
- `POST /api/v1/campaigns/:id/start` - Start campaign
- `POST /api/v1/campaigns/:id/pause` - Pause campaign

### Analytics
- `GET /api/v1/analytics/workspace/:workspaceId/dashboard` - Dashboard stats
- `GET /api/v1/analytics/workspace/:workspaceId/timeseries` - Time series data
- `GET /api/v1/analytics/workspace/:workspaceId/funnel` - Lead funnel

### Admin
- `GET /api/v1/admin/dashboard` - Admin dashboard stats
- `GET /api/v1/admin/users` - List all users
- `GET /api/v1/admin/workspaces` - List all workspaces

## Environment Variables

### Backend
| Variable | Description | Required |
|----------|-------------|----------|
| `DATABASE_URL` | PostgreSQL connection string | Yes |
| `REDIS_URL` | Redis connection string | Yes |
| `JWT_SECRET` | JWT signing secret | Yes |
| `JWT_REFRESH_SECRET` | JWT refresh token secret | Yes |
| `OPENAI_API_KEY` | OpenAI API key | No |
| `STRIPE_SECRET_KEY` | Stripe secret key | No |

### Frontend
| Variable | Description | Required |
|----------|-------------|----------|
| `VITE_API_URL` | Backend API URL | Yes |

## Deployment

### Docker Deployment
```bash
docker-compose up -d
```

### Production Build
```bash
# Backend
cd backend
npm run build
npm start

# Frontend
cd frontend
npm run build
# Serve dist/ folder with nginx or similar
```

## Contributing

1. Fork the repository
2. Create a feature branch
3. Commit your changes
4. Push to the branch
5. Create a Pull Request

## License

MIT License - see LICENSE file for details

## Support

For support, email support@bobxd.com or join our Discord community.
